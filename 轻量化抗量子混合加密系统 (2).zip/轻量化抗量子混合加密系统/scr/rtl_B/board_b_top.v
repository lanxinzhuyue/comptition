// ============================================================================
// board_b_top.v -- B 板加密闭环上板顶层 (Decaps 侧)
//
// IO (仅这些): clk, rst_n, uart_rx(A->B), uart_tx(B->PC), led
//   内部实例化 mlkem_b_loop_top, 走真实上板路径:
//     USE_RAND=1      d/z 由内部 TRNG+SHAKE256 (NUM_RUNS=1) 产生
//     PK_UART=1       复位自动 keygen -> 发 pk_B 帧 [0xAA][0x01][pk:800]
//                     收 A 密文帧 [0xAA][ct:768][ct_aes:16]
//                     回发明文帧 [0xAA][0x00][pt:16]
//     bypass_mlkem=0  真实 ML-KEM 核
//   SIM_MODE 参数透传: 0=真 TRNG(上板), 1=LFSR(仿真)
//
// 接线:
//   uart_rx  -> loop.uart2_rx   (A -> B 密文帧)
//   loop.uart1_tx -> uart_tx    (B -> PC: pk_B 帧 + 明文帧)
// ============================================================================
`timescale 1ns/1ps
module board_b_top #(
    parameter CLK_FREQ  = 50_000_000,
    parameter BAUD_RATE = 115_200,     // 上板: 115200; 仿真加速: 1.152M
    parameter SIM_MODE  = 0             // 0=真TRNG(上板), 1=LFSR(仿真)
) (
    input  wire clk_50m,      // 50MHz
    input  wire rst_n,        // 低有效
    input  wire uart_rx,      // A -> B
    output wire uart_tx,      // B -> PC
    output wire led
);

    wire [255:0] ss;
    wire         loop_done;

    mlkem_b_loop_top #(
        .CLK_FREQ (CLK_FREQ),
        .BAUD_RATE(BAUD_RATE),
        .USE_RAND (1),          // 内部 TRNG+SHAKE256
        .PK_UART  (1),          // 上板路径
        .SIM_MODE (SIM_MODE)    // 0=真TRNG
    ) u_loop (
        .clk(clk_50m), .rst_n(rst_n),
        .uart2_rx(uart_rx),                    // A -> B 密文帧
        .uart1_tx(uart_tx),                    // B -> PC (pk + 明文)
        .d_in(256'd0), .z_in(256'd0),          // USE_RAND=1 忽略
        .pk_w_a(8'd0), .pk_w_q(),              // PK_UART=1 内部驱动
        .bypass_mlkem(1'b0), .ss_bypass(256'd0),
        .led(led), .done(loop_done), .ss_out(ss)
    );

endmodule
