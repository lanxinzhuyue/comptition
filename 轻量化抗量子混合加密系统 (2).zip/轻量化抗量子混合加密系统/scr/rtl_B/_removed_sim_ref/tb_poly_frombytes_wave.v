// tb_poly_frombytes_wave.v
// 单元级: 实例化 poly_frombytes, 从 l_sk 读 384 字节 (sk 在 input_bytes.dat 的 768..1151),
// 写 s_hat 到 vec1 数组。验证 s_hat[0] 是否 == C 参考。
`timescale 1ns/1ps

module tb_poly_frombytes_wave;
    reg clk = 0;
    reg rst = 0;
    reg ap_start = 0;
    wire ap_done, ap_idle, ap_ready;

    // ---- l_sk BRAM (1632 深) ----
    wire [7:0] sk_q0, sk_q1;
    reg  [10:0] sk_addr0, sk_addr1;
    reg         sk_ce0, sk_ce1, sk_we0, sk_we1;
    reg  [7:0]  sk_d0, sk_d1;
    reg  load_done = 0;

    mlkem_b_top_l_sk_RAM_AUTO_1R1W #(
        .DataWidth(8), .AddressRange(1632), .AddressWidth(11))
    l_sk_U(
        .clk(clk), .reset(rst),
        .address0(load_done ? dut.a_address0 : sk_addr0),
        .ce0(load_done ? dut.a_ce0 : sk_ce0),
        .we0(load_done ? 1'b0 : sk_we0), .d0(sk_d0), .q0(sk_q0),
        .address1(load_done ? dut.a_address1 : sk_addr1),
        .ce1(load_done ? dut.a_ce1 : sk_ce1),
        .we1(load_done ? 1'b0 : sk_we1), .d1(sk_d1), .q1(sk_q1));

    // ---- DUT ----
    wire [8:0] r_address0;
    wire       r_ce0, r_we0;
    wire [15:0] r_d0;
    reg  [10:0] a_offset = 0;
    reg         r_offset = 0;
    wire [10:0] dut_a_address0, dut_a_address1;
    wire        dut_a_ce0, dut_a_ce1;

    mlkem_b_top_poly_frombytes dut(
        .ap_clk(clk), .ap_rst(rst),
        .ap_start(ap_start), .ap_done(ap_done), .ap_idle(ap_idle), .ap_ready(ap_ready),
        .r_address0(r_address0), .r_ce0(r_ce0), .r_we0(r_we0), .r_d0(r_d0),
        .r_offset(r_offset),
        .a_address0(dut_a_address0), .a_ce0(dut_a_ce0), .a_q0(sk_q0),
        .a_address1(dut_a_address1), .a_ce1(dut_a_ce1), .a_q1(sk_q1),
        .a_offset(a_offset));

    always #10 clk = ~clk;  // 50MHz

    // ---- sk 数据 (input_bytes.dat 768..1151 是 sk 前 384 字节) ----
    reg [7:0] sk [0:1631];
    reg [15:0] s_hat [0:255];
    integer cc, wc;
    initial begin
        $readmemh("input_bytes.dat", sk);
        wait (rst === 1'b0);
        // 载入 sk 前 384 字节 (偏移 768)
        for (cc = 0; cc < 384; cc = cc + 1) begin
            @(negedge clk);
            sk_addr0 = 768 + cc; sk_ce0 = 1; sk_we0 = 1; sk_d0 = sk[768 + cc];
            sk_addr1 = 0; sk_ce1 = 0; sk_we1 = 0; sk_d1 = 0;
        end
        @(negedge clk);
        sk_we0 = 0; sk_ce0 = 0;
        load_done = 1;
        a_offset = 768;   // sk 基址 (dec 路径 sk 从 0 起, 这里是 768 偏移的文件位置)
        r_offset = 0;
        $display("[tb] sk loaded (384B @ file offset 768), a_offset=%0d", a_offset);
    end

    // ---- 启动 ----
    initial begin
        wait (rst === 1'b0);
        wait (load_done === 1'b1);
        #40;
        @(negedge clk); ap_start = 1;
        wait (ap_done === 1'b1);
        @(negedge clk); ap_start = 0;
        $display("[tb] done at %0t", $time);
        #100;
        // 打印 s_hat 前 8 个
        for (wc = 0; wc < 8; wc = wc + 1)
            $display("s_hat[%0d] = %0d (0x%03x)", wc, s_hat[wc], s_hat[wc]);
        // C 参考 (从 sk 字节手算):
        // r[2i] = (a0 | a1<<8) & 0xFFF ; r[2i+1] = (a1>>4 | a2<<4) & 0xFFF
        for (wc = 0; wc < 8; wc = wc + 1) begin
            reg [15:0] ref0, ref1;
            ref0 = (sk[768 + 3*wc + 0] | (sk[768+3*wc+1] << 8)) & 16'hFFF;
            ref1 = ((sk[768+3*wc+1] >> 4) | (sk[768+3*wc+2] << 4)) & 16'hFFF;
            $display("ref[%0d]=%0d ref[%0d]=%0d", 2*wc, ref0, 2*wc+1, ref1);
        end
        $finish;
    end

    // ---- 捕获写回 ----
    always @(posedge clk) begin
        if (r_we0) begin
            s_hat[r_address0] <= r_d0[15:0];
            $display("[fb] W t=%0t adr=%0d val=%0d", $time, r_address0, r_d0);
        end
    end
endmodule
