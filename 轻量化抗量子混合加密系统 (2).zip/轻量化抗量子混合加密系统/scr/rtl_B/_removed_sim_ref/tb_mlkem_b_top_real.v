// ---------------------------------------------------------------------------
// tb_mlkem_b_top_real.v -- 真实 HLS RTL 验证 (真实 UART 快速版)
//
// 用真实 UART 模块接收 (不 force 内部信号), 但波特率 10 倍速 (1.152M)
// 缩短仿真时间 (2400B @1.152M ≈ 20.8ms)。验证:
//   - top.v 完整 UART + 握手 + 真实 HLS RTL 解密
//   - 输出 ss == KAT_SS
//
// 编译 (必须在 HLS verilog 目录, .dat 相对路径):
//   cd mlkem_artix7_ab_b/xc7a100t_100mhz/syn/verilog
//   iverilog -g2012 -s tb_mlkem_b_top_real <tb> <top> <uart_rx> <uart_tx> \
//      <wrapper> <keccak_ip> <keccak_round> *.v
//   vvp a.out
// ---------------------------------------------------------------------------
`timescale 1ns/1ps

module tb_mlkem_b_top_real;
    reg clk = 0;
    reg rst_n = 0;
    reg uart_rx = 1;
    wire uart_tx;
    wire led;

    always #10 clk = ~clk;   // 50MHz

    mlkem_b_top_uart #(
        .CLK_FREQ  (50_000_000),
        .BAUD_RATE (1_152_000)      // 10 倍速, 缩短仿真
    ) dut (
        .clk_50m (clk),
        .rst_n   (rst_n),
        .uart_rx (uart_rx),
        .uart_tx (uart_tx),
        .led     (led)
    );

    // ---- KAT 向量 ----
    reg [7:0] inp [0:2399];   // ct[768] + sk[1632]
    reg [7:0] exp [0:31];
    integer i;
    initial begin
        $readmemh("input_bytes.dat", inp);
        $readmemh("expected_ss.dat", exp);
        $display("[tb] loaded input (%0d) + expected ss (%0d)", 2400, 32);
    end

    // ---- 真实 UART 发送 (1.152Mbps, 1 bit = 868ns) ----
    task send_byte(input [7:0] d);
        integer bi;
        begin
            @(posedge clk);
            uart_rx = 0;  #868;   // start
            for (bi = 0; bi < 8; bi = bi + 1) begin
                uart_rx = d[bi];  #868;
            end
            uart_rx = 1;  #868;   // stop
        end
    endtask

    // ---- polyvec_decompress 写回监控 (诊断) ----
    integer pv_n = 0;
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_we0) begin
            if (pv_n < 8) $display("[pvdec] W0 t=%0t adr=%0d val=%0d",
                $time,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_address0,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_d0);
            pv_n = pv_n + 1;
        end
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_we1) begin
            if (pv_n < 8) $display("[pvdec] W1 t=%0t adr=%0d val=%0d",
                $time,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_address1,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_polyvec_decompress_fu_243.vec2_d1);
            pv_n = pv_n + 1;
        end
    end

    // ---- poly_frombytes (state3, dec s_hat) 读 sk 采样 ----
    integer fb_n = 0;
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd4) begin  // state3
            if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.grp_poly_frombytes_Pipeline_VITIS_LOOP_11_1_fu_30.a_ce0 && fb_n < 12) begin
                $display("[fb] t=%0t a_adr0=%0d a_q0=%02x a_adr1=%0d a_q1=%02x r_adr=%0d r_we=%b r_d0=%0d",
                    $time,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.grp_poly_frombytes_Pipeline_VITIS_LOOP_11_1_fu_30.a_address0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.grp_poly_frombytes_Pipeline_VITIS_LOOP_11_1_fu_30.a_q0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.grp_poly_frombytes_Pipeline_VITIS_LOOP_11_1_fu_30.a_address1,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.grp_poly_frombytes_Pipeline_VITIS_LOOP_11_1_fu_30.a_q1,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.r_address0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.r_we0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.grp_poly_frombytes_fu_232.r_d0);
                fb_n = fb_n + 1;
            end
        end
    end

    // ---- dec mp 采样 (state17 时 poly1 = v - INTT(s_hat^T*u_hat)) ----
    integer mp_n = 0;
    reg  mp_captured = 0;
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd65536 && !mp_captured) begin  // state17
            $display("[mp] t=%0t poly1[0..7] = %0d %0d %0d %0d %0d %0d %0d %0d",
                $time,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[0],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[1],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[2],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[3],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[4],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[5],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[6],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[7]);
            mp_captured = 1;
        end
    end

    // ---- basemul 累加采样 (state12/13/14 时 poly1 = s_hat^T*u_hat 未 INTT) ----
    integer acc_cnt = 0;
    reg [15:0] acc_prev [0:7];
    integer ai;
    initial for (ai = 0; ai < 8; ai = ai + 1) acc_prev[ai] = 16'hFFFF;
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd4096 ||   // state12
            dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd8192 ||   // state13
            dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd16384) begin  // state14
            if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[0] !== acc_prev[0] && acc_cnt < 6) begin
                $display("[acc] t=%0t state=%0d poly1[0..7] = %0d %0d %0d %0d %0d %0d %0d %0d",
                    $time,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[0],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[1],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[2],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[3],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[4],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[5],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[6],
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[7]);
                acc_cnt = acc_cnt + 1;
                for (ai = 0; ai < 8; ai = ai + 1) acc_prev[ai] = dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[ai];
            end
        end
    end

    // ---- poly1_U port0/port1 写事件精确跟踪 (state12/13/14, 定位累加冲突) ----
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd4096 ||   // state12
            dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd8192 ||   // state13
            dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm == 80'd16384) begin  // state14
            if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_we0) begin
                $display("[p1w0] t=%0t st=%0d addr0=%0d d0=%0d  (q0=%0d) ram0=%0d",
                    $time, dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_address0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_d0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_q0,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[0]);
            end
            if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_we1) begin
                $display("[p1w1] t=%0t st=%0d addr1=%0d d1=%0d  ram0=%0d",
                    $time, dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_address1,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_d1,
                    dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[0]);
            end
        end
    end

    // ---- vec2_U.ram[0] 变化监控 (定位 267->2112) ----
    reg [15:0] prev_v2r0 = 16'hxxxx;
    always @(posedge clk) begin
        if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_U.ram[0] !== prev_v2r0) begin
            $display("[v2ram0] t=%0t ram[0]=%0d (0x%04x)  state=%0d  we0=%b we1=%b addr0=%0d addr1=%0d d0=%0d",
                $time,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_U.ram[0],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_U.ram[0],
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.ap_CS_fsm,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_we0,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_we1,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_address0,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_address1,
                dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_d0);
            prev_v2r0 = dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_U.ram[0];
        end
    end

    // ---- UART TX 捕获 ----
    reg prev_tx = 1;
    reg capt = 0;
    reg [15:0] baud = 0;
    reg [3:0] bitc = 0;
    reg [7:0] rshift = 0;
    integer rx_count = 0;
    reg [7:0] rxf [0:31];
    localparam BAUD_DIV = 43;    // 50M / 1.152M
    localparam HALF = 21;
    always @(posedge clk) begin
        prev_tx <= uart_tx;
        if (!capt && !uart_tx && prev_tx) begin capt <= 1; baud <= 0; bitc <= 0; end
        if (capt) begin
            if (bitc == 0) begin
                if (baud == HALF - 1) begin
                    if (!uart_tx) begin baud <= 0; bitc <= 1; end
                    else capt <= 0;
                end else baud <= baud + 1;
            end else begin
                if (baud == BAUD_DIV - 1) begin
                    baud <= 0;
                    if (bitc >= 1 && bitc <= 8) rshift[bitc-1] <= uart_tx;
                    bitc <= bitc + 1;
                    if (bitc == 9) begin
                        capt <= 0;
                        rxf[rx_count] <= rshift;
                        rx_count <= rx_count + 1;
                    end
                end else baud <= baud + 1;
            end
        end
    end

    // ---- 主流程 (端口注入快速版: force uart_rx_done/data) ----
    integer b;
    initial begin
        rst_n = 0;
        #200;
        rst_n = 1;
        #200;

        $display("[tb] injecting 0xAA + 2400B via force...");
        force dut.uart_rx_data = 8'hAA;
        force dut.uart_rx_done = 1'b1;
        #20;
        force dut.uart_rx_done = 1'b0;
        #20;

        for (b = 0; b < 2400; b = b + 1) begin
            force dut.uart_rx_data = inp[b];
            force dut.uart_rx_done = 1'b1;
            #20;
            force dut.uart_rx_done = 1'b0;
            #20;
        end
        release dut.uart_rx_data;
        release dut.uart_rx_done;
        $display("[tb] injected. waiting for ML-KEM (led=1 means done)...");

        // 等计算完成 (led 拉高 = 解密成功, 状态机走完)
        while (!led) #1000;
        #2000;
        $display("=========== REAL RTL SIM RESULT ===========");
        $display("led = %b", led);
        // 读 out_mem 比对
        begin : chk
            integer m;
            integer mismatch;
            mismatch = 0;
            for (i = 0; i < 8; i = i + 1)
                $display("[tb] out_mem[%0d] = %08x", i, dut.out_mem[i]);
            $display("期望 ss:");
            for (m = 0; m < 32; m = m + 1) $write("%02x", exp[m]);
            $display("");
            for (m = 0; m < 32; m = m + 1) begin
                if (dut.out_mem[m/4][(m%4)*8 +: 8] !== exp[m]) begin
                    $display("  MISMATCH byte %0d: got %02x exp %02x", m,
                             dut.out_mem[m/4][(m%4)*8 +: 8], exp[m]);
                    mismatch = 1;
                end
            end
            if (!mismatch) $display("==> PASS: out_mem ss 与 KAT 一致!");
            else $display("==> FAIL");

            // 穿透层次抓 dec/re-encrypt 中间值:
            //   buf_U[0..31] = m' (dec 输出消息), buf_U[32..63] = H(pk)
            //   cmp_U[0..767] = re-encrypt 输出 (应与输入 ct 逐字节相等)
            $display("--- [diag] buf_U (m' || H(pk)) ---");
            for (m = 0; m < 64; m = m + 4)
                $display("buf[%0d..%0d] = %02x%02x%02x%02x", m, m+3,
                         dut.u_mlkem.grp_crypto_kem_dec_fu_91.buf_U.ram[m+0],
                         dut.u_mlkem.grp_crypto_kem_dec_fu_91.buf_U.ram[m+1],
                         dut.u_mlkem.grp_crypto_kem_dec_fu_91.buf_U.ram[m+2],
                         dut.u_mlkem.grp_crypto_kem_dec_fu_91.buf_U.ram[m+3]);
            $display("--- [diag] cmp_U (re-encrypt ct') vs input ct ---");
            begin : cmpchk
                integer c, cmm;
                cmm = 0;
                for (c = 0; c < 768; c = c + 4) begin
                    if (dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+0] != inp[c+0] ||
                        dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+1] != inp[c+1] ||
                        dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+2] != inp[c+2] ||
                        dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+3] != inp[c+3]) begin
                        if (cmm < 8)
                            $display("  cmp[%0d]=%02x%02x%02x%02x ct[%0d]=%02x%02x%02x%02x",
                                     c,
                                     dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+0],
                                     dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+1],
                                     dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+2],
                                     dut.u_mlkem.grp_crypto_kem_dec_fu_91.cmp_U.ram[c+3],
                                     c, inp[c+0], inp[c+1], inp[c+2], inp[c+3]);
                        cmm = 1;
                    end
                end
                if (!cmm) $display("  cmp_U == input ct (768B ALL MATCH)");
                else $display("  cmp_U MISMATCH (>=%0d diffs)", cmm);
            end

            // 穿透层次抓 dec 路径中间数组 (与 C 对拍):
            //   vec1_U = s_hat (512 entry, K=2), vec2_U = u, dec_v_U = v, poly1_U = mp
            $display("--- [diag] vec1_U = s_hat ---");
            for (m = 0; m < 8; m = m + 1)
                $display("  s_hat[%0d] = %0d", m, $signed(dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec1_U.ram[m]));
            $display("--- [diag] vec2_U = u (0..255) ---");
            for (m = 0; m < 8; m = m + 1)
                $display("  u[%0d] = %0d", m, $signed(dut.u_mlkem.grp_crypto_kem_dec_fu_91.vec2_U.ram[m]));
            $display("--- [diag] dec_v_U = v ---");
            for (m = 0; m < 8; m = m + 1)
                $display("  v[%0d] = %0d", m, dut.u_mlkem.grp_crypto_kem_dec_fu_91.dec_v_U.ram[m]);
            $display("--- [diag] poly1_U = mp (0..255) ---");
            for (m = 0; m < 8; m = m + 1)
                $display("  mp[%0d] = %0d", m, $signed(dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly1_U.ram[m]));
            $display("--- [diag] poly2_U (0..255) ---");
            for (m = 0; m < 8; m = m + 1)
                $display("  poly2[%0d] = %0d", m, $signed(dut.u_mlkem.grp_crypto_kem_dec_fu_91.poly2_U.ram[m]));

            // 对拍 l_ct (ct 解包) 与输入
            $display("--- [diag] l_ct vs input ct ---");
            begin : ctchk
                integer cc, ccm;
                ccm = 0;
                for (cc = 0; cc < 768; cc = cc + 1) begin
                    if (dut.u_mlkem.l_ct_U.ram[cc[7:0]] != inp[cc]) begin
                        if (ccm < 8)
                            $display("  l_ct[%0d] = %02x (exp %02x)",
                                     cc, dut.u_mlkem.l_ct_U.ram[cc[7:0]], inp[cc]);
                        ccm = 1;
                    end
                end
                if (!ccm) $display("  l_ct == input ct (768B ALL MATCH)");
                else $display("  l_ct MISMATCH (>=%0d diffs)", ccm);
            end
        end
        $display("[tb] HLS_RD total=%0d min=%0d max=%0d x-count=%0d last_addr=%0d",
                 rd_trace, rd_min, rd_max, rd_xcnt, last_rd_addr);
        $display("==========================================");
        $finish;
    end

    // 超时
    initial begin
        #120_000_000;
        $display("!! TIMEOUT");
        $finish;
    end

    // 调试: state 变化
    reg [2:0] last_state;
    always @(posedge clk) begin
        last_state <= dut.state;
        if (dut.state != last_state)
            $display("[%0t] state -> %0d", $time, dut.state);
    end

    // 调试: 监视 HLS 写 out_data (应 8 个 word)
    always @(posedge clk) begin
        if (dut.out_data_WEN_A != 4'b0) begin
            $display("[%0t] OUT_WR addr=%0d din=%08x we=%b", $time,
                     dut.out_data_Addr_A[5:2], dut.out_data_Din_A, dut.out_data_WEN_A);
        end
    end

    // 调试: HLS 读 in_data 统计 + 检测 x 数据
    integer rd_trace = 0;
    integer rd_min = 600, rd_max = 0, rd_xcnt = 0;
    reg [9:0] last_rd_addr;
    always @(posedge clk) begin
        if (dut.in_data_EN_A) begin
            if (rd_trace < 12) begin
                $display("[%0t] HLS_RD addr=%0d (>>2) data=%08x",
                         $time, dut.in_data_Addr_A[11:2], dut.in_data_Dout_A);
            end
            if (dut.in_data_Addr_A[11:2] < rd_min) rd_min = dut.in_data_Addr_A[11:2];
            if (dut.in_data_Addr_A[11:2] > rd_max) rd_max = dut.in_data_Addr_A[11:2];
            if (dut.in_data_Dout_A === 32'bx) rd_xcnt = rd_xcnt + 1;
            last_rd_addr = dut.in_data_Addr_A[11:2];
            rd_trace <= rd_trace + 1;
        end
    end
    // 统计打印由主流程 chk 块末尾调用 (见下)
endmodule
