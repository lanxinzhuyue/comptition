// tb_polyvec_decompress_wave.v
// 单元级: 直接例化 polyvec_decompress + l_ct BRAM, 用 input_bytes.dat 的
// ct[0:767] 驱动。跑 128 迭代, dump r_address0/1, r_q0/1, 各 mac dout,
// vec2 写地址/数据 到 VCD, 用 iverilog + gtkwave 分析地址<->数据对齐。
`timescale 1ns/1ps

module tb_polyvec_decompress_wave;
    reg clk = 0;
    reg rst = 0;
    reg ap_start = 0;
    wire ap_done, ap_idle, ap_ready;

    // ---- l_ct BRAM (单 RAM, 2 读口) ----
    wire [7:0] ct_q0, ct_q1;
    reg  [9:0] ct_addr0, ct_addr1;      // 载入用
    reg        ct_ce0, ct_ce1, ct_we0, ct_we1;
    reg  [7:0] ct_d0, ct_d1;
    reg  load_done = 0;
    wire [9:0] rd_addr0 = dut.r_address0;
    wire [9:0] rd_addr1 = dut.r_address1;

    mlkem_b_top_l_ct_RAM_AUTO_1R1W #(
        .DataWidth(8), .AddressRange(768), .AddressWidth(10))
    l_ct_U(
        .clk(clk), .reset(rst),
        .address0(load_done ? rd_addr0 : ct_addr0),
        .ce0(load_done ? r_ce0 : ct_ce0),
        .we0(load_done ? 1'b0 : ct_we0), .d0(ct_d0), .q0(ct_q0),
        .address1(load_done ? rd_addr1 : ct_addr1),
        .ce1(load_done ? r_ce1 : ct_ce1),
        .we1(load_done ? 1'b0 : ct_we1), .d1(ct_d1), .q1(ct_q1));

    // ---- DUT ----
    wire [9:0] r_address0, r_address1;
    wire       r_ce0, r_ce1;
    wire [8:0] vec2_address0, vec2_address1;
    wire       vec2_ce0, vec2_we0, vec2_ce1, vec2_we1;
    wire [15:0] vec2_d0, vec2_d1;

    mlkem_b_top_polyvec_decompress dut(
        .ap_clk(clk), .ap_rst(rst),
        .ap_start(ap_start), .ap_done(ap_done), .ap_idle(ap_idle), .ap_ready(ap_ready),
        .r_address0(r_address0), .r_ce0(r_ce0), .r_q0(ct_q0),
        .r_address1(r_address1), .r_ce1(r_ce1), .r_q1(ct_q1),
        .vec2_address0(vec2_address0), .vec2_ce0(vec2_ce0), .vec2_we0(vec2_we0), .vec2_d0(vec2_d0),
        .vec2_address1(vec2_address1), .vec2_ce1(vec2_ce1), .vec2_we1(vec2_we1), .vec2_d1(vec2_d1));

    always #10 clk = ~clk;  // 50MHz

    // ---- 复位 ----
    initial begin
        rst = 1;
        #100;
        @(negedge clk); rst = 0;
    end

    // ---- ct 数据 ----
    reg [7:0] ct [0:2399];
    reg [7:0] vec2 [0:255];
    integer cc, wc;
    initial begin
        $readmemh("input_bytes.dat", ct);
        // 等复位结束
        wait (rst === 1'b0);
        // 载入到 BRAM (在 negedge 设置, 下一个 posedge 写入)
        for (cc = 0; cc < 768; cc = cc + 1) begin
            @(negedge clk);
            ct_addr0 = cc[9:0]; ct_ce0 = 1; ct_we0 = 1; ct_d0 = ct[cc];
            ct_addr1 = 0; ct_ce1 = 0; ct_we1 = 0; ct_d1 = 0;
        end
        @(negedge clk);   // 等最后一个 posedge 把第 768 字节写进 ram
        ct_we0 = 0;
        // 验证读回首字节 (load_done 仍=0, 地址仍由 ct_addr0 控制)
        @(negedge clk);
        ct_addr0 = 0; ct_ce0 = 1;
        #10;
        $display("[tb] verify q0 addr0=0: %02x (expect %02x)", ct_q0, ct[0]);
        ct_ce0 = 0;
        @(negedge clk);
        load_done = 1;
        $display("[tb] ct loaded, %0d bytes @ %0t", 768, $time);
    end

    // ---- 启动 ----
    initial begin
        wait (rst === 1'b0);
        wait (load_done === 1'b1);
        #40;
        @(negedge clk); ap_start = 1;
        wait (ap_done === 1'b1);
        @(negedge clk); ap_start = 0;
        $display("[tb] done at %0t", $time);
        #200;
        // 打印 vec2 前 16 个 16-bit 结果
        for (wc = 0; wc < 16; wc = wc + 1)
            $display("vec2[%0d] = %0d (0x%04x)", wc, vec2[wc], vec2[wc]);
        $finish;
    end

    // ---- 捕获写回 vec2 ----
    always @(posedge clk) begin
        if (vec2_we0) vec2[vec2_address0] <= vec2_d0[15:0];
        if (vec2_we1) vec2[vec2_address1] <= vec2_d1[15:0];
    end

    // ---- 打印写回时刻的采样现场 (自证) ----
    integer wc_n;
    reg [7:0] last_q0, last_q1;
    reg [9:0] last_a0, last_a1;
    always @(posedge clk) begin
        last_q0 <= ct_q0; last_q1 <= ct_q1;
        last_a0 <= r_address0; last_a1 <= r_address1;
        if (vec2_we0) $display("t=%0t W0 adr=%0d val=%0d | addr0=%0d addr1=%0d q0=%0d q1=%0d",
            $time, vec2_address0, vec2_d0, r_address0, r_address1, ct_q0, ct_q1);
        if (vec2_we1) $display("t=%0t W1 adr=%0d val=%0d | addr0=%0d addr1=%0d q0=%0d q1=%0d",
            $time, vec2_address1, vec2_d1, r_address0, r_address1, ct_q0, ct_q1);
    end

    // ---- VCD ----
    initial begin
        $dumpfile("pvdec_wave.vcd");
        $dumpvars(0, tb_polyvec_decompress_wave);
    end
endmodule
