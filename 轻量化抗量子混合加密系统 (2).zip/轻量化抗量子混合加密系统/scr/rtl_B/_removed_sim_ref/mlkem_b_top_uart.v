// ---------------------------------------------------------------------------
// mlkem_b_top_uart.v -- ML-KEM-512 B 板 (Decaps) 最小闭环上板顶层
//
// 功能: 通过 UART RX 接收 2400 字节 (ct[768] + sk[1632]),
//       写入内部 BRAM, 启动 HLS ML-KEM Decaps IP,
//       从 out_data BRAM 读回 32 字节 ss, 经 UART TX 发回 PC。
//
// 随机性: implicit rejection 的 z (sk 末尾 32B) 由板载 TRNG + SHAKE256
//         后处理产生 (与 A 板同源)。收包完成后 S_SHAKE 态用 z_rand
//         覆盖 in_mem[592..599] (sk 末尾 z)。PC 协议不变 (仍发 2400B),
//         但 sk 末尾 z 以板载随机源为准。
//
// 对外 IO (只有这些):
//   clk_50m  : 板上时钟 (默认 50MHz; 若板为 40MHz 请把 CLK_FREQ 改为 40000000)
//   rst_n    : 复位 (低有效)
//   uart_rx  : 串口接收 (PC -> FPGA)
//   uart_tx  : 串口发送 (FPGA -> PC)
//   led      : 状态指示 (解密完成且已发回时点亮)
//
// UART 协议 (115200-8N1, 与 PC 串口助手):
//   发送: [0xAA][ct:768B][sk:1632B]  共 2401 字节
//   返回: [ss:32B]
//
// 对接 HLS IP (bram 接口 + ap_ctrl_hs):
//   in_data_*  : in_data[600]  uint32  (ct 192 word + sk 408 word, 小端)
//   out_data_* : out_data[8]   uint32  (ss 32 字节, 小端)
//   ap_start/ap_done/ap_idle/ap_ready
//
// 依赖: source4/uart_rx.v, source4/uart_tx.v (CLK_FREQ 参数化),
//        source4/shake256_rand.v, source4/trng_pdl_top.v, source4/keccak_f1600_core.v,
//        source4/keccak_round.v
// ---------------------------------------------------------------------------
module mlkem_b_top_uart #(
    parameter CLK_FREQ     = 50_000_000,   // 时钟频率 (Hz)
    parameter BAUD_RATE    = 115_200,      // 波特率
    parameter INPUT_BYTES  = 2400,         // ct(768) + sk(1632)
    parameter INPUT_WORDS  = 600,          // 2400 / 4
    parameter OUTPUT_BYTES = 32,           // ss
    parameter OUTPUT_WORDS = 8             // 32 / 4
) (
    input  wire clk_50m,
    input  wire rst_n,
    input  wire uart_rx,
    output wire uart_tx,
    output reg  led
);

    // ==================================================================
    // 1. UART 收发 (source4, 参数化时钟)
    // ==================================================================
    wire        uart_rx_done;
    wire [7:0]  uart_rx_data;
    wire        uart_tx_busy;
    reg         uart_tx_en;
    reg  [7:0]  uart_tx_data;

    uart_rx #(
        .CLK_FREQ (CLK_FREQ),
        .UART_BPS (BAUD_RATE)
    ) u_rx (
        .clk          (clk_50m),
        .rst_n        (rst_n),
        .uart_rxd     (uart_rx),
        .uart_rx_done (uart_rx_done),
        .uart_rx_data (uart_rx_data)
    );

    uart_tx #(
        .CLK_FREQ (CLK_FREQ),
        .UART_BPS (BAUD_RATE)
    ) u_tx (
        .clk          (clk_50m),
        .rst_n        (rst_n),
        .uart_tx_en   (uart_tx_en),
        .uart_tx_data (uart_tx_data),
        .uart_txd     (uart_tx),
        .uart_tx_busy (uart_tx_busy)
    );

    // ==================================================================
    // 1b. TRNG + SHAKE256 后处理 (implicit rejection 的 z 随机源)
    //     mix_seed = trng_seed ^ seed_proto, 本板 seed_proto 固定 0
    //     z_rand = shake_out[511:256] (后 32B)
    //     与 A 板 (mlkem_a_top_rand_uart.v) 同源同构
    // ==================================================================
    wire [255:0] trng_seed;
    wire         trng_rand_bit;
    trng_pdl_top u_trng (
        .clk       (clk_50m),
        .rst_n     (rst_n),
        .seed      (trng_seed),
        .rand_bit  (trng_rand_bit)
    );

    wire [255:0] mix_seed = trng_seed;   // seed_proto 固定 0

    reg         shake_go;
    wire        shake_busy;
    wire [511:0] shake_out;
    wire        shake_valid;
    shake256_rand u_shake (
        .clk    (clk_50m),
        .rst_n  (rst_n),
        .go     (shake_go),
        .seed   (mix_seed),
        .busy   (shake_busy),
        .valid  (shake_valid),
        .out    (shake_out)
    );

    wire [255:0] z_rand = shake_out[511:256];   // implicit rejection z
    reg  [7:0]   z_wr_cnt;   // 0..7, 写 z 的 8 word 计数
    reg          z_wr_we;    // z 写脉冲 (持续 8 拍)
    reg  [31:0]  z_wr_word;
    // z_rand 8 个 32-bit LE word
    wire [31:0]  z_word [0:7];
    genvar gz;
    generate
        for (gz = 0; gz < 8; gz = gz + 1) begin : g_zword
            assign z_word[gz] = z_rand[gz*32 +: 32];
        end
    endgenerate

    // ==================================================================
    // 2. 输入 BRAM (in_data): 32-bit x 1024, 用户逻辑收包写入,
    //                          HLS IP 启动后经 bram 接口读出
    // ==================================================================
    reg  [31:0] in_mem [0:1023];
    reg  [9:0]  in_mem_addr;
    reg         in_mem_we;
    reg  [31:0] in_mem_din;
    reg  [31:0] in_mem_dout;
    // 上电复位时给 in_mem_dout 赋 0, 避免 HLS 第一次读 (addr=0) 采到 x
    // HLS bram 接口: iter0 发地址/EN, iter1 采样 Dout -> 同步读 1 拍延迟是正确时序
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n)
            in_mem_dout <= 32'b0;
        else begin
            if (in_mem_we) in_mem[in_mem_addr] <= in_mem_din;
            in_mem_dout <= in_mem[in_mem_addr];
        end
    end

    // ==================================================================
    // 3. 输出 BRAM (out_data): 32-bit x 16, HLS IP 写, 用户逻辑读
    // ==================================================================
    reg  [31:0] out_mem [0:15];
    reg  [3:0]  out_mem_addr;
    reg         out_mem_we;
    reg  [31:0] out_mem_din;
    reg  [31:0] out_mem_dout;
    always @(posedge clk_50m) begin
        if (out_mem_we) out_mem[out_mem_addr] <= out_mem_din;
        out_mem_dout <= out_mem[out_mem_addr];
    end

    // ==================================================================
    // 4. HLS ML-KEM Decaps IP (bram 接口 + ap_ctrl_hs)
    // ==================================================================
    wire [31:0] in_data_Dout_A;
    wire        in_data_Clk_A, in_data_Rst_A;
    wire [31:0] in_data_Addr_A;
    wire        in_data_EN_A;
    wire [3:0]  in_data_WEN_A;
    wire [31:0] in_data_Din_A;

    wire [31:0] out_data_Dout_A;
    wire        out_data_Clk_A, out_data_Rst_A;
    wire [31:0] out_data_Addr_A;
    wire        out_data_EN_A;
    wire [3:0]  out_data_WEN_A;
    wire [31:0] out_data_Din_A;

    reg         ap_start_r;
    wire        ap_done, ap_idle, ap_ready;

    mlkem_b_top u_mlkem (
        .ap_clk         (clk_50m),
        .ap_rst         (~rst_n),       // HLS ap_rst 高有效
        .ap_start       (ap_start_r),
        .ap_done        (ap_done),
        .ap_idle        (ap_idle),
        .ap_ready       (ap_ready),
        .in_data_Addr_A (in_data_Addr_A),
        .in_data_EN_A   (in_data_EN_A),
        .in_data_WEN_A  (in_data_WEN_A),
        .in_data_Din_A  (in_data_Din_A),
        .in_data_Dout_A (in_data_Dout_A),
        .in_data_Clk_A  (in_data_Clk_A),
        .in_data_Rst_A  (in_data_Rst_A),
        .out_data_Addr_A(out_data_Addr_A),
        .out_data_EN_A  (out_data_EN_A),
        .out_data_WEN_A (out_data_WEN_A),
        .out_data_Din_A (out_data_Din_A),
        .out_data_Dout_A(out_data_Dout_A),
        .out_data_Clk_A (out_data_Clk_A),
        .out_data_Rst_A (out_data_Rst_A)
    );
    assign in_data_Clk_A  = clk_50m;
    assign in_data_Rst_A  = ~rst_n;
    assign out_data_Clk_A = clk_50m;
    assign out_data_Rst_A = ~rst_n;

    // 端口分时复用 (MUX):
    //   S_RX        : in_mem 由用户逻辑写 (收包)
    //   S_SHAKE     : in_mem 由 z 写逻辑写 (覆盖 sk 末尾 z)
    //   其他状态    : in_mem 地址/使能来自 HLS IP
    //   S_READ      : out_mem 由用户逻辑读 (读 ss)
    //   其他状态    : out_mem 地址/写使能来自 HLS IP
    localparam [3:0] S_IDLE   = 4'd0;  // 等帧头 0xAA
    localparam [3:0] S_RX     = 4'd1;  // 收 2400 字节 -> in_mem
    localparam [3:0] S_SHAKE  = 4'd2;  // 等 SHAKE256, 覆盖 z 到 in_mem[592..599]
    localparam [3:0] S_LAUNCH = 4'd3;  // 拉 ap_start
    localparam [3:0] S_RUN    = 4'd4;  // 等 ap_done
    localparam [3:0] S_READ   = 4'd5;  // out_mem 8 word -> ss_buf
    localparam [3:0] S_TX     = 4'd6;  // UART 发 32 字节 ss
    localparam [3:0] S_DONE   = 4'd7;  // 完成, LED 亮

    reg [3:0]  state;
    reg [11:0] rx_byte_cnt;   // 0..2399
    reg [9:0]  wr_word_cnt;   // 当前组 word 目标地址 0..599
    reg        wr_we;         // 组 word 写脉冲 (寄存到下一拍写)
    reg [31:0] wr_word_data;  // 组好的 word
    reg [7:0]  rx_buf [0:3];  // 收包 4 字节暂存
    reg [3:0]  rd_addr;       // S_READ 读地址 0..7
    reg        rd_valid;
    reg [7:0]  ss_buf [0:31]; // 32 字节 ss
    reg [5:0]  tx_cnt;        // 0..31

    // --- in_mem 端口 MUX ---
    // HLS bram 接口 Addr_A 是 32-bit 字节地址 (每 word 占 4 字节地址),
    // 故取 word 索引需 >> 2
    always @(*) begin
        // S_RX + S_LAUNCH 都允许写 in_mem:
        // 最后一字节 (rx_byte_cnt==INPUT_BYTES-1) 时 wr_we=1 且 state->S_LAUNCH,
        // 若 S_LAUNCH 不写, 最后一 word (in_mem[599]) 会丢失 -> HLS 读 z 得 x.
        if (state == S_RX || state == S_LAUNCH) begin
            in_mem_addr = wr_word_cnt;
            in_mem_we   = wr_we;
            in_mem_din  = wr_word_data;
        end else if (state == S_SHAKE) begin
            // 覆盖 sk 末尾 z: in_mem[592..599] = z_rand (8 word)
            // sk 起始 word 索引 192, 末尾 z 占 8 word -> 192+408-8 = 592
            in_mem_addr = z_wr_cnt + 10'd592;
            in_mem_we   = z_wr_we;
            in_mem_din  = z_wr_word;
        end else begin
            in_mem_addr = in_data_Addr_A[11:2];   // 字节地址 >> 2
            in_mem_we   = 1'b0;
            in_mem_din  = 32'b0;
        end
    end
    assign in_data_Dout_A = in_mem_dout;

    // --- out_mem 端口 MUX (HLS 用 WEN[3:0] 字节使能) ---
    // HLS 写 out_data 也用字节地址 (每 word 占 4), 取 word 索引需 >> 2
    always @(*) begin
        if (state == S_READ) begin
            out_mem_addr = rd_addr;
            out_mem_we   = 1'b0;
            out_mem_din  = 32'b0;
        end else begin
            out_mem_addr = out_data_Addr_A[5:2];   // 字节地址 >> 2 (0..7)
            out_mem_we   = (out_data_WEN_A != 4'b0);   // 任一字节使能有效即写
            out_mem_din  = out_data_Din_A;
        end
    end
    assign out_data_Dout_A = 32'b0;   // HLS IP 不读 out_data

    // ==================================================================
    // 5. 主状态机
    // ==================================================================
    always @(posedge clk_50m or negedge rst_n) begin
        if (!rst_n) begin
            state       <= S_IDLE;
            rx_byte_cnt <= 0;
            wr_word_cnt <= 0;
            wr_we       <= 0;
            wr_word_data<= 0;
            rd_addr     <= 0;
            rd_valid    <= 0;
            tx_cnt      <= 0;
            ap_start_r  <= 1'b0;
            uart_tx_en  <= 1'b0;
            uart_tx_data<= 8'd0;
            shake_go    <= 1'b0;
            z_wr_cnt    <= 8'd0;
            z_wr_we     <= 1'b0;
            z_wr_word   <= 32'd0;
            led         <= 1'b0;
        end else begin
            uart_tx_en <= 1'b0;   // 默认关发送脉冲
            wr_we      <= 1'b0;   // 默认关组 word 写

            case (state)
                // ---------------- S_IDLE: 等帧头 ----------------
                S_IDLE: begin
                    if (uart_rx_done && uart_rx_data == 8'hAA) begin
                        led         <= 1'b0;   // 新一帧开始, 清 LED
                        state       <= S_RX;
                        rx_byte_cnt <= 0;
                    end
                end

                // ---------------- S_RX: 收 2400 字节 ----------------
                S_RX: begin
                    if (uart_rx_done) begin
                        // 存当前字节到 word 暂存
                        rx_buf[rx_byte_cnt[1:0]] <= uart_rx_data;
                        // 每 4 字节组 1 个 word, 锁存到 wr_* (下一拍写 in_mem)
                        if (rx_byte_cnt[1:0] == 2'd3) begin
                            wr_we        <= 1'b1;
                            wr_word_cnt  <= rx_byte_cnt[11:2];
                            // LE 组包: {b3,b2,b1,b0} = {ct[3],ct[2],ct[1],ct[0]}
                        // 字节到达顺序: b0 先到 (rx_buf[0]=b0, rx_buf[1]=b1, rx_buf[2]=b2, 当前=b3)
                            wr_word_data <= {uart_rx_data, rx_buf[2], rx_buf[1], rx_buf[0]};
                        end
                        // 最后一字节: 收完, 拉 shake_go 一拍, 进入 S_SHAKE
                        if (rx_byte_cnt == INPUT_BYTES - 1) begin
                            shake_go <= 1'b1;
                            state    <= S_SHAKE;
                        end
                        rx_byte_cnt <= rx_byte_cnt + 1'b1;
                    end
                end

                // ---------------- S_SHAKE: 等 SHAKE256 出 z, 覆盖 in_mem[592..599] ----------------
                // shake_go 已在 S_RX 收尾拍拉高 1 拍 (进入本态前), 此处不再拉, 避免重复触发
                // 时序: 等 shake_valid 后 z_wr_we 持续 8 拍写 8 word
                //   拍0: shake_valid -> z_wr_we<=1, z_wr_word<=z_word[0], z_wr_cnt<=0
                //   拍1: MUX 写 in_mem[592]=z_word[0]; FSM cnt->1, word<=z_word[1]
                //   ...
                //   拍8: MUX 写 in_mem[599]=z_word[7]; FSM we->0, state->S_LAUNCH
                S_SHAKE: begin
                    shake_go <= 1'b0;   // 清 go (防残留, 避免 SHAKE 重复触发覆盖 shake_out)
                    if (shake_valid) begin
                        z_wr_we   <= 1'b1;
                        z_wr_word <= z_word[0];
                        z_wr_cnt  <= 8'd0;
                    end else if (z_wr_we) begin
                        if (z_wr_cnt == 8'd7) begin
                            z_wr_we   <= 1'b0;
                            state     <= S_LAUNCH;
                        end else begin
                            z_wr_cnt  <= z_wr_cnt + 1'b1;
                            z_wr_word <= z_word[z_wr_cnt + 1'b1];
                        end
                    end
                end

                // ---------------- S_LAUNCH: 拉 ap_start ----------------
                // ap_start 保持高直到 ap_done (HLS 标准握手: 高电平有效, 采样后内部开始)
                S_LAUNCH: begin
                    ap_start_r <= 1'b1;
                    state      <= S_RUN;
                end

                // ---------------- S_RUN: 等 ap_done ----------------
                S_RUN: begin
                    if (ap_done) begin
                        ap_start_r <= 1'b0;
                        state    <= S_READ;
                        rd_addr  <= 4'd0;
                        rd_valid <= 1'b0;
                    end
                end

                // ---------------- S_READ: 读 out_mem 8 word -> ss_buf ----------------
                S_READ: begin
                    if (!rd_valid) begin
                        rd_valid <= 1'b1;   // 地址 0 已就绪, 等 1 拍 BRAM 输出
                    end else begin
                        // 此刻 out_mem_dout = out_mem[rd_addr]
                        ss_buf[{rd_addr, 2'b00} + 3] <= out_mem_dout[31:24];
                        ss_buf[{rd_addr, 2'b00} + 2] <= out_mem_dout[23:16];
                        ss_buf[{rd_addr, 2'b00} + 1] <= out_mem_dout[15:8];
                        ss_buf[{rd_addr, 2'b00} + 0] <= out_mem_dout[7:0];
                        if (rd_addr == OUTPUT_WORDS - 1) begin
                            state  <= S_TX;
                            tx_cnt <= 6'd0;
                        end else begin
                            rd_addr <= rd_addr + 4'd1;
                        end
                    end
                end

                // ---------------- S_TX: 发 32 字节 ss ----------------
                S_TX: begin
                    if (!uart_tx_busy) begin
                        uart_tx_en   <= 1'b1;
                        uart_tx_data <= ss_buf[tx_cnt];
                        if (tx_cnt == OUTPUT_BYTES - 1) begin
                            state <= S_DONE;
                        end else begin
                            tx_cnt <= tx_cnt + 6'd1;
                        end
                    end
                end

                // ---------------- S_DONE: 完成 ----------------
                // LED 保持点亮直到下一次收到帧头 (上板可观察)
                S_DONE: begin
                    led   <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
