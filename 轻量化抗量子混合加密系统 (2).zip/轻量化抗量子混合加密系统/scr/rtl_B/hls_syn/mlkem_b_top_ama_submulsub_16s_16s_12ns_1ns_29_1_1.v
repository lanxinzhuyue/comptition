// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
`timescale 1 ns / 1 ps

module mlkem_b_top_ama_submulsub_16s_16s_12ns_1ns_29_1_1_DSP48_4 (
    input  [16 - 1:0] in0,
    input  [16 - 1:0] in1,
    input  [12 - 1:0] in2,
    input  [1 - 1:0] in3,
    output [29 - 1:0]  dout);


wire signed [18 - 1:0]     b;
wire signed [25 - 1:0]     a;
wire signed [25 - 1:0]     d;
wire signed [48 - 1:0]     c;
wire signed [43 - 1:0]     m;
wire signed [48 - 1:0]     p;
wire signed [25 - 1:0]     ad;

assign a = $signed(in0);
assign d = $signed(in1);
assign b = $unsigned(in2);
assign c = $unsigned(in3);

assign ad = a - d;
assign m  = ad * b;
assign p  = c - m;

assign dout = p;

endmodule
`timescale 1 ns / 1 ps
module mlkem_b_top_ama_submulsub_16s_16s_12ns_1ns_29_1_1(
    din0,
    din1,
    din2,
    din3,
    dout);

parameter ID = 32'd1;
parameter NUM_STAGE = 32'd1;
parameter din0_WIDTH = 32'd1;
parameter din1_WIDTH = 32'd1;
parameter din2_WIDTH = 32'd1;
parameter din3_WIDTH = 32'd1;
parameter dout_WIDTH = 32'd1;
input[din0_WIDTH - 1:0] din0;
input[din1_WIDTH - 1:0] din1;
input[din2_WIDTH - 1:0] din2;
input[din3_WIDTH - 1:0] din3;
output[dout_WIDTH - 1:0] dout;



mlkem_b_top_ama_submulsub_16s_16s_12ns_1ns_29_1_1_DSP48_4 mlkem_b_top_ama_submulsub_16s_16s_12ns_1ns_29_1_1_DSP48_4_U(
    .in0( din0 ),
    .in1( din1 ),
    .in2( din2 ),
    .in3( din3 ),
    .dout( dout ));

endmodule

