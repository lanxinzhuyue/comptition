// ============================================================================
// mlkem_b_agreement_core.v -- B 板密钥协商核心 (keygen -> decaps -> ss)
//
// 阶段5 (AES 闭环) 子模块: 在板上跑 RTL keygen 得 (pk_B,sk_B), 接收 A 板密文 ct,
// 做 HLS decaps, 输出会话密钥 ss_B (== ss_A)。
//
// 流程:
//   S_IDLE     : 等 start
//   S_KEYGEN   : keygen_wrap(d,z) -> (pk_B,sk_B)
//   S_FILL_DEC : 填 decaps in_mem: word0..191 = ct(768B), word192..599 = sk_B(1632B)
//   S_DEC_RUN  : ap_start 保持到 ap_done
//   S_DEC_READ : 读 decaps out_mem 8 word -> ss
//   S_DONE     : done 脉冲
//
// 端口: d/z 以 256-bit LE 输入; ct 以 192-word 输入 (来自 UART2 收包或 tb);
//       ss 以 256-bit 输出。
// ============================================================================
`timescale 1ns/1ps
module mlkem_b_agreement_core (
    input  wire        clk,
    input  wire        rst,          // high
    input  wire        start,
    input  wire [255:0] d_in,        // keygen d (byte0 = [7:0])
    input  wire [255:0] z_in,        // keygen z

    // A 板密文 ct input: 192 32-bit LE words
    // ct_w_a 为核心内部产生的读地址 (output), 外部据此回送 ct_w_q 数据 (input)
    output wire [7:0]  ct_w_a,       // word index 0..191 (core drives)
    input  wire [31:0] ct_w_q,

    // 本板 keygen 产生的 pk_B 读口 (供 A 板 encaps 用, 模拟板间 pk 交换)
    input  wire [7:0]  pk_w_a,       // word index 0..199
    output wire [31:0] pk_w_q,

    // peer ct handshake: level signals
    input  wire        ct_ready,     // A encaps done: ct valid
    output reg         pk_ready,     // keygen done: pk_B valid (held till next start)

    output reg         done,
    output reg  [255:0] ss
);

    // ==================================================================
    // keygen_wrap (kg_ tree)
    // ==================================================================
    wire [9:0]  kg_pk_a;  wire [7:0] kg_pk_q;
    wire [10:0] kg_sk_a;  wire [7:0] kg_sk_q;
    wire [7:0]  kg_pk_w_a; wire [31:0] kg_pk_w_q;
    wire [9:0]  kg_sk_w_a; wire [31:0] kg_sk_w_q;
    wire        kg_done;
    reg         kg_start;
    keygen_wrap u_kg (
        .clk(clk), .rst(rst), .start(kg_start), .done(kg_done),
        .d_in(d_in), .z_in(z_in),
        .pk_a(kg_pk_a), .pk_q(kg_pk_q),
        .sk_a(kg_sk_a), .sk_q(kg_sk_q),
        .pk_w_a(kg_pk_w_a), .pk_w_q(kg_pk_w_q),
        .sk_w_a(kg_sk_w_a), .sk_w_q(kg_sk_w_q)
    );
    assign pk_w_q = kg_pk_w_q;   // expose pk_B to A board

    // ==================================================================
    // HLS decaps (mlkem_b_top)
    // ==================================================================
    wire [31:0] dec_in_Addr; wire dec_in_EN, dec_in_Clk, dec_in_Rst;
    wire [3:0]  dec_in_WEN; wire [31:0] dec_in_Din, dec_in_Dout;
    wire [31:0] dec_out_Addr; wire dec_out_EN, dec_out_Clk, dec_out_Rst;
    wire [3:0]  dec_out_WEN; wire [31:0] dec_out_Din, dec_out_Dout;
    wire dec_ap_done, dec_ap_idle, dec_ap_ready;
    reg  dec_ap_start;

    mlkem_b_top u_dec (
        .ap_clk(clk), .ap_rst(rst), .ap_start(dec_ap_start),
        .ap_done(dec_ap_done), .ap_idle(dec_ap_idle), .ap_ready(dec_ap_ready),
        .in_data_Addr_A(dec_in_Addr), .in_data_EN_A(dec_in_EN),
        .in_data_WEN_A(dec_in_WEN), .in_data_Din_A(dec_in_Din),
        .in_data_Dout_A(dec_in_Dout), .in_data_Clk_A(dec_in_Clk),
        .in_data_Rst_A(dec_in_Rst),
        .out_data_Addr_A(dec_out_Addr), .out_data_EN_A(dec_out_EN),
        .out_data_WEN_A(dec_out_WEN), .out_data_Din_A(dec_out_Din),
        .out_data_Dout_A(dec_out_Dout), .out_data_Clk_A(dec_out_Clk),
        .out_data_Rst_A(dec_out_Rst)
    );
    assign dec_in_Clk = clk;  assign dec_in_Rst = rst;
    assign dec_out_Clk = clk; assign dec_out_Rst = rst;

    // ---- decaps input BRAM (600 words) ----
    reg [31:0] dec_in_mem [0:1023];
    reg [9:0]  dec_in_wa; reg dec_in_we; reg [31:0] dec_in_wd;
    reg [31:0] dec_in_dout;
    always @(posedge clk) begin
        if (dec_in_we) dec_in_mem[dec_in_wa] <= dec_in_wd;
        dec_in_dout <= dec_in_mem[dec_in_Addr[11:2]];
    end
    assign dec_in_Dout = dec_in_dout;

    // ---- decaps output BRAM (8 words) ----
    reg [31:0] dec_out_mem [0:15];
    always @(posedge clk) begin
        if (dec_out_WEN != 4'b0)
            dec_out_mem[dec_out_Addr[5:2]] <= dec_out_Din;
    end
    assign dec_out_Dout = 32'b0;

    // ==================================================================
    // FSM
    // ==================================================================
    localparam [3:0] S_IDLE=0, S_KEYGEN=1, S_FILL_DEC=2, S_DEC_RUN=3,
                     S_DEC_READ=4, S_DONE=5;
    reg [3:0] state;
    reg [9:0] cnt;      // word counter 0..599
    reg       rd_valid;
    reg [3:0] rd_idx;   // 0..7 read of ss
    reg       kg_done_l;   // keygen done 脉冲锁存 (等对端 ct_ready 时不丢)

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; cnt <= 0; kg_start <= 0; dec_ap_start <= 0;
            done <= 0; ss <= 0; dec_in_we <= 0; dec_in_wa <= 0; dec_in_wd <= 0;
            rd_valid <= 0; rd_idx <= 0; pk_ready <= 0; kg_done_l <= 0;
        end else begin
            kg_start <= 0; dec_ap_start <= 0; done <= 0; dec_in_we <= 0;
            case (state)
                S_IDLE: if (start) begin state <= S_KEYGEN; cnt <= 0; pk_ready <= 0; end

                S_KEYGEN: begin
                    if (cnt == 0) begin kg_start <= 1; cnt <= 1; end
                    else begin
                        if (kg_done) begin
                            kg_done_l <= 1;     // 锁存, 避免脉冲被对端时序错过
                            pk_ready  <= 1;     // pk_B now valid for A (level)
                        end
                        if (kg_done_l && ct_ready) begin
                            kg_done_l <= 0;
                            state <= S_FILL_DEC; cnt <= 0;
                        end
                    end
                end

                // word0..191 = ct, word192..599 = sk_B
                S_FILL_DEC: begin
                    if (cnt < 192) begin
                        dec_in_we <= 1; dec_in_wa <= cnt[9:0];
                        dec_in_wd <= ct_w_q;   // ct_w_a = cnt (set below)
                        cnt <= cnt + 1;
                    end else if (cnt < 600) begin
                        dec_in_we <= 1; dec_in_wa <= cnt[9:0];
                        dec_in_wd <= kg_sk_w_q; // kg_sk_w_a = cnt-192 (set below)
                        cnt <= cnt + 1;
                    end else begin
                        state <= S_DEC_RUN; cnt <= 0;
                    end
                end

                S_DEC_RUN: begin
                    dec_ap_start <= 1;
                    if (dec_ap_done) begin
                        dec_ap_start <= 0;
                        state <= S_DEC_READ; cnt <= 0; rd_valid <= 0;
                    end
                end

                S_DEC_READ: begin
                    if (!rd_valid) begin
                        rd_valid <= 1;
                    end else begin
                        ss[32*cnt[2:0] +: 32] <= dec_out_mem[cnt[2:0]];
                        if (cnt == 7) begin
                            state <= S_DONE;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end

                S_DONE: begin done <= 1; state <= S_IDLE; end
                default: state <= S_IDLE;
            endcase
        end
    end

    // combinational read addresses
    assign ct_w_a = (state == S_FILL_DEC && cnt < 192) ? cnt[7:0] : 8'd0;
    assign kg_sk_w_a = (state == S_FILL_DEC && cnt >= 192 && cnt < 600) ? (cnt - 192) : 10'd0;
    assign kg_pk_a = 10'd0; assign kg_sk_a = 11'd0;
    assign kg_pk_w_a = pk_w_a;   // pk_B read port exposed to A board

endmodule
