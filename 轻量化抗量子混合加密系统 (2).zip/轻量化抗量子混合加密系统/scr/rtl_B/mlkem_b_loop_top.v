// ============================================================================
// mlkem_b_loop_top.v -- B 板解密闭环顶层 (Phase 5, AES-128 encrypted loop)
//
// 数据流 (双 UART):
//   uart2_rx  : A -> B   [0xAA][ct:768B][ct_aes:16B]   密文帧
//   keygen    : 板内 RTL keygen(d_B,z_B) -> (pk_B,sk_B)
//   uart1_tx  : B -> PC   [0xAA][0x01][pk_B:800B]  pk_B 帧 (PK_UART=1, 复位后自动)
//               B -> PC   [0xAA][pt:16B]          明文帧回传
//   decaps    : HLS mlkem_b_top, 用 sk_B 与 ct -> ss
//   aes       : AES-128 解密, key = ss[0:16], 密文 ct_aes -> 明文 pt
//
// 上板 (PK_UART=1): 复位释放后自动 keygen -> 发 pk_B 帧给 PC -> PC 转发 A 板;
//   然后收 A 板密文帧 -> ct_ready -> decaps -> AES -> 回传明文。一轮会话闭环,
//   S_DONE 停住不循环 (重新会话需复位)。pk_B 只发一次 (keygen 只跑一轮)。
//
// 随机性: USE_RAND=1 时 d/z 由内部 rand_src (TRNG+SHAKE256, NUM_RUNS=1) 产生,
//         =0 时由端口 d_in/z_in 注入 (tb)。
// 端口 pk_w_a/pk_w_q 在 PK_UART=0 时穿到 core 供 tb 直连 A 板; =1 时内部驱动。
//
// 波特率: 与 A 板一致 (source4 uart 16 位 baud_cnt, 50MHz/1.152M=43 安全).
// ============================================================================
`timescale 1ns/1ps
module mlkem_b_loop_top #(
    parameter CLK_FREQ      = 50_000_000,
    parameter BAUD_RATE     = 1_152_000,     // 10x 仿真加速 (43 分频)
    parameter CT_BYTES      = 768,
    parameter CTAES_BYTES   = 16,
    parameter PT_BYTES      = 16,
    parameter USE_RAND      = 0,             // 1=d/z 用内部 TRNG+SHAKE256; 0=端口注入
    parameter PK_UART       = 0,             // 1=上板: 自动keygen+发pk+收ct; 0=tb直连
    parameter SIM_MODE      = 1              // 1=LFSR(仿真), 0=真TRNG(上板)
) (
    input  wire clk,
    input  wire rst_n,          // 低有效

    // UART2: A -> B (密文帧 [0xAA][ct][ct_aes])
    input  wire uart2_rx,

    // UART1: B -> PC (pk_B 帧 / 明文帧)
    output wire uart1_tx,

    // keygen 输入 (USE_RAND=1 时忽略; tb 注入参考值)
    input  wire [255:0] d_in,
    input  wire [255:0] z_in,

    // 本板 pk_B 字读口 (PK_UART=0 时端口驱动 core 供 tb 直连; =1 时内部驱动)
    input  wire [7:0]  pk_w_a,
    output wire [31:0] pk_w_q,

    // 测试旁路 (上板接 0): 跳过 ML-KEM 核 (不启动), 注入已知 ss,
    // 快速验证 UART 帧 + AES 解密接线
    input  wire        bypass_mlkem,
    input  wire [255:0] ss_bypass,

    output reg         led,
    output reg         done,
    output wire [255:0] ss_out
);

    // ==================================================================
    // UART 收发
    // ==================================================================
    wire        uart2_rx_done;  wire [7:0] uart2_rx_data;
    wire        uart1_tx_busy;
    reg         uart1_tx_en;    reg [7:0] uart1_tx_data;

    uart_rx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_rx2 (
        .clk(clk), .rst_n(rst_n), .uart_rxd(uart2_rx),
        .uart_rx_done(uart2_rx_done), .uart_rx_data(uart2_rx_data)
    );
    uart_tx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_tx1 (
        .clk(clk), .rst_n(rst_n), .uart_tx_en(uart1_tx_en),
        .uart_tx_data(uart1_tx_data), .uart_txd(uart1_tx), .uart_tx_busy(uart1_tx_busy)
    );

    // ==================================================================
    // 随机源 (TRNG + SHAKE256) -- USE_RAND=1 才例化
    // ==================================================================
    wire [255:0] rand_d, rand_z, rand_m;
    wire         rand_ok;
    generate
        if (USE_RAND) begin : g_rand
            rand_src #(.SIM_MODE(SIM_MODE), .NUM_RUNS(1)) u_rand (
                .clk(clk), .rst_n(rst_n),
                .d_out(rand_d), .z_out(rand_z), .m_out(rand_m),
                .all_valid(rand_ok)
            );
        end else begin : g_rand_off
            assign rand_d = 256'd0; assign rand_z = 256'd0; assign rand_m = 256'd0;
            assign rand_ok = 1'b0;
        end
    endgenerate
    wire [255:0] d_eff = USE_RAND ? rand_d : d_in;
    wire [255:0] z_eff = USE_RAND ? rand_z : z_in;
    wire         all_valid = USE_RAND ? rand_ok : 1'b1;

    // ==================================================================
    // UART2 收包缓冲 (ct + ct_aes)
    // ==================================================================
    reg [7:0]  rx_buf [0:783];      // [0:767]=ct, [768:783]=ct_aes
    reg [9:0]  rx_byte_cnt;         // 0..783

    // ==================================================================
    // 密钥协商/解密核心 (keygen RTL + HLS decaps)
    // ==================================================================
    wire        agr_start;
    wire        agr_done;
    wire [255:0] core_ss;
    wire [7:0]  ct_w_a;  wire [31:0] ct_w_q;   // 核心驱动读地址, 本层回送数据
    wire        core_pk_ready;                 // core keygen done (pk_B valid, level)

    // ct 字读: 核心驱动 ct_w_a (0..191) -> 回送 4 字节 LE word
    // ct 字节地址 = ct_w_a*4 + k
    assign ct_w_q = {rx_buf[{ct_w_a, 2'b00}+3], rx_buf[{ct_w_a, 2'b00}+2],
                     rx_buf[{ct_w_a, 2'b00}+1], rx_buf[{ct_w_a, 2'b00}+0]};

    // pk_w_a 来源: PK_UART=1 内部驱动 (pk 发送), =0 端口穿透
    //   S_TXPK 时按 pk_tx_cnt 组合产生字地址, 其余为 0
    wire [9:0] pk_byte_idx = pk_tx_cnt - 10'd2;          // pk 字节序号 0..799
    wire [7:0] pk_w_a_core =
        (state == S_TXPK && pk_tx_cnt >= 10'd2 && pk_tx_cnt <= 10'd801)
        ? pk_byte_idx[9:2] : 8'd0;
    wire [1:0] pk_boff = pk_byte_idx[1:0];   // pk 字节字内偏移
    wire [7:0] pk_w_a_eff = PK_UART ? pk_w_a_core : pk_w_a;

    // ct_ready: PK_UART=1 由顶层产生 (收满 784 字节), =0 恒 1 (tb 直连场景)
    reg  ct_ready_r;
    wire ct_ready_eff = PK_UART ? ct_ready_r : 1'b1;

    mlkem_b_agreement_core u_core (
        .clk(clk), .rst(~rst_n),
        .start(bypass_mlkem ? 1'b0 : agr_start),   // 旁路: 核不启动
        .d_in(d_eff), .z_in(z_eff),
        .ct_w_a(ct_w_a), .ct_w_q(ct_w_q),
        .pk_w_a(pk_w_a_eff), .pk_w_q(pk_w_q),
        .ct_ready(ct_ready_eff),
        .pk_ready(core_pk_ready),
        .done(agr_done), .ss(core_ss)
    );
    assign ss_out = bypass_mlkem ? ss_bypass : core_ss;

    // ---- 旁路: 收到 ct 后延 2 拍即视为"协商完成" ----
    reg bypass_done_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            bypass_done_r <= 1'b0;
        else if (state == S_AGREE) begin
            if (bypass_done_r)
                bypass_done_r <= 1'b0;
            else
                bypass_done_r <= 1'b1;
        end else
            bypass_done_r <= 1'b0;
    end
    wire agr_done_eff = bypass_mlkem ? bypass_done_r : agr_done;

    // ---- 旁路 pk 就绪: 旁路时 core 不启动, pk_ready 恒 0, 用延时代替 ----
    // (真实核时用 core_pk_ready; 旁路仅供 tb 快速验证 UART pk 帧流)
    reg [7:0] bypass_pk_cnt;
    wire bypass_pk_ok;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            bypass_pk_cnt <= 8'd0;
        else if (bypass_mlkem && !bypass_pk_ok)
            bypass_pk_cnt <= bypass_pk_cnt + 8'd1;
    end
    assign bypass_pk_ok = (bypass_pk_cnt >= 8'd200);
    wire pk_ready_eff = bypass_mlkem ? bypass_pk_ok : core_pk_ready;

    // ==================================================================
    // AES-128 (decrypt)
    // ==================================================================
    wire       aes_busy, aes_valid;
    wire [127:0] aes_out;
    reg        aes_start;
    aes_block_top u_aes (
        .clk(clk), .rstn(rst_n), .start(aes_start), .mode(1'b0),
        .key_in(ss_out[127:0]),        // ss 前 16 字节 (byte0=[7:0])
        .data_in({rx_buf[783],rx_buf[782],rx_buf[781],rx_buf[780],
                  rx_buf[779],rx_buf[778],rx_buf[777],rx_buf[776],
                  rx_buf[775],rx_buf[774],rx_buf[773],rx_buf[772],
                  rx_buf[771],rx_buf[770],rx_buf[769],rx_buf[768]}),
        .busy(aes_busy), .data_out_valid(aes_valid), .data_out(aes_out)
    );

    // 解密结果 (byte0=[7:0])
    reg [7:0] pt_buf [0:PT_BYTES-1];
    wire [7:0] pt_byte [0:PT_BYTES-1];
    genvar gp;
    generate
        for (gp = 0; gp < PT_BYTES; gp = gp + 1) begin : g_ptbyte
            assign pt_byte[gp] = aes_out[8*gp +: 8];
        end
    endgenerate

    // ==================================================================
    // 主状态机 (PK_UART=1: 一次性闭环; =0: tb 原循环逻辑)
    // ==================================================================
    localparam [3:0] S_IDLE  = 4'd0,  // PK=1: 立即进 S_TXPK; =0: 等帧头 0xAA
                     S_RX2   = 4'd1,  // 收 784 字节 (ct+ct_aes)
                     S_AGREE = 4'd2,  // keygen+decaps (等 agr_done 脉冲)
                     S_AES   = 4'd3,  // AES 解密
                     S_TX1   = 4'd4,  // uart1 发 [0xAA][pt]
                     S_DONE  = 4'd5,
                     S_TXPK  = 4'd6;  // PK=1: 发 [0xAA][0x01][pk_B:800]
    reg [3:0] state;
    reg [4:0] rx_pt_cnt;             // 明文发送计数 0..17 (0xAA + type + 16B)
    reg [9:0] pk_tx_cnt;             // pk 帧字节计数 0..801
    reg       pk_tx_sent;            // PK=1: pk 帧已发完 (防重发)
    reg       auto_started;          // PK=1: 复位后已自动打 core start
    reg [3:0] boot_cnt;              // 复位后延时计数 (打 core start 前)
    reg       boot_wait;             // PK=1: 延时完成, 等 all_valid
    // 注: 发送握手不再用额外 ack 寄存器 -- 直接判 !uart1_tx_en && !uart1_tx_busy,
    // en 非阻塞更新在上拍已生效, 下一拍读到 1 自然拦下重复 en (同 A 板)。

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state       <= S_IDLE;
            rx_byte_cnt <= 0;
            aes_start   <= 0;
            rx_pt_cnt   <= 0;
            pk_tx_cnt   <= 0;
            pk_tx_sent  <= 0;
            uart1_tx_en <= 0;   uart1_tx_data <= 0;
            ct_ready_r  <= 0;
            led         <= 0;   done <= 0;
        end else begin
            uart1_tx_en <= 0;
            aes_start   <= 0;
            done        <= 0;

            case (state)
                // ---------------- S_IDLE ----------------
                S_IDLE: begin
                    led <= 1'b0;
                    if (PK_UART) begin
                        // 复位后先发 pk_B 帧 (只一次), 之后等 A 板密文帧头
                        if (!pk_tx_sent)
                            state <= S_TXPK;
                        else if (uart2_rx_done && uart2_rx_data == 8'hAA)
                            state <= S_RX2;
                    end else if (uart2_rx_done && uart2_rx_data == 8'hAA) begin
                        state <= S_RX2;
                    end
                end

                // ---------------- S_TXPK: 发 [0xAA][0x01][pk_B:800] (PK=1) ----------------
                // 等 core keygen 完成 (pk_ready_eff 电平) 后开始发。
                S_TXPK: begin
                    if (pk_ready_eff) begin
                        if (!uart1_tx_en && !uart1_tx_busy) begin
                            uart1_tx_en <= 1'b1;
                            if (pk_tx_cnt == 10'd0)
                                uart1_tx_data <= 8'hAA;
                            else if (pk_tx_cnt == 10'd1)
                                uart1_tx_data <= 8'h01;
                            else
                                uart1_tx_data <= pk_w_q >> (8*pk_boff);
                            if (pk_tx_cnt == 10'd801) begin
                                pk_tx_sent <= 1'b1;   // pk 帧发完, 只发一次
                                state      <= S_IDLE; // 等 A 板密文
                            end else
                                pk_tx_cnt <= pk_tx_cnt + 10'd1;
                        end
                    end
                end

                // ---------------- S_RX2: 收 784 字节 ----------------
                S_RX2: begin
                    if (uart2_rx_done) begin
                        rx_buf[rx_byte_cnt] <= uart2_rx_data;
                        if (rx_byte_cnt == 10'd783) begin
                            ct_ready_r <= 1'b1;      // PK=1: ct 就绪 -> 核心可 decaps
                            state      <= S_AGREE;
                        end else
                            rx_byte_cnt <= rx_byte_cnt + 10'd1;
                    end
                end

                // ---------------- S_AGREE: 启动核心, 等 done ----------------
                S_AGREE: begin
                    if (agr_done_eff) begin
                        aes_start <= 1'b1;      // 打 AES 启动脉冲
                        state     <= S_AES;
                    end
                end

                // ---------------- S_AES: 等 AES 解密, 锁明文 ----------------
                S_AES: begin
                    if (aes_valid) begin
                        pt_buf[ 0] <= pt_byte[ 0];  pt_buf[ 8] <= pt_byte[ 8];
                        pt_buf[ 1] <= pt_byte[ 1];  pt_buf[ 9] <= pt_byte[ 9];
                        pt_buf[ 2] <= pt_byte[ 2];  pt_buf[10] <= pt_byte[10];
                        pt_buf[ 3] <= pt_byte[ 3];  pt_buf[11] <= pt_byte[11];
                        pt_buf[ 4] <= pt_byte[ 4];  pt_buf[12] <= pt_byte[12];
                        pt_buf[ 5] <= pt_byte[ 5];  pt_buf[13] <= pt_byte[13];
                        pt_buf[ 6] <= pt_byte[ 6];  pt_buf[14] <= pt_byte[14];
                        pt_buf[ 7] <= pt_byte[ 7];  pt_buf[15] <= pt_byte[15];
                        rx_pt_cnt <= 4'd0;
                        state     <= S_TX1;
                    end
                end

                // ---------------- S_TX1: 发 [0xAA][0x00][pt:16] (PK=1) / [0xAA][pt:16] (=0) ----
                // PK=1 时带 type 0x00 区分明文帧 (pk 帧为 0x01), PC 可分辨两帧;
                // PK=0 时保持旧协议 (tb 兼容)
                S_TX1: begin
                    if (!uart1_tx_en && !uart1_tx_busy) begin
                        uart1_tx_en <= 1'b1;
                        if (rx_pt_cnt == 5'd0)
                            uart1_tx_data <= 8'hAA;
                        else if (PK_UART && rx_pt_cnt == 5'd1)
                            uart1_tx_data <= 8'h00;
                        else
                            uart1_tx_data <= pt_buf[rx_pt_cnt - (PK_UART ? 5'd2 : 5'd1)];
                        if (rx_pt_cnt == (PK_UART ? 5'd17 : 5'd16))
                            state <= S_DONE;
                        else
                            rx_pt_cnt <= rx_pt_cnt + 5'd1;
                    end
                end

                // ---------------- S_DONE ----------------
                S_DONE: begin
                    led   <= 1'b1;
                    done  <= 1'b1;
                    // PK_UART=1: 一次性闭环, 停住; =0: 回 S_IDLE 循环
                    state <= PK_UART ? S_DONE : S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

    // ---- 复位后 boot: PK=1 自动打一拍 agr_start (keygen 启动) ----
    // boot_wait 在延时后置位并保持, 直到 all_valid(随机就绪) 才打脉冲, 只打一次。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            auto_started <= 1'b0;
            boot_cnt     <= 4'd0;
            boot_wait    <= 1'b0;
        end else if (PK_UART && !auto_started) begin
            if (boot_wait) begin
                if (all_valid) auto_started <= 1'b1;   // 随机就绪后只打一次
            end else if (boot_cnt == 4'd3) begin
                boot_wait <= 1'b1;                     // 延时完成, 等 all_valid
            end else begin
                boot_cnt <= boot_cnt + 4'd1;
            end
        end
    end
    wire boot_pulse = PK_UART && boot_wait && all_valid && !auto_started;

    // ---- 核心启动: PK=1 只由 boot_pulse 触发 (keygen 只跑一轮);
    //      PK=0 进入 S_AGREE 打一拍 (tb 每轮从 S_IDLE 重启核心) ----
    reg agr_start_r;
    reg [3:0] prev_state;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            agr_start_r <= 1'b0;
            prev_state  <= 4'd0;
        end else begin
            prev_state <= state;
            if (boot_pulse)
                agr_start_r <= 1'b1;
            else if (!PK_UART && state == S_AGREE && prev_state != S_AGREE)
                agr_start_r <= 1'b1;
            else
                agr_start_r <= 1'b0;
        end
    end
    assign agr_start = agr_start_r;

endmodule
