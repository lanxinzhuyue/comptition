`timescale 1ns / 1ps
// ---------------------------------------------------------------------------
// keccak_f1600_core.v -- 自包含 Keccak-f[1600] 置换核 (24 轮, 1 round/cycle)
//
// 接口极简: 输入 1600-bit 状态, go 触发, 24 拍后 done + state_out 有效.
// 内部自带 25x64 lane 寄存器 (不用外部 RAM), 用 keccak_round 组合轮.
// 完全绕开 RAM 端口仲裁, 适合 SHAKE256/TRNG 后处理等小引擎.
//
// 时序: go 拉高 1 拍 -> busy; 24 拍后 done 拉高 1 拍, state_out 有效.
//   总 ~26 拍 (IDLE + 24 ROUND + DONE).
//
// lane 顺序: state[1599:0] = {lane[24], lane[23], ..., lane[0]},
//   lane[i] = state[64i+63 : 64i]  (lane0 在 LSB)
// ---------------------------------------------------------------------------
module keccak_f1600_core (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         go,
    input  wire [1599:0] state_in,
    output reg          busy,
    output reg          done,
    output reg  [1599:0] state_out
);

    reg [63:0] lane [0:24];
    reg [4:0]  round_cnt;
    reg [7:0]  lfsr;      // FIPS 202 LFSR 状态 (round 0 = 0x01)
    reg        running;

    // 组合轮输入输出
    wire [1599:0] s_in, s_out;
    wire [7:0]    r_next;
    assign s_in = { lane[24], lane[23], lane[22], lane[21], lane[20],
                    lane[19], lane[18], lane[17], lane[16], lane[15],
                    lane[14], lane[13], lane[12], lane[11], lane[10],
                    lane[ 9], lane[ 8], lane[ 7], lane[ 6], lane[ 5],
                    lane[ 4], lane[ 3], lane[ 2], lane[ 1], lane[ 0] };

    keccak_round u_round (
        .s_o (s_out),
        .r_o (r_next),
        .s_i (s_in),
        .r_i (lfsr)   // FIPS 202 LFSR 状态
    );

    integer i;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy      <= 1'b0;
            done      <= 1'b0;
            running   <= 1'b0;
            round_cnt <= 5'd0;
            lfsr      <= 8'h01;
            for (i = 0; i < 25; i = i + 1) lane[i] <= 64'd0;
        end else begin
            done <= 1'b0;
            if (!running) begin
                if (go) begin
                    // 装载输入状态
                    busy      <= 1'b1;
                    running   <= 1'b1;
                    round_cnt <= 5'd0;
                    lfsr      <= 8'h01;   // 第 0 轮用 LFSR 0x01
                    for (i = 0; i < 25; i = i + 1)
                        lane[i] <= state_in[64*i +: 64];
                end
            end else begin
                // 执行 24 轮置换
                if (round_cnt == 5'd23) begin
                    // 最后一轮: 输出
                    lane[ 0] <= s_out[ 63:   0];
                    lane[ 1] <= s_out[127:  64];
                    lane[ 2] <= s_out[191: 128];
                    lane[ 3] <= s_out[255: 192];
                    lane[ 4] <= s_out[319: 256];
                    lane[ 5] <= s_out[383: 320];
                    lane[ 6] <= s_out[447: 384];
                    lane[ 7] <= s_out[511: 448];
                    lane[ 8] <= s_out[575: 512];
                    lane[ 9] <= s_out[639: 576];
                    lane[10] <= s_out[703: 640];
                    lane[11] <= s_out[767: 704];
                    lane[12] <= s_out[831: 768];
                    lane[13] <= s_out[895: 832];
                    lane[14] <= s_out[959: 896];
                    lane[15] <= s_out[1023: 960];
                    lane[16] <= s_out[1087: 1024];
                    lane[17] <= s_out[1151: 1088];
                    lane[18] <= s_out[1215: 1152];
                    lane[19] <= s_out[1279: 1216];
                    lane[20] <= s_out[1343: 1280];
                    lane[21] <= s_out[1407: 1344];
                    lane[22] <= s_out[1471: 1408];
                    lane[23] <= s_out[1535: 1472];
                    lane[24] <= s_out[1599: 1536];
                    state_out <= s_out;
                    busy      <= 1'b0;
                    done      <= 1'b1;
                    running   <= 1'b0;
                end else begin
                    lane[ 0] <= s_out[ 63:   0];
                    lane[ 1] <= s_out[127:  64];
                    lane[ 2] <= s_out[191: 128];
                    lane[ 3] <= s_out[255: 192];
                    lane[ 4] <= s_out[319: 256];
                    lane[ 5] <= s_out[383: 320];
                    lane[ 6] <= s_out[447: 384];
                    lane[ 7] <= s_out[511: 448];
                    lane[ 8] <= s_out[575: 512];
                    lane[ 9] <= s_out[639: 576];
                    lane[10] <= s_out[703: 640];
                    lane[11] <= s_out[767: 704];
                    lane[12] <= s_out[831: 768];
                    lane[13] <= s_out[895: 832];
                    lane[14] <= s_out[959: 896];
                    lane[15] <= s_out[1023: 960];
                    lane[16] <= s_out[1087: 1024];
                    lane[17] <= s_out[1151: 1088];
                    lane[18] <= s_out[1215: 1152];
                    lane[19] <= s_out[1279: 1216];
                    lane[20] <= s_out[1343: 1280];
                    lane[21] <= s_out[1407: 1344];
                    lane[22] <= s_out[1471: 1408];
                    lane[23] <= s_out[1535: 1472];
                    lane[24] <= s_out[1599: 1536];
                    round_cnt <= round_cnt + 5'd1;
                    lfsr      <= r_next;   // 更新 LFSR 状态
                end
            end
        end
    end

endmodule
