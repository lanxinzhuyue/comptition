// ============================================================================
// aes128_core.v -- AES-128 encrypt/decrypt core (FIPS-197)
//
// 128-bit block, 128-bit key.  Byte order convention (MUST match Python ref):
//   byte0 of the block  <->  [7:0]    (least-significant byte)
//   byte15 of the block <->  [127:120] (most-significant byte)
// This is little-endian byte packing, same as the ML-KEM bram interface.
//
// Single-round iterative core: state updated once per cycle.
//   encrypt:  round0 AddRoundKey + 10 round transforms = 11 updates.
//   decrypt:  round0 AddRoundKey(rk10) + 10 inverse transforms.
// Latency 12 clocks/block (11 RUN + 1 FIN).
//
// Interface:
//   en / data_in_valid : start a block (latches data_in, key_in, mode)
//   mode  : 1=encrypt, 0=decrypt
//   aes_state : busy
//   data_out_valid : result valid one cycle
// ============================================================================
`timescale 1ns / 1ps

module aes128_core #(
    parameter integer ROUNDS = 10
) (
    input  wire         clk,
    input  wire         rstn,
    input  wire         en,
    input  wire         data_in_valid,
    input  wire [127:0] data_in,
    output reg          aes_state,
    output reg          rk_ready,
    output reg          data_out_valid,
    output reg  [127:0] data_out,
    input  wire [127:0] key_in,
    input  wire         mode
);

    // ==================================================================
    // S-box / InvS-box (FIPS-197 verified tables)
    // ==================================================================
    function [7:0] sbox;
        input [7:0] x;
        begin
            case (x)
                8'h00: sbox=8'h63; 8'h01: sbox=8'h7c; 8'h02: sbox=8'h77; 8'h03: sbox=8'h7b;
                8'h04: sbox=8'hf2; 8'h05: sbox=8'h6b; 8'h06: sbox=8'h6f; 8'h07: sbox=8'hc5;
                8'h08: sbox=8'h30; 8'h09: sbox=8'h01; 8'h0a: sbox=8'h67; 8'h0b: sbox=8'h2b;
                8'h0c: sbox=8'hfe; 8'h0d: sbox=8'hd7; 8'h0e: sbox=8'hab; 8'h0f: sbox=8'h76;
                8'h10: sbox=8'hca; 8'h11: sbox=8'h82; 8'h12: sbox=8'hc9; 8'h13: sbox=8'h7d;
                8'h14: sbox=8'hfa; 8'h15: sbox=8'h59; 8'h16: sbox=8'h47; 8'h17: sbox=8'hf0;
                8'h18: sbox=8'had; 8'h19: sbox=8'hd4; 8'h1a: sbox=8'ha2; 8'h1b: sbox=8'haf;
                8'h1c: sbox=8'h9c; 8'h1d: sbox=8'ha4; 8'h1e: sbox=8'h72; 8'h1f: sbox=8'hc0;
                8'h20: sbox=8'hb7; 8'h21: sbox=8'hfd; 8'h22: sbox=8'h93; 8'h23: sbox=8'h26;
                8'h24: sbox=8'h36; 8'h25: sbox=8'h3f; 8'h26: sbox=8'hf7; 8'h27: sbox=8'hcc;
                8'h28: sbox=8'h34; 8'h29: sbox=8'ha5; 8'h2a: sbox=8'he5; 8'h2b: sbox=8'hf1;
                8'h2c: sbox=8'h71; 8'h2d: sbox=8'hd8; 8'h2e: sbox=8'h31; 8'h2f: sbox=8'h15;
                8'h30: sbox=8'h04; 8'h31: sbox=8'hc7; 8'h32: sbox=8'h23; 8'h33: sbox=8'hc3;
                8'h34: sbox=8'h18; 8'h35: sbox=8'h96; 8'h36: sbox=8'h05; 8'h37: sbox=8'h9a;
                8'h38: sbox=8'h07; 8'h39: sbox=8'h12; 8'h3a: sbox=8'h80; 8'h3b: sbox=8'he2;
                8'h3c: sbox=8'heb; 8'h3d: sbox=8'h27; 8'h3e: sbox=8'hb2; 8'h3f: sbox=8'h75;
                8'h40: sbox=8'h09; 8'h41: sbox=8'h83; 8'h42: sbox=8'h2c; 8'h43: sbox=8'h1a;
                8'h44: sbox=8'h1b; 8'h45: sbox=8'h6e; 8'h46: sbox=8'h5a; 8'h47: sbox=8'ha0;
                8'h48: sbox=8'h52; 8'h49: sbox=8'h3b; 8'h4a: sbox=8'hd6; 8'h4b: sbox=8'hb3;
                8'h4c: sbox=8'h29; 8'h4d: sbox=8'he3; 8'h4e: sbox=8'h2f; 8'h4f: sbox=8'h84;
                8'h50: sbox=8'h53; 8'h51: sbox=8'hd1; 8'h52: sbox=8'h00; 8'h53: sbox=8'hed;
                8'h54: sbox=8'h20; 8'h55: sbox=8'hfc; 8'h56: sbox=8'hb1; 8'h57: sbox=8'h5b;
                8'h58: sbox=8'h6a; 8'h59: sbox=8'hcb; 8'h5a: sbox=8'hbe; 8'h5b: sbox=8'h39;
                8'h5c: sbox=8'h4a; 8'h5d: sbox=8'h4c; 8'h5e: sbox=8'h58; 8'h5f: sbox=8'hcf;
                8'h60: sbox=8'hd0; 8'h61: sbox=8'hef; 8'h62: sbox=8'haa; 8'h63: sbox=8'hfb;
                8'h64: sbox=8'h43; 8'h65: sbox=8'h4d; 8'h66: sbox=8'h33; 8'h67: sbox=8'h85;
                8'h68: sbox=8'h45; 8'h69: sbox=8'hf9; 8'h6a: sbox=8'h02; 8'h6b: sbox=8'h7f;
                8'h6c: sbox=8'h50; 8'h6d: sbox=8'h3c; 8'h6e: sbox=8'h9f; 8'h6f: sbox=8'ha8;
                8'h70: sbox=8'h51; 8'h71: sbox=8'ha3; 8'h72: sbox=8'h40; 8'h73: sbox=8'h8f;
                8'h74: sbox=8'h92; 8'h75: sbox=8'h9d; 8'h76: sbox=8'h38; 8'h77: sbox=8'hf5;
                8'h78: sbox=8'hbc; 8'h79: sbox=8'hb6; 8'h7a: sbox=8'hda; 8'h7b: sbox=8'h21;
                8'h7c: sbox=8'h10; 8'h7d: sbox=8'hff; 8'h7e: sbox=8'hf3; 8'h7f: sbox=8'hd2;
                8'h80: sbox=8'hcd; 8'h81: sbox=8'h0c; 8'h82: sbox=8'h13; 8'h83: sbox=8'hec;
                8'h84: sbox=8'h5f; 8'h85: sbox=8'h97; 8'h86: sbox=8'h44; 8'h87: sbox=8'h17;
                8'h88: sbox=8'hc4; 8'h89: sbox=8'ha7; 8'h8a: sbox=8'h7e; 8'h8b: sbox=8'h3d;
                8'h8c: sbox=8'h64; 8'h8d: sbox=8'h5d; 8'h8e: sbox=8'h19; 8'h8f: sbox=8'h73;
                8'h90: sbox=8'h60; 8'h91: sbox=8'h81; 8'h92: sbox=8'h4f; 8'h93: sbox=8'hdc;
                8'h94: sbox=8'h22; 8'h95: sbox=8'h2a; 8'h96: sbox=8'h90; 8'h97: sbox=8'h88;
                8'h98: sbox=8'h46; 8'h99: sbox=8'hee; 8'h9a: sbox=8'hb8; 8'h9b: sbox=8'h14;
                8'h9c: sbox=8'hde; 8'h9d: sbox=8'h5e; 8'h9e: sbox=8'h0b; 8'h9f: sbox=8'hdb;
                8'ha0: sbox=8'he0; 8'ha1: sbox=8'h32; 8'ha2: sbox=8'h3a; 8'ha3: sbox=8'h0a;
                8'ha4: sbox=8'h49; 8'ha5: sbox=8'h06; 8'ha6: sbox=8'h24; 8'ha7: sbox=8'h5c;
                8'ha8: sbox=8'hc2; 8'ha9: sbox=8'hd3; 8'haa: sbox=8'hac; 8'hab: sbox=8'h62;
                8'hac: sbox=8'h91; 8'had: sbox=8'h95; 8'hae: sbox=8'he4; 8'haf: sbox=8'h79;
                8'hb0: sbox=8'he7; 8'hb1: sbox=8'hc8; 8'hb2: sbox=8'h37; 8'hb3: sbox=8'h6d;
                8'hb4: sbox=8'h8d; 8'hb5: sbox=8'hd5; 8'hb6: sbox=8'h4e; 8'hb7: sbox=8'ha9;
                8'hb8: sbox=8'h6c; 8'hb9: sbox=8'h56; 8'hba: sbox=8'hf4; 8'hbb: sbox=8'hea;
                8'hbc: sbox=8'h65; 8'hbd: sbox=8'h7a; 8'hbe: sbox=8'hae; 8'hbf: sbox=8'h08;
                8'hc0: sbox=8'hba; 8'hc1: sbox=8'h78; 8'hc2: sbox=8'h25; 8'hc3: sbox=8'h2e;
                8'hc4: sbox=8'h1c; 8'hc5: sbox=8'ha6; 8'hc6: sbox=8'hb4; 8'hc7: sbox=8'hc6;
                8'hc8: sbox=8'he8; 8'hc9: sbox=8'hdd; 8'hca: sbox=8'h74; 8'hcb: sbox=8'h1f;
                8'hcc: sbox=8'h4b; 8'hcd: sbox=8'hbd; 8'hce: sbox=8'h8b; 8'hcf: sbox=8'h8a;
                8'hd0: sbox=8'h70; 8'hd1: sbox=8'h3e; 8'hd2: sbox=8'hb5; 8'hd3: sbox=8'h66;
                8'hd4: sbox=8'h48; 8'hd5: sbox=8'h03; 8'hd6: sbox=8'hf6; 8'hd7: sbox=8'h0e;
                8'hd8: sbox=8'h61; 8'hd9: sbox=8'h35; 8'hda: sbox=8'h57; 8'hdb: sbox=8'hb9;
                8'hdc: sbox=8'h86; 8'hdd: sbox=8'hc1; 8'hde: sbox=8'h1d; 8'hdf: sbox=8'h9e;
                8'he0: sbox=8'he1; 8'he1: sbox=8'hf8; 8'he2: sbox=8'h98; 8'he3: sbox=8'h11;
                8'he4: sbox=8'h69; 8'he5: sbox=8'hd9; 8'he6: sbox=8'h8e; 8'he7: sbox=8'h94;
                8'he8: sbox=8'h9b; 8'he9: sbox=8'h1e; 8'hea: sbox=8'h87; 8'heb: sbox=8'he9;
                8'hec: sbox=8'hce; 8'hed: sbox=8'h55; 8'hee: sbox=8'h28; 8'hef: sbox=8'hdf;
                8'hf0: sbox=8'h8c; 8'hf1: sbox=8'ha1; 8'hf2: sbox=8'h89; 8'hf3: sbox=8'h0d;
                8'hf4: sbox=8'hbf; 8'hf5: sbox=8'he6; 8'hf6: sbox=8'h42; 8'hf7: sbox=8'h68;
                8'hf8: sbox=8'h41; 8'hf9: sbox=8'h99; 8'hfa: sbox=8'h2d; 8'hfb: sbox=8'h0f;
                8'hfc: sbox=8'hb0; 8'hfd: sbox=8'h54; 8'hfe: sbox=8'hbb; 8'hff: sbox=8'h16;
            endcase
        end
    endfunction

    function [7:0] isbox;
        input [7:0] x;
        begin
            case (x)
                8'h00: isbox=8'h52; 8'h01: isbox=8'h09; 8'h02: isbox=8'h6a; 8'h03: isbox=8'hd5;
                8'h04: isbox=8'h30; 8'h05: isbox=8'h36; 8'h06: isbox=8'ha5; 8'h07: isbox=8'h38;
                8'h08: isbox=8'hbf; 8'h09: isbox=8'h40; 8'h0a: isbox=8'ha3; 8'h0b: isbox=8'h9e;
                8'h0c: isbox=8'h81; 8'h0d: isbox=8'hf3; 8'h0e: isbox=8'hd7; 8'h0f: isbox=8'hfb;
                8'h10: isbox=8'h7c; 8'h11: isbox=8'he3; 8'h12: isbox=8'h39; 8'h13: isbox=8'h82;
                8'h14: isbox=8'h9b; 8'h15: isbox=8'h2f; 8'h16: isbox=8'hff; 8'h17: isbox=8'h87;
                8'h18: isbox=8'h34; 8'h19: isbox=8'h8e; 8'h1a: isbox=8'h43; 8'h1b: isbox=8'h44;
                8'h1c: isbox=8'hc4; 8'h1d: isbox=8'hde; 8'h1e: isbox=8'he9; 8'h1f: isbox=8'hcb;
                8'h20: isbox=8'h54; 8'h21: isbox=8'h7b; 8'h22: isbox=8'h94; 8'h23: isbox=8'h32;
                8'h24: isbox=8'ha6; 8'h25: isbox=8'hc2; 8'h26: isbox=8'h23; 8'h27: isbox=8'h3d;
                8'h28: isbox=8'hee; 8'h29: isbox=8'h4c; 8'h2a: isbox=8'h95; 8'h2b: isbox=8'h0b;
                8'h2c: isbox=8'h42; 8'h2d: isbox=8'hfa; 8'h2e: isbox=8'hc3; 8'h2f: isbox=8'h4e;
                8'h30: isbox=8'h08; 8'h31: isbox=8'h2e; 8'h32: isbox=8'ha1; 8'h33: isbox=8'h66;
                8'h34: isbox=8'h28; 8'h35: isbox=8'hd9; 8'h36: isbox=8'h24; 8'h37: isbox=8'hb2;
                8'h38: isbox=8'h76; 8'h39: isbox=8'h5b; 8'h3a: isbox=8'ha2; 8'h3b: isbox=8'h49;
                8'h3c: isbox=8'h6d; 8'h3d: isbox=8'h8b; 8'h3e: isbox=8'hd1; 8'h3f: isbox=8'h25;
                8'h40: isbox=8'h72; 8'h41: isbox=8'hf8; 8'h42: isbox=8'hf6; 8'h43: isbox=8'h64;
                8'h44: isbox=8'h86; 8'h45: isbox=8'h68; 8'h46: isbox=8'h98; 8'h47: isbox=8'h16;
                8'h48: isbox=8'hd4; 8'h49: isbox=8'ha4; 8'h4a: isbox=8'h5c; 8'h4b: isbox=8'hcc;
                8'h4c: isbox=8'h5d; 8'h4d: isbox=8'h65; 8'h4e: isbox=8'hb6; 8'h4f: isbox=8'h92;
                8'h50: isbox=8'h6c; 8'h51: isbox=8'h70; 8'h52: isbox=8'h48; 8'h53: isbox=8'h50;
                8'h54: isbox=8'hfd; 8'h55: isbox=8'hed; 8'h56: isbox=8'hb9; 8'h57: isbox=8'hda;
                8'h58: isbox=8'h5e; 8'h59: isbox=8'h15; 8'h5a: isbox=8'h46; 8'h5b: isbox=8'h57;
                8'h5c: isbox=8'ha7; 8'h5d: isbox=8'h8d; 8'h5e: isbox=8'h9d; 8'h5f: isbox=8'h84;
                8'h60: isbox=8'h90; 8'h61: isbox=8'hd8; 8'h62: isbox=8'hab; 8'h63: isbox=8'h00;
                8'h64: isbox=8'h8c; 8'h65: isbox=8'hbc; 8'h66: isbox=8'hd3; 8'h67: isbox=8'h0a;
                8'h68: isbox=8'hf7; 8'h69: isbox=8'he4; 8'h6a: isbox=8'h58; 8'h6b: isbox=8'h05;
                8'h6c: isbox=8'hb8; 8'h6d: isbox=8'hb3; 8'h6e: isbox=8'h45; 8'h6f: isbox=8'h06;
                8'h70: isbox=8'hd0; 8'h71: isbox=8'h2c; 8'h72: isbox=8'h1e; 8'h73: isbox=8'h8f;
                8'h74: isbox=8'hca; 8'h75: isbox=8'h3f; 8'h76: isbox=8'h0f; 8'h77: isbox=8'h02;
                8'h78: isbox=8'hc1; 8'h79: isbox=8'haf; 8'h7a: isbox=8'hbd; 8'h7b: isbox=8'h03;
                8'h7c: isbox=8'h01; 8'h7d: isbox=8'h13; 8'h7e: isbox=8'h8a; 8'h7f: isbox=8'h6b;
                8'h80: isbox=8'h3a; 8'h81: isbox=8'h91; 8'h82: isbox=8'h11; 8'h83: isbox=8'h41;
                8'h84: isbox=8'h4f; 8'h85: isbox=8'h67; 8'h86: isbox=8'hdc; 8'h87: isbox=8'hea;
                8'h88: isbox=8'h97; 8'h89: isbox=8'hf2; 8'h8a: isbox=8'hcf; 8'h8b: isbox=8'hce;
                8'h8c: isbox=8'hf0; 8'h8d: isbox=8'hb4; 8'h8e: isbox=8'he6; 8'h8f: isbox=8'h73;
                8'h90: isbox=8'h96; 8'h91: isbox=8'hac; 8'h92: isbox=8'h74; 8'h93: isbox=8'h22;
                8'h94: isbox=8'he7; 8'h95: isbox=8'had; 8'h96: isbox=8'h35; 8'h97: isbox=8'h85;
                8'h98: isbox=8'he2; 8'h99: isbox=8'hf9; 8'h9a: isbox=8'h37; 8'h9b: isbox=8'he8;
                8'h9c: isbox=8'h1c; 8'h9d: isbox=8'h75; 8'h9e: isbox=8'hdf; 8'h9f: isbox=8'h6e;
                8'ha0: isbox=8'h47; 8'ha1: isbox=8'hf1; 8'ha2: isbox=8'h1a; 8'ha3: isbox=8'h71;
                8'ha4: isbox=8'h1d; 8'ha5: isbox=8'h29; 8'ha6: isbox=8'hc5; 8'ha7: isbox=8'h89;
                8'ha8: isbox=8'h6f; 8'ha9: isbox=8'hb7; 8'haa: isbox=8'h62; 8'hab: isbox=8'h0e;
                8'hac: isbox=8'haa; 8'had: isbox=8'h18; 8'hae: isbox=8'hbe; 8'haf: isbox=8'h1b;
                8'hb0: isbox=8'hfc; 8'hb1: isbox=8'h56; 8'hb2: isbox=8'h3e; 8'hb3: isbox=8'h4b;
                8'hb4: isbox=8'hc6; 8'hb5: isbox=8'hd2; 8'hb6: isbox=8'h79; 8'hb7: isbox=8'h20;
                8'hb8: isbox=8'h9a; 8'hb9: isbox=8'hdb; 8'hba: isbox=8'hc0; 8'hbb: isbox=8'hfe;
                8'hbc: isbox=8'h78; 8'hbd: isbox=8'hcd; 8'hbe: isbox=8'h5a; 8'hbf: isbox=8'hf4;
                8'hc0: isbox=8'h1f; 8'hc1: isbox=8'hdd; 8'hc2: isbox=8'ha8; 8'hc3: isbox=8'h33;
                8'hc4: isbox=8'h88; 8'hc5: isbox=8'h07; 8'hc6: isbox=8'hc7; 8'hc7: isbox=8'h31;
                8'hc8: isbox=8'hb1; 8'hc9: isbox=8'h12; 8'hca: isbox=8'h10; 8'hcb: isbox=8'h59;
                8'hcc: isbox=8'h27; 8'hcd: isbox=8'h80; 8'hce: isbox=8'hec; 8'hcf: isbox=8'h5f;
                8'hd0: isbox=8'h60; 8'hd1: isbox=8'h51; 8'hd2: isbox=8'h7f; 8'hd3: isbox=8'ha9;
                8'hd4: isbox=8'h19; 8'hd5: isbox=8'hb5; 8'hd6: isbox=8'h4a; 8'hd7: isbox=8'h0d;
                8'hd8: isbox=8'h2d; 8'hd9: isbox=8'he5; 8'hda: isbox=8'h7a; 8'hdb: isbox=8'h9f;
                8'hdc: isbox=8'h93; 8'hdd: isbox=8'hc9; 8'hde: isbox=8'h9c; 8'hdf: isbox=8'hef;
                8'he0: isbox=8'ha0; 8'he1: isbox=8'he0; 8'he2: isbox=8'h3b; 8'he3: isbox=8'h4d;
                8'he4: isbox=8'hae; 8'he5: isbox=8'h2a; 8'he6: isbox=8'hf5; 8'he7: isbox=8'hb0;
                8'he8: isbox=8'hc8; 8'he9: isbox=8'heb; 8'hea: isbox=8'hbb; 8'heb: isbox=8'h3c;
                8'hec: isbox=8'h83; 8'hed: isbox=8'h53; 8'hee: isbox=8'h99; 8'hef: isbox=8'h61;
                8'hf0: isbox=8'h17; 8'hf1: isbox=8'h2b; 8'hf2: isbox=8'h04; 8'hf3: isbox=8'h7e;
                8'hf4: isbox=8'hba; 8'hf5: isbox=8'h77; 8'hf6: isbox=8'hd6; 8'hf7: isbox=8'h26;
                8'hf8: isbox=8'he1; 8'hf9: isbox=8'h69; 8'hfa: isbox=8'h14; 8'hfb: isbox=8'h63;
                8'hfc: isbox=8'h55; 8'hfd: isbox=8'h21; 8'hfe: isbox=8'h0c; 8'hff: isbox=8'h7d;
            endcase
        end
    endfunction

    // ==================================================================
    // GF(2^8) helpers
    // ==================================================================
    function [7:0] gm2;
        input [7:0] a;
        begin gm2 = {a[6:0], 1'b0} ^ (a[7] ? 8'h1b : 8'h00); end
    endfunction
    function [7:0] gm3;
        input [7:0] a;
        begin gm3 = gm2(a) ^ a; end
    endfunction
    function [7:0] gm9;
        input [7:0] a;
        begin gm9 = gm2(gm2(gm2(a))) ^ a; end
    endfunction
    function [7:0] gm11;
        input [7:0] a;
        begin gm11 = gm2(gm2(gm2(a))) ^ gm2(a) ^ a; end
    endfunction
    function [7:0] gm13;
        input [7:0] a;
        begin gm13 = gm2(gm2(gm2(a))) ^ gm2(gm2(a)) ^ a; end
    endfunction
    function [7:0] gm14;
        input [7:0] a;
        begin gm14 = gm2(gm2(gm2(a))) ^ gm2(gm2(a)) ^ gm2(a); end
    endfunction

    // MixColumns column: returns {t3,t2,t1,t0} (byte0=row0 output at [7:0])
    function [31:0] mixcol;
        input [7:0] b0, b1, b2, b3;
        reg [7:0] t0, t1, t2, t3;
        begin
            t0 = gm2(b0) ^ gm3(b1) ^ b2 ^ b3;
            t1 = b0 ^ gm2(b1) ^ gm3(b2) ^ b3;
            t2 = b0 ^ b1 ^ gm2(b2) ^ gm3(b3);
            t3 = gm3(b0) ^ b1 ^ b2 ^ gm2(b3);
            mixcol = {t3, t2, t1, t0};
        end
    endfunction

    // InvMixColumns column (byte0=row0 output at [7:0])
    function [31:0] invmixcol;
        input [7:0] b0, b1, b2, b3;
        reg [7:0] t0, t1, t2, t3;
        begin
            t0 = gm14(b0) ^ gm11(b1) ^ gm13(b2) ^ gm9(b3);
            t1 = gm9(b0) ^ gm14(b1) ^ gm11(b2) ^ gm13(b3);
            t2 = gm13(b0) ^ gm9(b1) ^ gm14(b2) ^ gm11(b3);
            t3 = gm11(b0) ^ gm13(b1) ^ gm9(b2) ^ gm14(b3);
            invmixcol = {t3, t2, t1, t0};
        end
    endfunction

    // ==================================================================
    // Key expansion: iterative, precomputed once per block into wreg[0..43].
    //   w[0..3] = key bytes 0..15 (LE words), loaded on start (IDLE).
    //   w[i] = w[i-4] ^ g(w[i-1]); g = RotWord+SubWord+Rcon (every 4th)
    // Computed in EXPAND state (one word/cycle), so the critical path no
    // longer chains 44 combinational words from key_reg (8+ rot_sub deep).
    // ==================================================================
    reg [31:0] wreg [0:43];
    reg [5:0]  xp_cnt;          // expansion counter 4..43

    // g-function for current expansion word (combinational on wreg[xp_cnt-1])
    wire [31:0] xp_prev = wreg[xp_cnt-1];
    wire [31:0] xp_rot_sub =
        {sbox(xp_prev[7:0]), sbox(xp_prev[31:24]), sbox(xp_prev[23:16]), sbox(xp_prev[15:8])};
    wire [31:0] xp_rcon =
        (xp_cnt[1:0]==0) ? (xp_cnt==4  ? 32'h00000001 : xp_cnt==8  ? 32'h00000002 :
         xp_cnt==12 ? 32'h00000004 : xp_cnt==16 ? 32'h00000008 : xp_cnt==20 ? 32'h00000010 :
         xp_cnt==24 ? 32'h00000020 : xp_cnt==28 ? 32'h00000040 : xp_cnt==32 ? 32'h00000080 :
         xp_cnt==36 ? 32'h0000001b : 32'h00000036) : 32'h0;
    wire [31:0] xp_g  = (xp_cnt[1:0]==0) ? (xp_rot_sub ^ xp_rcon) : xp_prev;
    wire [31:0] xp_next = wreg[xp_cnt-4] ^ xp_g;

    // Round key selection: encrypt rk_sel=round (0..10), decrypt rk_sel=10-round
    wire [3:0] rk_sel = mode ? round[3:0] : (ROUNDS[3:0] - round[3:0]);
    wire [31:0] rk_w0 = wreg[rk_sel*4 + 0];
    wire [31:0] rk_w1 = wreg[rk_sel*4 + 1];
    wire [31:0] rk_w2 = wreg[rk_sel*4 + 2];
    wire [31:0] rk_w3 = wreg[rk_sel*4 + 3];
    // LE assembly: byte0=w0[7:0], byte4=w1[7:0], ... -> round_key bytes
    wire [127:0] round_key = {rk_w3, rk_w2, rk_w1, rk_w0};

    // ==================================================================
    // Round transform (combinational, based on current state)
    // ==================================================================
    reg [127:0] state;
    wire [7:0] b [0:15];
    assign b[0] =state[7:0];   assign b[1] =state[15:8];  assign b[2] =state[23:16]; assign b[3] =state[31:24];
    assign b[4] =state[39:32]; assign b[5] =state[47:40]; assign b[6] =state[55:48]; assign b[7] =state[63:56];
    assign b[8] =state[71:64]; assign b[9] =state[79:72]; assign b[10]=state[87:80]; assign b[11]=state[95:88];
    assign b[12]=state[103:96];assign b[13]=state[111:104];assign b[14]=state[119:112];assign b[15]=state[127:120];

    // ShiftRows output byte sh[k] = byte k of state after row shift
    wire [7:0] sh [0:15];
    // col0 = bytes 0,1,2,3 = rows 0..3
    assign sh[0]=b[0];  assign sh[1]=b[5];  assign sh[2]=b[10]; assign sh[3]=b[15];
    assign sh[4]=b[4];  assign sh[5]=b[9];  assign sh[6]=b[14]; assign sh[7]=b[3];
    assign sh[8]=b[8];  assign sh[9]=b[13]; assign sh[10]=b[2]; assign sh[11]=b[7];
    assign sh[12]=b[12];assign sh[13]=b[1]; assign sh[14]=b[6]; assign sh[15]=b[11];

    // InvShiftRows
    wire [7:0] ish [0:15];
    assign ish[0]=b[0];  assign ish[1]=b[13]; assign ish[2]=b[10]; assign ish[3]=b[7];
    assign ish[4]=b[4];  assign ish[5]=b[1];  assign ish[6]=b[14]; assign ish[7]=b[11];
    assign ish[8]=b[8];  assign ish[9]=b[5];  assign ish[10]=b[2]; assign ish[11]=b[15];
    assign ish[12]=b[12];assign ish[13]=b[9]; assign ish[14]=b[6]; assign ish[15]=b[3];

    wire [7:0] ss [0:15];
    wire [7:0] iss [0:15];
    genvar si;
    generate
        for (si = 0; si < 16; si = si + 1) begin : g_sub
            assign ss[si]  = sbox(sh[si]);
            assign iss[si] = isbox(ish[si]);
        end
    endgenerate

    // MixColumns on substituted matrix
    wire [31:0] mc0 = mixcol(ss[0], ss[1], ss[2], ss[3]);
    wire [31:0] mc1 = mixcol(ss[4], ss[5], ss[6], ss[7]);
    wire [31:0] mc2 = mixcol(ss[8], ss[9], ss[10], ss[11]);
    wire [31:0] mc3 = mixcol(ss[12], ss[13], ss[14], ss[15]);
    // InvMixColumns on inv-substituted matrix
    wire [31:0] imc0 = invmixcol(iss[0], iss[1], iss[2], iss[3]);
    wire [31:0] imc1 = invmixcol(iss[4], iss[5], iss[6], iss[7]);
    wire [31:0] imc2 = invmixcol(iss[8], iss[9], iss[10], iss[11]);
    wire [31:0] imc3 = invmixcol(iss[12], iss[13], iss[14], iss[15]);

    // Reassemble into LE 128-bit: col c occupies bytes [4c..4c+3], byte0 of
    // column = row0 output.  mc_c[7:0] = row0 output of col c.
    wire [127:0] enc_mix = {mc3, mc2, mc1, mc0};
    wire [127:0] dec_mix = {imc3, imc2, imc1, imc0};
    wire [127:0] enc_sub =
        {ss[15],ss[14],ss[13],ss[12],ss[11],ss[10],ss[9],ss[8],
         ss[7],ss[6],ss[5],ss[4],ss[3],ss[2],ss[1],ss[0]};
    wire [127:0] dec_sub =
        {iss[15],iss[14],iss[13],iss[12],iss[11],iss[10],iss[9],iss[8],
         iss[7],iss[6],iss[5],iss[4],iss[3],iss[2],iss[1],iss[0]};

    // InvMixColumns on each column of the 128-bit round key (for decrypt,
    // equivalent-inverse-cipher form, rounds 1..9)
    wire [31:0] rk_inv0 = invmixcol(round_key[7:0],  round_key[15:8],  round_key[23:16], round_key[31:24]);
    wire [31:0] rk_inv1 = invmixcol(round_key[39:32],round_key[47:40], round_key[55:48], round_key[63:56]);
    wire [31:0] rk_inv2 = invmixcol(round_key[71:64],round_key[79:72], round_key[87:80], round_key[95:88]);
    wire [31:0] rk_inv3 = invmixcol(round_key[103:96],round_key[111:104],round_key[119:112],round_key[127:120]);
    wire [127:0] rk_inv128 = {rk_inv3, rk_inv2, rk_inv1, rk_inv0};

    // state_next for current round
    wire [127:0] rnd = mode ?
        (round == ROUNDS ? enc_sub : enc_mix) :
        (round == ROUNDS ? dec_sub : dec_mix);
    wire [127:0] rk0_enc = {wreg[3], wreg[2], wreg[1], wreg[0]};
    wire [127:0] rk0_dec = {wreg[43], wreg[42], wreg[41], wreg[40]};
    // decrypt rounds 1..9: use InvMixColumns'ed round key (equivalent inverse cipher)
    wire [127:0] rk_eff = (mode || round == 4'd0 || round == ROUNDS) ? round_key : rk_inv128;
    wire [127:0] state_next = (round == 4'd0) ?
        (data_in ^ (mode ? rk0_enc : rk0_dec)) :
        (rnd ^ rk_eff);

    // ==================================================================
    // FSM: IDLE -> EXPAND -> RUN -> FIN
    //   EXPAND: precompute 44 round-key words into wreg (one word/cycle).
    //   RUN   : one round transform per cycle (round_key from wreg mux).
    // Latency: 1 (expand start) + ~40 (expand) + 11 (run) + 1 (fin) ~= 53 cyc/block.
    // ==================================================================
    reg [3:0] round;
    reg [1:0] fsm;
    localparam IDLE = 2'd0, EXPAND = 2'd1, RUN = 2'd2, FIN = 2'd3;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            fsm <= IDLE; round <= 0; xp_cnt <= 0;
            state <= 128'b0;
            aes_state <= 0; rk_ready <= 1; data_out_valid <= 0; data_out <= 128'b0;
        end else begin
            data_out_valid <= 1'b0;
            case (fsm)
                IDLE: begin
                    rk_ready <= 1'b1;
                    if (en && data_in_valid) begin
                        // latch key into wreg[0..3], start expansion
                        wreg[0] <= key_in[31:0];   wreg[1] <= key_in[63:32];
                        wreg[2] <= key_in[95:64];  wreg[3] <= key_in[127:96];
                        xp_cnt  <= 6'd4;
                        fsm     <= EXPAND;
                        aes_state <= 1'b1; rk_ready <= 1'b0;
                    end
                end
                EXPAND: begin
                    wreg[xp_cnt] <= xp_next;
                    if (xp_cnt == 6'd43) begin
                        fsm <= RUN; round <= 4'd0;
                    end else begin
                        xp_cnt <= xp_cnt + 6'd1;
                    end
                end
                RUN: begin
                    state <= state_next;
                    if (round == ROUNDS) begin
                        fsm <= FIN; round <= 4'd0;
                    end else begin
                        round <= round + 4'd1;
                    end
                end
                FIN: begin
                    data_out <= state;
                    data_out_valid <= 1'b1;
                    aes_state <= 1'b0;
                    rk_ready <= 1'b1;
                    fsm <= IDLE;
                end
                default: fsm <= IDLE;
            endcase
        end
    end

endmodule
