`timescale 1ns / 1ps
// ---------------------------------------------------------------------------
// sha3_512_33b.v -- SHA3-512 (33B -> 64B) 用于 keygen 的 G 函数
//
// G(d||k) = SHA3-512(d[32] || k[1])  ->  rho[32] || sigma[32]
//   (FIPS 203 K-PKE.KeyGen step 1: (rho, sigma) = G(d || k))
//
// SHA3-512 rate = 72 字节 (9 lane)。输入 33B 单 block:
//   lane0..3 = d[32B], lane4 byte0 = 0x06 (域分离 SHA3-512),
//   lane8 byte7 |= 0x80 (pad10*1)
// 输出: 64B = 8 lane (rho = out[255:0], sigma = out[511:256], LE)
//
// 复用 keccak_f1600_core (24 轮置换, 1 round/cycle, ~26 拍)。
// 接口风格同 shake256_rand.v:
//   go    : 上升沿触发一次 (level? 与 shake256_rand 一致: go 拉高进入, 内部清理)
//   din   : 33 字节输入 (din[263:0]: byte0..byte32, din[7:0]=byte0 LE)
//   busy  : 1 = 处理中
//   valid : 输出有效脉冲 (1 拍)
//   out   : 64 字节输出 (rho=out[255:0], sigma=out[511:256], LE)
// ---------------------------------------------------------------------------
module sha3_512_33b (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         go,
    input  wire [263:0] din,        // 33B
    output reg          busy,
    output reg          valid,
    output reg  [511:0] out
);

    // ---------------------------------------------------------------------
    // keccak_f1600_core (1 次置换即可: 33B 单 block absorb + 1 次 squeeze)
    // ---------------------------------------------------------------------
    reg  [1599:0] core_in;
    wire          core_busy, core_done;
    wire [1599:0] core_out;
    reg           core_go;
    keccak_f1600_core u_core (
        .clk       (clk),
        .rst_n     (rst_n),
        .go        (core_go),
        .state_in  (core_in),
        .busy      (core_busy),
        .done      (core_done),
        .state_out (core_out)
    );

    // ---------------------------------------------------------------------
    // FSM
    // ---------------------------------------------------------------------
    localparam S_IDLE  = 2'd0;
    localparam S_CORE  = 2'd1;
    localparam S_COREW = 2'd2;
    localparam S_OUT   = 2'd3;
    localparam S_DONE0 = 3'd4;   // 实际用 3-bit 避免歧义

    reg [2:0] state;
    integer   i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= S_IDLE;
            busy     <= 1'b0;
            valid    <= 1'b0;
            core_go  <= 1'b0;
            out      <= 512'd0;
        end else begin
            valid   <= 1'b0;
            core_go <= 1'b0;

            case (state)
                S_IDLE: begin
                    if (go) begin
                        busy <= 1'b1;
                        // 装配 33B block: lane0..3 = d(32B), lane4 byte0=0x06, lane8 byte7|=0x80
                        for (i = 0; i < 25; i = i + 1)
                            core_in[64*i +: 64] <= 64'd0;
                        core_in[ 63:   0] <= din[ 63:  0];   // byte0..7
                        core_in[127:  64] <= din[127: 64];   // byte8..15
                        core_in[191: 128] <= din[191:128];   // byte16..23
                        core_in[255: 192] <= din[255:192];   // byte24..31
                        core_in[319: 256] <= {48'd0, 8'h06, din[263:256]};  // [7:0]=byte0=2, [15:8]=byte1=0x06
                        core_in[575: 512] <= 64'h8000000000000000;           // lane8 byte7 |= 0x80
                        state <= S_CORE;
                    end
                end

                S_CORE: begin
                    core_go <= 1'b1;
                    state   <= S_COREW;
                end

                S_COREW: begin
                    if (core_done) begin
                        state <= S_OUT;
                    end
                end

                S_OUT: begin
                    // core_out lane0..7 = out (64B), LE
                    out[ 63:   0] <= core_out[ 63:  0];
                    out[127:  64] <= core_out[127: 64];
                    out[191: 128] <= core_out[191:128];
                    out[255: 192] <= core_out[255:192];
                    out[319: 256] <= core_out[319:256];
                    out[383: 320] <= core_out[383:320];
                    out[447: 384] <= core_out[447:384];
                    out[511: 448] <= core_out[511:448];
                    state <= S_DONE0;
                end

                S_DONE0: begin
                    busy  <= 1'b0;
                    valid <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
