// ============================================================================
// rst_sync.v -- 异步复位同步释放器 (复位同步器)
//
// 用途: MMCM/PLL 接入后, 把板级异步复位 + locked 组合信号同步到工作时钟域.
//   - 异步断言: rstn 拉低立即复位 (元胞级)
//   - 同步释放: rstn 释放后, 再等 2 个时钟沿才释放 (防复位释放时刻 metastability)
//   - 保证 MMCM 未锁定期间 (locked=0) 设计保持复位, 防止自由运行
// ============================================================================
`timescale 1ns/1ps
module rst_sync (
    input  wire clk,       // 工作时钟 (PLL 输出域)
    input  wire rstn,      // 异步复位输入, 低有效 (rst_n & locked)
    output wire rstn_out   // 同步后的复位, 低有效
);

    reg [1:0] rst_meta, rst_sync_r;

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            rst_meta  <= 1'b0;
            rst_sync_r <= 1'b0;
        end else begin
            rst_meta  <= 1'b1;
            rst_sync_r <= rst_meta;
        end
    end

    assign rstn_out = rst_sync_r;

endmodule
