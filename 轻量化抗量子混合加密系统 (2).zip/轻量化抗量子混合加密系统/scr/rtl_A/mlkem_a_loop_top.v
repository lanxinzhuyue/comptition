// ============================================================================
// mlkem_a_loop_top.v -- A 板加密闭环顶层 (Phase 5, AES-128 encrypted loop)
//
// 数据流 (双 UART):
//   uart1_rx  : PC -> A   [0xAA][pt:16B]    明文帧 (PK_FROM_UART=0, tb/旧协议)
//               PC -> A   [0xAA][0x01][pk_B:800B] 对端公钥帧 (PK_FROM_UART=1)
//               PC -> A   [0xAA][0x02][pt:16B]    明文帧 (PK_FROM_UART=1)
//   keygen    : 板内 RTL keygen(d_A,z_A) -> (pk_A,sk_A)  (pk_A 本环未外发)
//   encaps    : HLS mlkem_a_top, 用对端 pk_B 与共享 m -> (ct, ss)
//   aes       : AES-128 加密, key = ss[0:16] -> ct_aes
//   uart2_tx  : A -> B   [0xAA][ct:768B][ct_aes:16B]   密文帧
//
// 随机性: USE_RAND=1 时 d/z/m 由内部 rand_src (TRNG+SHAKE256, NUM_RUNS=2) 产生,
//         会话期间固定, 复位换一组; USE_RAND=0 时由端口 d_in/z_in/m_in 注入 (tb).
// 对端 pk_B: PK_FROM_UART=1 时经 uart1 收包存 pkb_buf[0:799], pkB_ready 为收满电平;
//           PK_FROM_UART=0 时由端口 pkB_w_q/pkB_ready 提供 (tb 直连 B 板).
//
// 波特率: source4 uart_rx/tx 的 baud_cnt 为 16 位, 需 CLK_FREQ/UART_BPS<=65535.
//         50MHz/115200=434 (上板) 与 50MHz/1.152M=43 (10x 仿真加速) 均安全.
// ============================================================================
`timescale 1ns/1ps
module mlkem_a_loop_top #(
    parameter CLK_FREQ      = 50_000_000,
    parameter BAUD_RATE     = 1_152_000,     // 10x 仿真加速 (43 分频)
    parameter PT_BYTES      = 16,
    parameter CT_BYTES      = 768,
    parameter CTAES_BYTES   = 16,
    parameter TX2_TOTAL     = 785,           // 0xAA(1) + ct(768) + ct_aes(16)
    parameter USE_RAND      = 0,             // 1=d/z/m 用内部 TRNG+SHAKE256; 0=端口注入
    parameter PK_FROM_UART  = 0,             // 1=pk_B 经 uart1 收包; 0=端口提供 (tb)
    parameter AUTO_NEGO     = 0,             // 1=自动协商: pk_B 帧经 uart_nego_rx 收
    parameter SIM_MODE      = 1              // 1=LFSR(仿真), 0=真TRNG(上板)
) (
    input  wire clk,
    input  wire rst_n,          // 低有效

    // UART1: PC -> A (明文帧 / pk_B 帧)
    input  wire uart1_rx,
    output wire uart1_tx,       // 预留 (本环 A 不发回 PC)

    // NEGO: B -> A (pk_B 帧, 仅 AUTO_NEGO=1)
    input  wire uart_nego_rx,

    // UART2: A -> B (密文帧 [0xAA][ct][ct_aes])
    output wire uart2_tx,

    // keygen/协议输入 (USE_RAND=1 时忽略; tb 注入参考值)
    input  wire [255:0] d_in,
    input  wire [255:0] z_in,
    input  wire [255:0] m_in,

    // 对端 pk_B 字读口 (PK_FROM_UART=0 时由外部提供; =1 时内部 pkb_buf)
    output wire [7:0]  pkB_w_a,
    input  wire [31:0] pkB_w_q,
    input  wire        pkB_ready,

    // 测试旁路 (上板接 0): 跳过 ML-KEM 核, 注入已知 ss/ct,
    // 快速验证 UART 帧 + AES 接线 (核不启动, 省去 ML-KEM 仿真时间)
    input  wire        bypass_mlkem,
    input  wire [255:0] ss_bypass,        // 注入 ss
    output wire [7:0]  ct_bypass_w_a,     // 注入 ct 读地址 (tb 提供)
    input  wire [31:0] ct_bypass_w_q,     // 注入 ct 数据

    output reg         led,
    output reg         done,
    output wire [255:0] ss_out
);

    // ==================================================================
    // UART 收发
    // ==================================================================
    wire        uart1_rx_done;  wire [7:0] uart1_rx_data;
    wire        uart1_tx_busy;
    reg         uart1_tx_en;    reg [7:0] uart1_tx_data;
    wire        uart2_tx_busy;
    reg         uart2_tx_en;    reg [7:0] uart2_tx_data;
    // AUTO_NEGO: 协商 RX (B -> A)
    wire        negrx_done;  wire [7:0] negrx_data;

    uart_rx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_rx1 (
        .clk(clk), .rst_n(rst_n), .uart_rxd(uart1_rx),
        .uart_rx_done(uart1_rx_done), .uart_rx_data(uart1_rx_data)
    );
    uart_rx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_rx_nego (
        .clk(clk), .rst_n(rst_n), .uart_rxd(uart_nego_rx),
        .uart_rx_done(negrx_done), .uart_rx_data(negrx_data)
    );
    uart_tx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_tx1 (
        .clk(clk), .rst_n(rst_n), .uart_tx_en(uart1_tx_en),
        .uart_tx_data(uart1_tx_data), .uart_txd(uart1_tx), .uart_tx_busy(uart1_tx_busy)
    );
    uart_tx #(.CLK_FREQ(CLK_FREQ), .UART_BPS(BAUD_RATE)) u_tx2 (
        .clk(clk), .rst_n(rst_n), .uart_tx_en(uart2_tx_en),
        .uart_tx_data(uart2_tx_data), .uart_txd(uart2_tx), .uart_tx_busy(uart2_tx_busy)
    );

    // ==================================================================
    // 随机源 (TRNG + SHAKE256) -- USE_RAND=1 才例化
    // ==================================================================
    wire [255:0] rand_d, rand_z, rand_m;
    wire         rand_ok;
    generate
        if (USE_RAND) begin : g_rand
            rand_src #(.SIM_MODE(SIM_MODE), .NUM_RUNS(2)) u_rand (
                .clk(clk), .rst_n(rst_n),
                .d_out(rand_d), .z_out(rand_z), .m_out(rand_m),
                .all_valid(rand_ok)
            );
        end else begin : g_rand_off
            assign rand_d = 256'd0; assign rand_z = 256'd0; assign rand_m = 256'd0;
            assign rand_ok = 1'b0;
        end
    endgenerate
    // 有效随机值 mux: USE_RAND=1 -> rand_src; =0 -> 端口注入
    wire [255:0] d_eff = USE_RAND ? rand_d : d_in;
    wire [255:0] z_eff = USE_RAND ? rand_z : z_in;
    wire [255:0] m_eff = USE_RAND ? rand_m : m_in;
    wire         all_valid = USE_RAND ? rand_ok : 1'b1;

    // ==================================================================
    // pk_B 收包 (仅 PK_FROM_UART=1 工作): [0xAA][0x01][pk:800] / [0xAA][0x02][pt:16]
    // 收包器在后台常驻, 主 FSM S_IDLE 只等 pt_frame_done。
    // PK_FROM_UART=0 时恒在 P_IDLE, 不干扰旧协议 (主 FSM 走 S_RX_PT)。
    // ==================================================================
    reg [7:0]  pkb_buf [0:799];          // 对端 pk_B 缓存 (PK=1)

    // ---- pkb_buf 单写端口仲裁 ----
    // 两个收包器 (uart1 旧路径 / nego 自动协商) 各驱动一组写请求, 二选一后由
    // pump 写进 pkb_buf。若两个 always 直接写同一 RAM, Vivado 报
    // Synth 8-2913 (Unsupported Dual Port Block-RAM template)。
    reg        pkb_wen_u;   reg [9:0] pkb_waddr_u;   reg [7:0] pkb_wdata_u;  // uart1 收包器
    reg        pkb_wen_n;   reg [9:0] pkb_waddr_n;   reg [7:0] pkb_wdata_n;  // nego 收包器
    wire       pkb_wen   = AUTO_NEGO ? pkb_wen_n   : pkb_wen_u;
    wire [9:0] pkb_waddr = AUTO_NEGO ? pkb_waddr_n : pkb_waddr_u;
    wire [7:0] pkb_wdata = AUTO_NEGO ? pkb_wdata_n : pkb_wdata_u;
    always @(posedge clk) begin
        if (pkb_wen) pkb_buf[pkb_waddr] <= pkb_wdata;
    end

    reg        pkb_ready_r;              // PK=1: pk 收满电平 (保持到下次复位)
    reg [1:0]  pkrx_st;
    reg [9:0]  pkrx_cnt;                 // payload 内字节计数
    reg [7:0]  pkrx_type;
    reg        pt_done_r;                // pt 帧完成脉冲 (1拍)
    // pt_rx_buf: 收包器专用明文缓冲 (PK=1), 与主 FSM 的 pt_buf 分开,
    // 避免同一 reg 两个 always 驱动 (Vivado DRC MDRV-1 拦截)
    reg [7:0]  pt_rx_buf [0:PT_BYTES-1];
    localparam P_IDLE = 2'd0, P_TYPE = 2'd1, P_PAY = 2'd2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pkrx_st <= P_IDLE; pkrx_cnt <= 0; pkrx_type <= 0;
            pkb_ready_r <= 1'b0; pt_done_r <= 1'b0;
            pkb_wen_u <= 1'b0; pkb_waddr_u <= 0; pkb_wdata_u <= 0;
        end else begin
            pt_done_r <= 1'b0;
            pkb_wen_u <= 1'b0;
            if (!PK_FROM_UART) begin
                pkrx_st <= P_IDLE;
            end else begin
                case (pkrx_st)
                    P_IDLE: begin
                        if (uart1_rx_done && uart1_rx_data == 8'hAA)
                            pkrx_st <= P_TYPE;
                    end
                    P_TYPE: begin
                        if (uart1_rx_done) begin
                            pkrx_type <= uart1_rx_data;
                            pkrx_cnt  <= 10'd0;
                            pkrx_st   <= P_PAY;
                        end
                    end
                    P_PAY: begin
                        if (uart1_rx_done) begin
                            if (pkrx_type == 8'h01) begin
                                pkb_wen_u   <= 1'b1;
                                pkb_waddr_u <= pkrx_cnt[9:0];
                                pkb_wdata_u <= uart1_rx_data;
                                if (pkrx_cnt == 10'd799) begin
                                    pkb_ready_r <= 1'b1;      // pk 收满, 电平保持
                                    pkrx_st     <= P_IDLE;
                                end else
                                    pkrx_cnt <= pkrx_cnt + 10'd1;
                            end else begin
                                pt_rx_buf[pkrx_cnt[3:0]] <= uart1_rx_data;
                                if (pkrx_cnt == 10'd15) begin
                                    pt_done_r <= 1'b1;        // 明文帧收满脉冲
                                    pkrx_st   <= P_IDLE;
                                end else
                                    pkrx_cnt <= pkrx_cnt + 10'd1;
                            end
                        end
                    end
                    default: pkrx_st <= P_IDLE;
                endcase
            end
        end
    end
    wire pt_frame_done = pt_done_r;

    // ==================================================================
    // AUTO_NEGO: 独立 pk_B 收包器 (听 nego RX, B->A 协商直连)
    // 收完整 pk 帧 [0xAA][0x01][pk:800] 后置 pkb_nego_ready 电平。
    // 独立于 uart1 收包器, 互不干扰 (PC 明文帧仍从 uart1_rx 进)。
    // ==================================================================
    localparam N_IDLE = 2'd0, N_TYPE = 2'd1, N_PAY = 2'd2;
    reg [1:0]  negrx_st;
    reg [9:0]  negrx_cnt;
    reg [7:0]  negrx_type;
    reg        pkb_nego_ready;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            negrx_st  <= N_IDLE; negrx_cnt <= 0; negrx_type <= 0;
            pkb_nego_ready <= 1'b0;
            pkb_wen_n <= 1'b0; pkb_waddr_n <= 0; pkb_wdata_n <= 0;
        end else if (AUTO_NEGO) begin
            pkb_wen_n <= 1'b0;
            case (negrx_st)
                N_IDLE: begin
                    if (negrx_done && negrx_data == 8'hAA)
                        negrx_st <= N_TYPE;
                end
                N_TYPE: begin
                    if (negrx_done) begin
                        negrx_type <= negrx_data;
                        negrx_cnt  <= 10'd0;
                        negrx_st   <= (negrx_data == 8'h01) ? N_PAY : N_IDLE;
                    end
                end
                N_PAY: begin
                    if (negrx_done && negrx_type == 8'h01) begin
                        pkb_wen_n   <= 1'b1;
                        pkb_waddr_n <= negrx_cnt[9:0];
                        pkb_wdata_n <= negrx_data;
                        if (negrx_cnt == 10'd799) begin
                            pkb_nego_ready <= 1'b1;   // pk 收满, 电平保持
                            negrx_st       <= N_IDLE;
                        end else
                            negrx_cnt <= negrx_cnt + 10'd1;
                    end
                end
                default: negrx_st <= N_IDLE;
            endcase
        end else begin
            // AUTO_NEGO=0: nego 收包器禁用 (保持 IDLE)
            negrx_st  <= N_IDLE; negrx_cnt <= 0; negrx_type <= 0;
            pkb_wen_n <= 1'b0;
        end
    end

    // pkB_ready_eff: AUTO_NEGO? nego ready; PK_FROM_UART? uart1 收包 ready; else 端口
    wire        pkB_ready_eff = AUTO_NEGO ? pkb_nego_ready
                              : (PK_FROM_UART ? pkb_ready_r : pkB_ready);

    // pkB 来源 mux: AUTO_NEGO/PK=1 -> 内部 pkb_buf (core 驱动读地址), =0 -> 端口
    wire [7:0]  pkB_w_a_core;                                  // core 输出读地址
    wire [31:0] pkb_w_q = {pkb_buf[pkB_w_a_core*4+3], pkb_buf[pkB_w_a_core*4+2],
                           pkb_buf[pkB_w_a_core*4+1], pkb_buf[pkB_w_a_core*4+0]};
    assign pkB_w_a = pkB_w_a_core;
    wire [31:0] pkB_w_q_eff   = AUTO_NEGO ? pkb_w_q
                              : (PK_FROM_UART ? pkb_w_q : pkB_w_q);

    // ==================================================================
    // 密钥协商核心 (keygen RTL + HLS encaps)
    // ==================================================================
    wire        agr_start;
    wire        agr_done;              // 核 done 脉冲
    wire [255:0] core_ss;              // 核 ss
    wire [7:0]  ct_w_a;  wire [31:0] core_ct_w_q;
    mlkem_a_agreement_core u_core (
        .clk(clk), .rst(~rst_n),
        .start(bypass_mlkem ? 1'b0 : agr_start),   // 旁路: 核不启动
        .d_in(d_eff), .z_in(z_eff), .m_in(m_eff),
        .pkB_w_a(pkB_w_a_core), .pkB_w_q(pkB_w_q_eff), .pkB_ready(pkB_ready_eff),
        .done(agr_done), .ct_ready(),
        .ct_w_a(ct_w_a), .ct_w_q(core_ct_w_q),
        .ss(core_ss)
    );

    // ---- 测试旁路: 跳过 ML-KEM 核, 注入已知 ss/ct ----
    // ct_w_q: 旁路时由 tb 按 ct_w_a 地址喂回 (loop_ct.dat)
    // agr_done: 旁路时由内部 2 拍延时代替核
    wire [31:0] ct_w_q = bypass_mlkem ? ct_bypass_w_q : core_ct_w_q;
    assign ss_out       = bypass_mlkem ? ss_bypass    : core_ss;
    assign ct_bypass_w_a = ct_w_a;      // 暴露核读地址给 tb (旁路时查表用)

    reg bypass_done_r;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            bypass_done_r <= 1'b0;
        else if (state == S_AGREE) begin
            if (bypass_done_r)
                bypass_done_r <= 1'b0;
            else
                bypass_done_r <= 1'b1;
        end else
            bypass_done_r <= 1'b0;
    end
    wire agr_done_eff = bypass_mlkem ? bypass_done_r : agr_done;

    // ==================================================================
    // 明文帧缓冲 (来自 uart1: PK=1 由收包器写 pt_rx_buf, PK=0 由主 FSM 写 pt_buf)
    // 两个缓冲各自单驱动 (避免 Vivado DRC MDRV-1 多驱动拦截)
    // ==================================================================
    reg [7:0]  pt_buf [0:PT_BYTES-1];
    reg [3:0]  rx_pt_cnt;        // 0..15 (仅 PK=0)

    // 明文源选择: PK=1 -> 收包器缓冲 pt_rx_buf; PK=0 -> 主 FSM 缓冲 pt_buf
    wire [7:0] pt_sel [0:PT_BYTES-1];
    genvar gpt;
    generate
        for (gpt = 0; gpt < PT_BYTES; gpt = gpt + 1) begin : g_ptsel
            assign pt_sel[gpt] = PK_FROM_UART ? pt_rx_buf[gpt] : pt_buf[gpt];
        end
    endgenerate

    // ==================================================================
    // AES-128 (encrypt)
    // ==================================================================
    wire       aes_busy, aes_valid;
    wire [127:0] aes_out;
    reg        aes_start;
    aes_block_top u_aes (
        .clk(clk), .rstn(rst_n), .start(aes_start), .mode(1'b1),
        .key_in(ss_out[127:0]),        // ss 前 16 字节 (byte0=[7:0])
        .data_in({pt_sel[15],pt_sel[14],pt_sel[13],pt_sel[12],
                  pt_sel[11],pt_sel[10],pt_sel[9 ],pt_sel[8 ],
                  pt_sel[7 ],pt_sel[6 ],pt_sel[5 ],pt_sel[4 ],
                  pt_sel[3 ],pt_sel[2 ],pt_sel[1 ],pt_sel[0 ]}),
        .busy(aes_busy), .data_out_valid(aes_valid), .data_out(aes_out)
    );

    // ==================================================================
    // 密文帧缓冲 (ct_aes 16B) + TX 引擎
    // ==================================================================
    reg  [7:0]  ctaes_buf [0:CTAES_BYTES-1];
    reg  [10:0] tx2_cnt;             // 帧内字节 0..784
    // 注: 发送握手不再用额外 ack 寄存器 -- 直接判 !uart2_tx_en (同 always 内
    // 读当前寄存器值, en 非阻塞更新在上拍已生效, 下一拍必读到 1, 自然拦下
    // 重复 en), 配合 !uart2_tx_busy 保证每字节只 en 一次。
    // ct 字读: 帧字节 idx 1..768 -> ct 字节 (字=(idx-1)/4, 字内偏移=(idx-1)%4)
    wire [9:0]  ct_byte_idx = tx2_cnt - 11'd1;       // 0..767
    wire [7:0]  ct_w_sel    = ct_byte_idx[9:2];      // 0..191
    wire [1:0]  ct_b_sel    = ct_byte_idx[1:0];
    wire [3:0]  ctaes_idx   = tx2_cnt - 11'd769;     // 0..15

    // ==================================================================
    // 主状态机
    // ==================================================================
    localparam [3:0] S_IDLE   = 4'd0,  // 等明文帧 (PK=1: pt_frame_done; =0: 帧头)
                     S_RX_PT  = 4'd1,  // 收 16 字节明文 (仅 PK=0)
                     S_AGREE  = 4'd2,  // keygen+encaps (等 agr_done 脉冲)
                     S_AES    = 4'd3,  // AES 加密
                     S_TX2    = 4'd4,  // uart2 发 [0xAA][ct][ct_aes]
                     S_DONE   = 4'd5;
    reg [3:0] state;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state       <= S_IDLE;
            rx_pt_cnt   <= 0;
            aes_start   <= 0;
            tx2_cnt     <= 0;
            uart2_tx_en <= 0;   uart2_tx_data <= 0;
            uart1_tx_en <= 0;   uart1_tx_data <= 0;
            led         <= 0;   done <= 0;
        end else begin
            uart2_tx_en <= 0;   // 默认关发送脉冲
            uart1_tx_en <= 0;
            aes_start   <= 0;
            done        <= 0;

            case (state)
                // ---------------- S_IDLE: 等明文帧 ----------------
                S_IDLE: begin
                    led <= 1'b0;
                    if (AUTO_NEGO) begin
                        // 自动协商: 协商完成 (pkB_ready_eff=pkb_nego_ready) 后，
                        // 才响应 PC 明文帧 (pt_frame_done) → S_AGREE。
                        if (pkB_ready_eff && pt_frame_done)
                            state <= S_AGREE;
                    end else if (PK_FROM_UART) begin
                        // 收包器在后台解析 [0xAA][0x01][pk] / [0xAA][0x02][pt],
                        // pk 帧置 pkb_ready_r, 明文帧拉 pt_frame_done
                        if (pt_frame_done)
                            state <= S_AGREE;
                    end else if (uart1_rx_done && uart1_rx_data == 8'hAA) begin
                        state <= S_RX_PT;
                    end
                end

                // ---------------- S_RX_PT: 收明文 (仅 PK=0) ----------------
                S_RX_PT: begin
                    if (uart1_rx_done) begin
                        pt_buf[rx_pt_cnt] <= uart1_rx_data;
                        if (rx_pt_cnt == 4'd15)   // PT_BYTES-1 = 15 (避免位宽扩展陷阱)
                            state <= S_AGREE;
                        else
                            rx_pt_cnt <= rx_pt_cnt + 1'b1;
                    end
                end

                // ---------------- S_AGREE: 启动核心, 等 done ----------------
                S_AGREE: begin
                    if (agr_done_eff) begin
                        aes_start <= 1'b1;      // 打 AES 启动脉冲
                        state     <= S_AES;
                    end
                end

                // ---------------- S_AES: 等 AES 完成, 存 ct_aes ----------------
                S_AES: begin
                    if (aes_valid) begin
                        ctaes_buf[ 0] <= aes_out[7:0];   ctaes_buf[ 8] <= aes_out[71:64];
                        ctaes_buf[ 1] <= aes_out[15:8];  ctaes_buf[ 9] <= aes_out[79:72];
                        ctaes_buf[ 2] <= aes_out[23:16]; ctaes_buf[10] <= aes_out[87:80];
                        ctaes_buf[ 3] <= aes_out[31:24]; ctaes_buf[11] <= aes_out[95:88];
                        ctaes_buf[ 4] <= aes_out[39:32]; ctaes_buf[12] <= aes_out[103:96];
                        ctaes_buf[ 5] <= aes_out[47:40]; ctaes_buf[13] <= aes_out[111:104];
                        ctaes_buf[ 6] <= aes_out[55:48]; ctaes_buf[14] <= aes_out[119:112];
                        ctaes_buf[ 7] <= aes_out[63:56]; ctaes_buf[15] <= aes_out[127:120];
                        tx2_cnt <= 11'd0;
                        state   <= S_TX2;
                    end
                end

                // ---------------- S_TX2: 发 [0xAA][ct][ct_aes] ----------------
                // 握手: 判 !uart2_tx_en && !uart2_tx_busy。en 是非阻塞更新, 断言
                // 的下一拍本 always 读到的 uart2_tx_en 必为 1 -> 抑制重复 en;
                // uart_tx busy (寄存器) 拉高后阻塞, 拉低后发下一字节 -> 每字节只 en 一次。
                S_TX2: begin
                    if (!uart2_tx_en && !uart2_tx_busy) begin
                        uart2_tx_en <= 1'b1;
                        if (tx2_cnt == 11'd0) begin
                            uart2_tx_data <= 8'hAA;
                        end else if (tx2_cnt <= 11'd768) begin
                            // ct: ct_w_q 为组合读 (enc_out_mem[ct_w_a]), 同拍有效
                            uart2_tx_data <= ct_w_q >> (8*ct_b_sel);
                        end else begin
                            uart2_tx_data <= ctaes_buf[ctaes_idx];
                        end
                        if (tx2_cnt == 11'd784)
                            state <= S_DONE;
                        else
                            tx2_cnt <= tx2_cnt + 11'd1;
                    end
                end

                // ---------------- S_DONE ----------------
                S_DONE: begin
                    led   <= 1'b1;
                    done  <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

    // ---- 核心启动: 本会话已打脉冲标志, 等 all_valid(随机就绪) 才启动 ----
    // 用 "agr_started" 标志而非 prev_state: 避免 all_valid 在进入 S_AGREE
    // 之后才变高时脉冲被吞 (prev_state 已为 S_AGREE)。
    reg agr_start_r;
    reg agr_started;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            agr_start_r <= 1'b0;
            agr_started <= 1'b0;
        end else begin
            agr_start_r <= 1'b0;
            if (state != S_AGREE)
                agr_started <= 1'b0;          // 离开 S_AGREE 复位标志 (下轮可再启动)
            else if (!agr_started && all_valid) begin
                agr_start_r <= 1'b1;          // 打单拍脉冲
                agr_started <= 1'b1;
            end
        end
    end
    assign agr_start = agr_start_r;

    // ---- ct 字读地址: S_TX2 且发 ct 区段 ----
    assign ct_w_a = (state == S_TX2 && tx2_cnt >= 11'd1 && tx2_cnt <= 11'd768)
                    ? ct_w_sel : 8'd0;

endmodule
