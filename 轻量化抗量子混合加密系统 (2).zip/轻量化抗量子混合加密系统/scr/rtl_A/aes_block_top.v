// ============================================================================
// aes_block_top.v -- AES-128 block wrapper for the ML-KEM-AES loop
//
// Presents a clean one-block handshake around aes128_core:
//   start (pulse)  + data_in + mode -> busy asserts, data_out_valid pulses,
//   data_out holds the result until the next start.
// Key is latched on start and held for the whole block (key expansion in the
// core is combinational, so this also allows key refresh per block if needed).
//
// Byte convention identical to aes128_core: byte0 <-> [7:0] (LE packing).
// ============================================================================
`timescale 1ns / 1ps

module aes_block_top (
    input  wire        clk,
    input  wire        rstn,
    input  wire        start,        // one-cycle pulse: process data_in
    input  wire        mode,         // 1=encrypt, 0=decrypt
    input  wire [127:0] key_in,
    input  wire [127:0] data_in,
    output wire        busy,
    output reg         data_out_valid,
    output reg  [127:0] data_out
);

    reg [127:0] key_reg;
    reg [127:0] din_reg;
    reg         mode_reg;

    wire core_state, core_rk_ready, core_out_valid;
    wire [127:0] core_out;

    aes128_core u_core (
        .clk(clk), .rstn(rstn),
        .en(1'b1), .data_in_valid(go),
        .data_in(din_reg), .aes_state(core_state), .rk_ready(core_rk_ready),
        .data_out_valid(core_out_valid), .data_out(core_out),
        .key_in(key_reg), .mode(mode_reg)
    );

    reg [1:0] fsm;
    localparam IDLE = 2'd0, GOCORE = 2'd1, WAITD = 2'd2;
    reg go;

    assign busy = (fsm != IDLE);

    always @(posedge clk or negedge rstn) begin
        if (!rstn) begin
            fsm <= IDLE; go <= 0;
            key_reg <= 0; din_reg <= 0; mode_reg <= 0;
            data_out_valid <= 0; data_out <= 0;
        end else begin
            go <= 1'b0;
            data_out_valid <= 1'b0;
            case (fsm)
                IDLE: begin
                    if (start) begin
                        key_reg <= key_in; din_reg <= data_in; mode_reg <= mode;
                        fsm <= GOCORE;
                    end
                end
                GOCORE: begin
                    go <= 1'b1;
                    fsm <= WAITD;
                end
                WAITD: begin
                    if (core_out_valid) begin
                        data_out <= core_out;
                        data_out_valid <= 1'b1;
                        fsm <= IDLE;
                    end
                end
                default: fsm <= IDLE;
            endcase
        end
    end

endmodule
