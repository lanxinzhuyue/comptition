`timescale 1ns / 1ps
// ---------------------------------------------------------------------------
// trng_pdl_top.v -- TRNG 真随机源 (PDL 链 + XOR 压缩 + 采样移位)
//
// 功能: 32 路 PDL (可编程延迟线) + XOR 压缩 -> 每时钟 1 bit 真随机
//       经 256-bit 移位寄存器收集 32 字节 seed, 供 SHAKE256 后处理.
//
// 来源: source4/FPGA-based-True-Random-Number-Generator (TRNG_Module.v),
//       只读复用 PDL/Delay_Control/DFF, 加采样时序.
//
// 原理: 每路 PDL 由 LUT4 反相链构成, 振荡频率受工艺/温度/噪声抖动,
//       32 路 XOR 后 bit 输出有真随机性. 采样 DFF 打一拍避免亚稳态.
//
// 时序 (同步采集, 防亚稳态):
//   - 每时钟上升沿采样 rand_bit (振荡信号已经 DFF 同步过)
//   - 每个 sysclk 周期收集 1 bit;  32 字节 = 256 个时钟 = 256/(50M) = 5.12us
//   - 采样点可选: 每 2/4 时钟采 1 次 (增大相邻 bit 相关性, 更好满足熵源假设)
//
// 接口:
//   rst_n    : 复位 (低有效, 高即采样开始)
//   seed[255:0] : 32 字节随机输出 (seed[7:0]=byte0)
//   rand_bit : 单 bit 熵源观测
//
// SIM_MODE: 1 = 仿真用 LFSR 伪随机源 (确定性可测, 不例化 TRNG 振荡);
//           0 = 上板用真 TRNG (PDL 振荡, 需 unisim LUT4)
// ---------------------------------------------------------------------------
module trng_pdl_top #(
    parameter SIM_MODE = 1
) (
    input  wire         clk,
    input  wire         rst_n,
    output reg  [255:0] seed,
    output wire         rand_bit,   // 调试/熵源观测
    output reg          seed_valid  // 256-bit seed 收集满的标志 (每 256 bit 拉高 1 拍)
);

    // ---- 熵源: 真 TRNG (上板) 或 LFSR (仿真) ----
    wire trng_out;
    reg  en, clr;

    generate
        if (SIM_MODE == 0) begin : g_real
            TRNG_Module u_trng (
                .en       (en),
                .clk      (clk),
                .clr      (clr),
                .rand_num (trng_out)
            );
        end else begin : g_sim
            // 仿真: 32-bit LFSR (Galois x^32+x^22+x^2+x+1), 每 4 拍进 1 位
            reg [31:0] lfsr;
            always @(posedge clk or negedge rst_n) begin
                if (!rst_n)
                    lfsr <= 32'hDEADBEEF;
                else if (sdiv == 2'd0)
                    lfsr <= {lfsr[30:0], lfsr[0] ^ lfsr[1] ^ lfsr[21] ^ lfsr[31]};
            end
            assign trng_out = lfsr[0];
        end
    endgenerate
    assign rand_bit = trng_out;

    // 采样计数器: 每 4 时钟采 1 bit (提高相邻采样去相关)
    reg [1:0] sdiv;
    // 位计数: 0..255
    reg [7:0] bitcnt;
    // 收集寄存器 (seed 移位)
    reg [255:0] seed_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            en         <= 1'b0;
            clr        <= 1'b1;
            sdiv       <= 2'd0;
            bitcnt     <= 8'd0;
            seed_r     <= 256'd0;
            seed       <= 256'd0;
            seed_valid <= 1'b0;
        end else begin
            seed_valid <= 1'b0;   // 默认关脉冲
            // TRNG 使能 (复位释放后启动振荡; SIM 模式忽略)
            if (clr) begin
                clr <= 1'b0;
                en  <= 1'b1;
            end
            // 每 4 拍采 1 bit
            sdiv <= sdiv + 2'd1;
            if (sdiv == 2'd0) begin
                // 采样 TRNG 输出 -> 移入 seed
                seed_r <= {seed_r[254:0], trng_out};
                if (bitcnt == 8'd255) begin
                    // 收集满 256 bit -> 锁存到 seed 输出, 拉高 seed_valid 1 拍
                    seed       <= {seed_r[254:0], trng_out};
                    seed_valid <= 1'b1;
                    bitcnt     <= 8'd0;
                end else begin
                    bitcnt <= bitcnt + 8'd1;
                end
            end
        end
    end

endmodule
