// ============================================================================
// keygen_wrap.v -- RTL ML-KEM-512 keygen wrapper (clean handshake + RAM ports)
//
// Wraps the KAT-verified hand-written mlkem_keygen_top with:
//   - 32-byte wire inputs d_in / z_in (byte0 = [7:0]), instead of a raw bram
//     interface.  d/z reads are modelled as SYNCHRONOUS (1-cycle latency),
//     exactly like tb_keygen.v does -- the keygen FSM expects d_q0 to be the
//     value captured on the previous posedge.
//   - byte read ports for pk (800B) / sk (1632B) results, combinational.
//   - simple start/done pulse handshake.
//
// Used by mlkem_a_agreement_core / mlkem_b_agreement_core (phase-5 loop).
// ============================================================================
`timescale 1ns/1ps
module keygen_wrap (
    input  wire        clk,
    input  wire        rst,          // active high (same as HLS ap_rst)
    input  wire        start,        // pulse: run keygen(d_in, z_in)
    input  wire [255:0] d_in,        // 32 bytes, byte0 = [7:0]
    input  wire [255:0] z_in,        // 32 bytes, byte0 = [7:0]
    output reg         done,         // pulse when pk/sk ready

    // pk / sk read ports (combinational)
    input  wire [9:0]  pk_a,
    output wire [7:0]  pk_q,
    input  wire [10:0] sk_a,
    output wire [7:0]  sk_q,
    // 32-bit LE word read ports (faster bulk copy into HLS input RAMs)
    input  wire [7:0]  pk_w_a,     // word index 0..199
    output wire [31:0] pk_w_q,
    input  wire [9:0]  sk_w_a,     // word index 0..407
    output wire [31:0] sk_w_q
);

    reg [7:0] pk_mem [0:799];
    reg [7:0] sk_mem [0:1631];
    assign pk_q = pk_mem[pk_a];
    assign sk_q = sk_mem[sk_a];
    assign pk_w_q = {pk_mem[pk_w_a*4+3], pk_mem[pk_w_a*4+2], pk_mem[pk_w_a*4+1], pk_mem[pk_w_a*4+0]};
    assign sk_w_q = {sk_mem[sk_w_a*4+3], sk_mem[sk_w_a*4+2], sk_mem[sk_w_a*4+1], sk_mem[sk_w_a*4+0]};

    // ---- mlkem_keygen_top ports ----
    wire [4:0]  kg_d_a;   wire kg_d_ce;
    wire [4:0]  kg_z_a;   wire kg_z_ce;
    wire [9:0]  kg_pk_a;  wire kg_pk_ce, kg_pk_we; wire [7:0] kg_pk_d;
    wire [10:0] kg_sk_a;  wire kg_sk_ce, kg_sk_we; wire [7:0] kg_sk_d;
    wire kg_done, kg_idle, kg_ready;
    reg  kg_start;

    reg [7:0] d_q0_r, z_q0_r;
    wire [7:0] d_q0 = d_q0_r;
    wire [7:0] z_q0 = z_q0_r;

    mlkem_keygen_top u_kg (
        .ap_clk      (clk),
        .ap_rst      (rst),
        .ap_start    (kg_start),
        .ap_done     (kg_done),
        .ap_idle     (kg_idle),
        .ap_ready    (kg_ready),
        .d_address0  (kg_d_a), .d_ce0 (kg_d_ce), .d_q0 (d_q0),
        .z_address0  (kg_z_a), .z_ce0 (kg_z_ce), .z_q0 (z_q0),
        .pk_address0 (kg_pk_a), .pk_ce0 (kg_pk_ce), .pk_we0 (kg_pk_we), .pk_d0 (kg_pk_d),
        .sk_address0 (kg_sk_a), .sk_ce0 (kg_sk_ce), .sk_we0 (kg_sk_we), .sk_d0 (kg_sk_d)
    );

    // d/z synchronous read model (matches tb_keygen.v, required by keygen FSM)
    always @(posedge clk) begin
        if (kg_d_ce) d_q0_r <= d_in[8*kg_d_a +: 8];
        if (kg_z_ce) z_q0_r <= z_in[8*kg_z_a +: 8];
    end

    // pk/sk write capture
    always @(posedge clk) begin
        if (kg_pk_ce && kg_pk_we) pk_mem[kg_pk_a] <= kg_pk_d;
        if (kg_sk_ce && kg_sk_we) sk_mem[kg_sk_a] <= kg_sk_d;
    end

    // ---- handshake FSM ----
    localparam W_IDLE = 2'd0, W_RUN = 2'd1;
    reg [1:0] st;
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            st <= W_IDLE; kg_start <= 0; done <= 0;
        end else begin
            kg_start <= 0;
            done     <= 0;
            case (st)
                W_IDLE: if (start) begin kg_start <= 1; st <= W_RUN; end
                W_RUN : begin
                    if (kg_done) begin done <= 1; st <= W_IDLE; end
                end
                default: st <= W_IDLE;
            endcase
        end
    end

endmodule
