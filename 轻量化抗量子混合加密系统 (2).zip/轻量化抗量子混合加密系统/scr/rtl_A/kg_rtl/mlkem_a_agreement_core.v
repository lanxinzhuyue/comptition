// ============================================================================
// mlkem_a_agreement_core.v -- A 板密钥协商核心 (keygen -> encaps -> ss)
//
// 阶段5 (AES 闭环) 子模块: 在板上跑 RTL keygen 得 (pk_A,sk_A), 接收对端 pk_B,
// 对共享明文 m 做 HLS encaps, 输出会话密钥 ss (= G(m||H(pk_B)) 前32B) 和密文 ct。
//
// 流程 (与 mlkem_b_top_uart.v 相同的 HLS bram+ap_ctrl_hs 接线):
//   S_IDLE     : 等 start
//   S_KEYGEN   : keygen_wrap(d,z) -> 内部 pk_A/sk_A (备用) + 填 pk 到 encaps in_mem
//   S_FILL_ENC : 填 encaps in_mem: word0..7 = m, word8..207 = pk_B
//   S_ENC_RUN  : ap_start 保持到 ap_done
//   S_ENC_READ : 从 encaps out_mem 读 ct(192w)+ss(8w)
//   S_DONE     : done 脉冲
//
// 端口: d/z/m 以 256-bit LE 输入; pk_B 以 200-word 输入 (来自 UART2 收包或 tb);
//       ct 经 ct_rd 组合读口; ss 以 256-bit 输出。
// ============================================================================
`timescale 1ns/1ps
module mlkem_a_agreement_core (
    input  wire        clk,
    input  wire        rst,          // high
    input  wire        start,
    input  wire [255:0] d_in,        // keygen d (byte0 = [7:0])
    input  wire [255:0] z_in,        // keygen z
    input  wire [255:0] m_in,        // shared m (byte0 = [7:0])

    // peer pk_B input: 200 32-bit LE words
    output wire [7:0]  pkB_w_a,      // word index 0..199 (this core requests)
    input  wire [31:0] pkB_w_q,
    input  wire        pkB_ready,    // peer keygen done: pk_B is valid

    output reg         done,
    output reg         ct_ready,      // level: encaps done, ct valid (held till next start)
    // ct read port: 768 bytes = 192 words LE
    input  wire [7:0]  ct_w_a,
    output wire [31:0] ct_w_q,
    // ss output
    output reg  [255:0] ss
);

    // ==================================================================
    // keygen_wrap (kg_ tree)
    // ==================================================================
    wire [9:0]  kg_pk_a;  wire [7:0] kg_pk_q;
    wire [10:0] kg_sk_a;  wire [7:0] kg_sk_q;
    wire [7:0]  kg_pk_w_a; wire [31:0] kg_pk_w_q;
    wire [9:0]  kg_sk_w_a; wire [31:0] kg_sk_w_q;
    wire        kg_done;
    reg         kg_start;
    keygen_wrap u_kg (
        .clk(clk), .rst(rst), .start(kg_start), .done(kg_done),
        .d_in(d_in), .z_in(z_in),
        .pk_a(kg_pk_a), .pk_q(kg_pk_q),
        .sk_a(kg_sk_a), .sk_q(kg_sk_q),
        .pk_w_a(kg_pk_w_a), .pk_w_q(kg_pk_w_q),
        .sk_w_a(kg_sk_w_a), .sk_w_q(kg_sk_w_q)
    );

    // ==================================================================
    // HLS encaps (mlkem_a_top)
    // ==================================================================
    wire [31:0] enc_in_Addr; wire enc_in_EN, enc_in_Clk, enc_in_Rst;
    wire [3:0]  enc_in_WEN; wire [31:0] enc_in_Din, enc_in_Dout;
    wire [31:0] enc_out_Addr; wire enc_out_EN, enc_out_Clk, enc_out_Rst;
    wire [3:0]  enc_out_WEN; wire [31:0] enc_out_Din, enc_out_Dout;
    wire enc_ap_done, enc_ap_idle, enc_ap_ready;
    reg  enc_ap_start;

    mlkem_a_top u_enc (
        .ap_clk(clk), .ap_rst(rst), .ap_start(enc_ap_start),
        .ap_done(enc_ap_done), .ap_idle(enc_ap_idle), .ap_ready(enc_ap_ready),
        .in_data_Addr_A(enc_in_Addr), .in_data_EN_A(enc_in_EN),
        .in_data_WEN_A(enc_in_WEN), .in_data_Din_A(enc_in_Din),
        .in_data_Dout_A(enc_in_Dout), .in_data_Clk_A(enc_in_Clk),
        .in_data_Rst_A(enc_in_Rst),
        .out_data_Addr_A(enc_out_Addr), .out_data_EN_A(enc_out_EN),
        .out_data_WEN_A(enc_out_WEN), .out_data_Din_A(enc_out_Din),
        .out_data_Dout_A(enc_out_Dout), .out_data_Clk_A(enc_out_Clk),
        .out_data_Rst_A(enc_out_Rst)
    );
    assign enc_in_Clk = clk;  assign enc_in_Rst = rst;
    assign enc_out_Clk = clk; assign enc_out_Rst = rst;

    // ---- encaps input BRAM (208 words) ----
    reg [31:0] enc_in_mem [0:255];
    reg [7:0]  enc_in_wa; reg enc_in_we; reg [31:0] enc_in_wd;
    reg [31:0] enc_in_dout;
    always @(posedge clk) begin
        if (enc_in_we) enc_in_mem[enc_in_wa] <= enc_in_wd;
        enc_in_dout <= enc_in_mem[enc_in_Addr[9:2]];
    end
    assign enc_in_Dout = enc_in_dout;

    // ---- encaps output BRAM (200 words) ----
    reg [31:0] enc_out_mem [0:255];
    reg [31:0] enc_out_dout;
    always @(posedge clk) begin
        if (enc_out_WEN != 4'b0)
            enc_out_mem[enc_out_Addr[9:2]] <= enc_out_Din;
        enc_out_dout <= enc_out_mem[enc_out_Addr[9:2]];
    end
    assign enc_out_Dout = enc_out_dout;

    // ct read (192 words) + ss capture
    assign ct_w_q = enc_out_mem[ct_w_a];

    // ==================================================================
    // m words
    // ==================================================================
    wire [31:0] m_word [0:7];
    genvar gmi;
    generate
        for (gmi = 0; gmi < 8; gmi = gmi + 1) begin : g_mw
            assign m_word[gmi] = m_in[32*gmi +: 32];
        end
    endgenerate

    // ==================================================================
    // FSM
    // ==================================================================
    localparam [3:0] S_IDLE=0, S_KEYGEN=1, S_FILL_ENC=2, S_ENC_RUN=3,
                     S_ENC_READ=4, S_DONE=5;
    reg [3:0] state;
    reg [9:0] cnt;      // word counter 0..207 (pkB fill) / 0..199 (read)
    reg [7:0] rd_valid;
    reg       kg_done_l;   // keygen done 脉冲锁存 (等待对端 ready 时不丢)

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; cnt <= 0; kg_start <= 0; enc_ap_start <= 0;
            done <= 0; ss <= 0; enc_in_we <= 0; enc_in_wa <= 0; enc_in_wd <= 0;
            rd_valid <= 0; ct_ready <= 0; kg_done_l <= 0;
        end else begin
            kg_start <= 0; enc_ap_start <= 0; done <= 0; enc_in_we <= 0;
            case (state)
                S_IDLE: if (start) begin state <= S_KEYGEN; cnt <= 0; ct_ready <= 0; end

                // keygen: 锁存 done 脉冲, 等对端 pk_B ready, 填 encaps in_mem
                S_KEYGEN: begin
                    if (cnt == 0) begin kg_start <= 1; cnt <= 1; end
                    else begin
                        if (kg_done) kg_done_l <= 1;
                        if (kg_done_l && pkB_ready) begin
                            kg_done_l <= 0;
                            state <= S_FILL_ENC; cnt <= 0;
                        end
                    end
                end

                // fill word0..7 = m, word8..207 = pk_B
                S_FILL_ENC: begin
                    if (cnt < 8) begin
                        enc_in_we <= 1; enc_in_wa <= cnt[7:0];
                        enc_in_wd <= m_word[cnt[7:0]];
                        cnt <= cnt + 1;
                    end else if (cnt < 208) begin
                        // pk_B: pkB_w_a = cnt-8
                        enc_in_we <= 1; enc_in_wa <= cnt[7:0];
                        enc_in_wd <= pkB_w_q;   // pkB_w_a = cnt-8 (set below)
                        cnt <= cnt + 1;
                    end else begin
                        state <= S_ENC_RUN; cnt <= 0;
                    end
                end

                S_ENC_RUN: begin
                    enc_ap_start <= 1;
                    if (enc_ap_done) begin
                        enc_ap_start <= 0;
                        state <= S_ENC_READ; cnt <= 0; rd_valid <= 0;
                    end
                end

                // read out_mem 200 words -> nothing external (ct via ct_w_q),
                // capture ss (last 8 words) into ss reg
                S_ENC_READ: begin
                    if (!rd_valid) begin
                        rd_valid <= 1;
                    end else begin
                        // capture ss: words 192..199
                        if (cnt >= 192 && cnt <= 199) begin
                            ss[32*(cnt-192) +: 32] <= enc_out_mem[cnt[7:0]];
                        end
                        if (cnt == 199) begin
                            ct_ready <= 1;       // ct is now stable/valid for B
                            state <= S_DONE; cnt <= 0;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end

                S_DONE: begin done <= 1; state <= S_IDLE; end
                default: state <= S_IDLE;
            endcase
        end
    end

    // pkB_w_a combinational: S_FILL_ENC, cnt in 8..207 -> cnt-8
    assign pkB_w_a = (state == S_FILL_ENC && cnt >= 8 && cnt < 208) ? (cnt - 8) : 8'd0;

    // keygen pk/sk read ports unused here (kept for future use / symmetry)
    assign kg_pk_a = 10'd0; assign kg_sk_a = 11'd0;
    assign kg_pk_w_a = 8'd0; assign kg_sk_w_a = 10'd0;

endmodule
