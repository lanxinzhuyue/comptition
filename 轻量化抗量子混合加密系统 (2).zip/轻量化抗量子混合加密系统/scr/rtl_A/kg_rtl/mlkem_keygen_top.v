// ============================================================================
// 阶段 4: RTL ML-KEM-512 keygen 顶层 (纯手写 Verilog)
//
// 复用 HLS 综合出的运算单元 (rtl/keygen/):
//   - kg_ntt                  NTT (r_offset 选段, zetas 外部 ROM)
//   - kg_poly_uniform         A 矩阵生成
//   - kg_poly_basemul         NTT 域乘 (r 双口写, a/b 双口读)
//   - kg_poly_add             加法: r = b + poly1
//   - kg_poly_reduce          Barrett 归约
//   - kg_poly_getnoise_eta1   CBD 采样 (nonce [1:0])
// 手写部分:
//   - sha3_512_33b  (G(d||k) -> rho||sigma)
//   - poly_tobytes  (pack int16[256] -> 384B)
//   - sha3_once_1   (H(pk))
//   - FSM 调度
//
// 端口驱动架构 (关键): 所有 RAM/外部端口由组合块单点驱动 (always @(*)),
//   时序块只驱动 state/cnt/sub/ph/go 等控制信号 + 暂存器. 无多重驱动.
//
// RAM:
//   enc_r_ram[512]  : s_hat (段 0/1)        单写口 + 双读口
//   enc_e1_ram[512] : e_hat / t_hat (段 0/1) 单写口 + 双读口
//   a_mat_ram[256]  : A 行                   单写口 + 双读口
//   poly1_ram[256]  : basemul 累加器         AUTO_1R1W 双可读写口
//   poly2_ram[256]  : basemul 单次结果       AUTO_1R1W 双可读写口
//   enc_rho_ram[64] : rho[0..31] + sigma[32..63] 单写口 + 双读口
//   pk_buf[800]     : pk 镜像 (供 H(pk), 组合读)
//
// FIPS 203 K-PKE.KeyGen (K=2):
//   (rho,sigma) = G(d||0x02)
//   s[i]=CBD(sigma,i), e[i]=CBD(sigma,i+2)
//   s_hat[i]=NTT(s[i]), e_hat[i]=NTT(e[i])
//   for i: poly1=0; for j: uniform(a_mat,rho,i,j); basemul(poly2,a_mat,s_hat[j]);
//         poly1+=poly2; t_hat[i]=e_hat[i]+poly1; reduce(t_hat[i])
//   pk = t_hat[0]||t_hat[1]||rho
//   sk = s_hat[0]||s_hat[1]||pk||H(pk)||z
// ============================================================================
`timescale 1ns/1ps
module mlkem_keygen_top (
    input  wire        ap_clk,
    input  wire        ap_rst,
    input  wire        ap_start,
    output reg         ap_done,
    output reg         ap_idle,
    output reg         ap_ready,

    output wire [4:0]  d_address0,
    output wire        d_ce0,
    input  wire [7:0]  d_q0,

    output wire [4:0]  z_address0,
    output wire        z_ce0,
    input  wire [7:0]  z_q0,

    output wire [9:0]  pk_address0,
    output wire        pk_ce0,
    output wire        pk_we0,
    output wire [7:0]  pk_d0,

    output wire [10:0] sk_address0,
    output wire        sk_ce0,
    output wire        sk_we0,
    output wire [7:0]  sk_d0
);

// ===================== FSM =====================
localparam [3:0]
    S_IDLE = 4'd0, S_G = 4'd1, S_GW = 4'd2, S_CBD = 4'd3, S_NTT = 4'd4,
    S_AB   = 4'd5, S_PACK= 4'd6, S_DONE = 4'd7;
reg [3:0] state;
reg [31:0] cnt;
reg [1:0]  idx;     // CBD/NTT 的 0..3, AB 的 0..1
reg [3:0]  sub;     // S_AB 子步骤 0..3
reg [3:0]  ph;      // S_PACK 阶段子状态 0..7
reg [7:0]  tb_pair; // tobytes 对索引 0..127
reg [2:0]  tb_step; // tobytes 步 0..4 (5 拍/对)

// ===================== RAM 定义 =====================
// ---- enc_r_ram[512]: AUTO_1R1W 双口 (读写各 2 口, 支持 cbd3 双写) ----
reg [15:0] enc_r_ram[0:511];
reg [15:0] enc_r_q0, enc_r_q1;
reg [9:0]  enc_r_a0, enc_r_a1;
reg        enc_r_ce0, enc_r_ce1, enc_r_we0, enc_r_we1;
wire [15:0] enc_r_d0, enc_r_d1;  // assign-driven (submodule outputs)
always @(posedge ap_clk) begin
    if (enc_r_ce0) begin
        if (enc_r_we0) enc_r_ram[enc_r_a0] <= enc_r_d0;
        else           enc_r_q0 <= enc_r_ram[enc_r_a0];
    end
end
always @(posedge ap_clk) begin
    if (enc_r_ce1) begin
        if (enc_r_we1) enc_r_ram[enc_r_a1] <= enc_r_d1;
        else           enc_r_q1 <= enc_r_ram[enc_r_a1];
    end
end

// ---- enc_e1_ram[512]: AUTO_1R1W 双口 ----
reg [15:0] enc_e1_ram[0:511];
reg [15:0] enc_e1_q0, enc_e1_q1;
reg [9:0]  enc_e1_a0, enc_e1_a1;
reg        enc_e1_ce0, enc_e1_ce1, enc_e1_we0, enc_e1_we1;
wire [15:0] enc_e1_d0;  // assign-driven: auto-track submodule outputs
wire [15:0] enc_e1_d1;
always @(posedge ap_clk) begin
    if (enc_e1_ce0) begin
        if (enc_e1_we0) enc_e1_ram[enc_e1_a0] <= enc_e1_d0;
        else           enc_e1_q0 <= enc_e1_ram[enc_e1_a0];
    end
end
always @(posedge ap_clk) begin
    if (enc_e1_ce1) begin
        if (enc_e1_we1) enc_e1_ram[enc_e1_a1] <= enc_e1_d1;
        else           enc_e1_q1 <= enc_e1_ram[enc_e1_a1];
    end
end

// ---- a_mat_ram[512]: 单写口 + 双读口 (A[i][0]@0..255, A[i][1]@256..511) ----
reg [15:0] a_mat_ram[0:511];
reg [15:0] a_mat_q0, a_mat_q1;
reg [8:0]  a_mat_ra0, a_mat_ra1, a_mat_wa;
reg        a_mat_rce0, a_mat_rce1, a_mat_wce, a_mat_wwe;
wire [15:0] a_mat_wd;
always @(posedge ap_clk) begin
    if (a_mat_rce0) a_mat_q0 <= a_mat_ram[a_mat_ra0];
end
always @(posedge ap_clk) begin
    if (a_mat_rce1) a_mat_q1 <= a_mat_ram[a_mat_ra1];
end
always @(posedge ap_clk) begin
    if (a_mat_wce) begin
        if (a_mat_wwe) a_mat_ram[a_mat_wa] <= a_mat_wd;
    end
end

// ---- poly1_ram[256]: AUTO_1R1W 双可读写口 ----
reg [15:0] poly1_ram[0:255];
reg [15:0] poly1_q0, poly1_q1;
reg [7:0]  poly1_a0, poly1_a1;
reg        poly1_ce0, poly1_ce1, poly1_we0, poly1_we1;
wire [15:0] poly1_d0, poly1_d1;
always @(posedge ap_clk) begin
    if (poly1_ce0) begin
        if (poly1_we0) poly1_ram[poly1_a0] <= poly1_d0;
        else           poly1_q0 <= poly1_ram[poly1_a0];
    end
end
always @(posedge ap_clk) begin
    if (poly1_ce1) begin
        if (poly1_we1) poly1_ram[poly1_a1] <= poly1_d1;
        else           poly1_q1 <= poly1_ram[poly1_a1];
    end
end

// ---- poly2_ram[256]: AUTO_1R1W 双可读写口 ----
reg [15:0] poly2_ram[0:255];
reg [15:0] poly2_q0, poly2_q1;
reg [7:0]  poly2_a0, poly2_a1;
reg        poly2_ce0, poly2_ce1, poly2_we0, poly2_we1;
wire [15:0] poly2_d0, poly2_d1;
always @(posedge ap_clk) begin
    if (poly2_ce0) begin
        if (poly2_we0) poly2_ram[poly2_a0] <= poly2_d0;
        else           poly2_q0 <= poly2_ram[poly2_a0];
    end
end
always @(posedge ap_clk) begin
    if (poly2_ce1) begin
        if (poly2_we1) poly2_ram[poly2_a1] <= poly2_d1;
        else           poly2_q1 <= poly2_ram[poly2_a1];
    end
end

// ---- enc_rho_ram[64]: 单写口 + 双读口 ----
reg [7:0]  enc_rho_ram[0:63];
reg [7:0]  enc_rho_q0, enc_rho_q1;
reg [5:0]  enc_rho_ra0, enc_rho_ra1, enc_rho_wa;
reg        enc_rho_rce0, enc_rho_rce1, enc_rho_wce, enc_rho_wwe;
wire [7:0]  enc_rho_wd;
always @(posedge ap_clk) begin
    if (enc_rho_rce0) enc_rho_q0 <= enc_rho_ram[enc_rho_ra0];
end
always @(posedge ap_clk) begin
    if (enc_rho_rce1) enc_rho_q1 <= enc_rho_ram[enc_rho_ra1];
end
always @(posedge ap_clk) begin
    if (enc_rho_wce) begin
        if (enc_rho_wwe) enc_rho_ram[enc_rho_wa] <= enc_rho_wd;
    end
end

// ---- pk_buf[800] (组合读) ----
reg [7:0] pk_buf[0:799];

// ===================== G 函数 =====================
reg  [263:0] g_din;
wire         g_valid, g_busy;
wire [511:0] g_out;
reg          g_go;
sha3_512_33b u_g(
    .clk(ap_clk), .rst_n(~ap_rst), .go(g_go), .din(g_din),
    .busy(g_busy), .valid(g_valid), .out(g_out));

// ===================== 运算单元实例 =====================
// ---- ntt ----
reg  ntt_go;  wire ntt_done;
wire [8:0]  ntt_r_a0; wire ntt_r_ce0, ntt_r_we0; wire [13:0] ntt_r_d0; wire [13:0] ntt_r_q0;
wire [5:0]  ntt_z0a;  wire ntt_z0ce; wire [11:0] ntt_z0q;
wire [5:0]  ntt_z1a;  wire ntt_z1ce; wire [11:0] ntt_z1q;
reg [1:0]   ntt_off;
kg_ntt u_ntt(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(ntt_go),
    .ap_done(ntt_done), .ap_idle(), .ap_ready(),
    .r_address0(ntt_r_a0), .r_ce0(ntt_r_ce0), .r_we0(ntt_r_we0),
    .r_d0(ntt_r_d0), .r_q0(ntt_r_q0),
    .r_offset(ntt_off[0]),
    .p_ZL5zetas_0_address0(ntt_z0a), .p_ZL5zetas_0_ce0(ntt_z0ce), .p_ZL5zetas_0_q0(ntt_z0q),
    .p_ZL5zetas_1_address0(ntt_z1a), .p_ZL5zetas_1_ce0(ntt_z1ce), .p_ZL5zetas_1_q0(ntt_z1q));

// ---- poly_uniform ----
reg  uniform_go; wire uniform_done;
reg [1:0] unif_i, unif_j;
wire [4:0] unif_rho_a; wire unif_rho_ce; wire [7:0] unif_rho_q;
wire [8:0] unif_am_a;  wire unif_am_ce, unif_am_we; wire [11:0] unif_am_d;
kg_poly_uniform u_uniform(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(uniform_go),
    .ap_done(uniform_done), .ap_idle(), .ap_ready(),
    .i(unif_i[0]), .j(unif_j[0]),
    .enc_rho_address0(unif_rho_a), .enc_rho_ce0(unif_rho_ce), .enc_rho_q0(unif_rho_q),
    .a_mat_address0(unif_am_a), .a_mat_ce0(unif_am_ce), .a_mat_we0(unif_am_we),
    .a_mat_d0(unif_am_d));

// ---- poly_basemul ----
reg  basemul_go; wire basemul_done;
reg [1:0] bm_a_off, bm_b_off;
wire [7:0] bm_r_a0; wire bm_r_ce0, bm_r_we0; wire [15:0] bm_r_d0;
wire [7:0] bm_r_a1; wire bm_r_ce1, bm_r_we1; wire [15:0] bm_r_d1;
wire [8:0] bm_a_a0; wire bm_a_ce0; wire [11:0] bm_a_q0;
wire [8:0] bm_a_a1; wire bm_a_ce1; wire [11:0] bm_a_q1;
wire [8:0] bm_b_a0; wire bm_b_ce0; wire [13:0] bm_b_q0;
wire [8:0] bm_b_a1; wire bm_b_ce1; wire [13:0] bm_b_q1;
kg_poly_basemul u_basemul(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(basemul_go),
    .ap_done(basemul_done), .ap_idle(), .ap_ready(),
    .r_address0(bm_r_a0), .r_ce0(bm_r_ce0), .r_we0(bm_r_we0), .r_d0(bm_r_d0),
    .r_address1(bm_r_a1), .r_ce1(bm_r_ce1), .r_we1(bm_r_we1), .r_d1(bm_r_d1),
    .a_address0(bm_a_a0), .a_ce0(bm_a_ce0), .a_q0(bm_a_q0),
    .a_address1(bm_a_a1), .a_ce1(bm_a_ce1), .a_q1(bm_a_q1),
    .a_offset(bm_a_off[0]), .b_offset(bm_b_off[0]),
    .enc_r_address0(bm_b_a0), .enc_r_ce0(bm_b_ce0), .enc_r_q0(bm_b_q0),
    .enc_r_address1(bm_b_a1), .enc_r_ce1(bm_b_ce1), .enc_r_q1(bm_b_q1));

// ---- poly_add (r = b + poly1) ----
reg  add_go; wire add_done;
wire [7:0] add_r_a0; wire add_r_ce0, add_r_we0; wire [15:0] add_r_d0;
wire [7:0] add_b_a0; wire add_b_ce0; wire [15:0] add_b_q0;
wire [7:0] add_p1_a0; wire add_p1_ce0; wire [15:0] add_p1_q0;
kg_poly_add u_add(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(add_go),
    .ap_done(add_done), .ap_idle(), .ap_ready(),
    .r_address0(add_r_a0), .r_ce0(add_r_ce0), .r_we0(add_r_we0), .r_d0(add_r_d0),
    .b_address0(add_b_a0), .b_ce0(add_b_ce0), .b_q0(add_b_q0),
    .poly1_address0(add_p1_a0), .poly1_ce0(add_p1_ce0), .poly1_q0(add_p1_q0));

// ---- poly_reduce ----
reg  reduce_go; wire reduce_done;
wire [7:0] red_r_a0; wire red_r_ce0, red_r_we0; wire [15:0] red_r_d0;
wire [7:0] red_r_a1; wire red_r_ce1; wire [15:0] red_r_q1;
kg_poly_reduce u_reduce(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(reduce_go),
    .ap_done(reduce_done), .ap_idle(), .ap_ready(),
    .r_address0(red_r_a0), .r_ce0(red_r_ce0), .r_we0(red_r_we0), .r_d0(red_r_d0),
    .r_address1(red_r_a1), .r_ce1(red_r_ce1), .r_q1(red_r_q1));

// ---- poly_getnoise_eta1 ----
reg  getnoise_go; wire getnoise_done;
reg [1:0] gn_off, gn_nonce;
wire [8:0] gn_r_a0; wire gn_r_ce0, gn_r_we0; wire [13:0] gn_r_d0;
wire [8:0] gn_r_a1; wire gn_r_ce1, gn_r_we1; wire [13:0] gn_r_d1;
wire [5:0] gn_k_a;  wire gn_k_ce; wire [7:0] gn_k_q;
kg_poly_getnoise_eta1 u_getnoise(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(getnoise_go),
    .ap_done(getnoise_done), .ap_idle(), .ap_ready(),
    .r_address0(gn_r_a0), .r_ce0(gn_r_ce0), .r_we0(gn_r_we0), .r_d0(gn_r_d0),
    .r_address1(gn_r_a1), .r_ce1(gn_r_ce1), .r_we1(gn_r_we1), .r_d1(gn_r_d1),
    .r_offset(gn_off[0]),
    .key_address0(gn_k_a), .key_ce0(gn_k_ce), .key_q0(gn_k_q),
    .nonce(gn_nonce));

// ---- sha3_once_1 (H) ----
reg  h_go; wire h_done;
wire [5:0] h_out_a; wire h_out_ce, h_out_we; wire [7:0] h_out_d;
wire [9:0] h_in_a0; wire h_in_ce0; wire [7:0] h_in_q0;
wire [9:0] h_in_a1; wire h_in_ce1; wire [7:0] h_in_q1;
kg_sha3_once_1 u_h(
    .ap_clk(ap_clk), .ap_rst(ap_rst), .ap_start(h_go),
    .ap_done(h_done), .ap_idle(), .ap_ready(),
    .out_r_address0(h_out_a), .out_r_ce0(h_out_ce), .out_r_we0(h_out_we), .out_r_d0(h_out_d),
    .in_r_address0(h_in_a0), .in_r_ce0(h_in_ce0), .in_r_q0(h_in_q0),
    .in_r_address1(h_in_a1), .in_r_ce1(h_in_ce1), .in_r_q1(h_in_q1));

// ===================== ntt zetas ROM (外部, 同步读) =====================
reg [11:0] ntt_z0_rom[0:63];
reg [11:0] ntt_z1_rom[0:63];
initial begin
    $readmemh("C:/Users/lenovo/Desktop/HLS/project/hls_ab/rtl/keygen/mlkem_a_top_crypto_kem_enc_derand_p_ZL5zetas_0_ROM_AUTO_1R.dat", ntt_z0_rom);
    $readmemh("C:/Users/lenovo/Desktop/HLS/project/hls_ab/rtl/keygen/mlkem_a_top_crypto_kem_enc_derand_p_ZL5zetas_1_ROM_AUTO_1R.dat", ntt_z1_rom);
end
reg [11:0] ntt_z0q_r, ntt_z1q_r;
always @(posedge ap_clk) begin
    if (ntt_z0ce) ntt_z0q_r <= ntt_z0_rom[ntt_z0a];
    if (ntt_z1ce) ntt_z1q_r <= ntt_z1_rom[ntt_z1a];
end
assign ntt_z0q = ntt_z0q_r;
assign ntt_z1q = ntt_z1q_r;

// ===================== 组合桥接: RAM/外部端口唯一驱动源 =====================
// 全部由 state/cnt/sub/ph/tb_* 等组合决定, 无时序驱动. 无多重驱动.
// ---- 内部读回 mux 线 (assign) ----
reg [13:0] ntt_q0_s;
reg [11:0] bm_a0_s, bm_a1_s;
reg [13:0] bm_b0_s, bm_b1_s;
reg [15:0] add_b0_s, add_p10_s;
reg [15:0] red_q1_s;
reg [15:0] dmy;
reg [7:0]  unif_rho_s;
reg [7:0]  gn_key_s;
reg [7:0]  h_in0_s, h_in1_s;
assign ntt_r_q0  = ntt_q0_s;
assign bm_a_q0   = bm_a0_s;
assign bm_a_q1   = bm_a1_s;
assign bm_b_q0   = bm_b0_s;
assign bm_b_q1   = bm_b1_s;
assign add_b_q0  = add_b0_s;
assign add_p1_q0 = add_p10_s;
assign red_r_q1  = red_q1_s;
assign unif_rho_q = unif_rho_s;
assign gn_k_q    = gn_key_s;
assign h_in_q0   = h_in0_s;
assign h_in_q1   = h_in1_s;

// ---- 外部端口 reg (组合驱动) ----
reg [4:0]  d_a;  reg d_ce;
reg [4:0]  z_a;  reg z_ce;
reg [9:0]  pk_a; reg pk_ce, pk_we; reg [7:0] pk_d;
reg [10:0] sk_a; reg sk_ce, sk_we; reg [7:0] sk_d;
assign d_address0 = d_a;  assign d_ce0 = d_ce;
assign z_address0 = z_a;  assign z_ce0 = z_ce;
assign pk_address0 = pk_a; assign pk_ce0 = pk_ce; assign pk_we0 = pk_we; assign pk_d0 = pk_d;
assign sk_address0 = sk_a; assign sk_ce0 = sk_ce; assign sk_we0 = sk_we; assign sk_d0 = sk_d;

always @(*) begin
    // ---- 默认 ----
    d_a=0; d_ce=0; z_a=0; z_ce=0;
    pk_a=0; pk_ce=0; pk_we=0; pk_d=0;
    sk_a=0; sk_ce=0; sk_we=0; sk_d=0;
    enc_r_ce0=0; enc_r_ce1=0; enc_r_we0=0; enc_r_we1=0; enc_r_a0=0; enc_r_a1=0;
    enc_e1_ce0=0; enc_e1_ce1=0; enc_e1_we0=0; enc_e1_we1=0; enc_e1_a0=0; enc_e1_a1=0;
    a_mat_rce0=0; a_mat_rce1=0; a_mat_wce=0; a_mat_wwe=0; a_mat_wa=0; a_mat_ra0=0; a_mat_ra1=0;
    poly1_ce0=0; poly1_ce1=0; poly1_we0=0; poly1_we1=0; poly1_a0=0; poly1_a1=0;
    poly2_ce0=0; poly2_ce1=0; poly2_we0=0; poly2_we1=0; poly2_a0=0; poly2_a1=0;
    enc_rho_rce0=0; enc_rho_rce1=0; enc_rho_wce=0; enc_rho_wwe=0; enc_rho_wa=0; enc_rho_ra0=0; enc_rho_ra1=0;
    ntt_q0_s=0; bm_a0_s=0; bm_a1_s=0; bm_b0_s=0; bm_b1_s=0;
    add_b0_s=0; add_p10_s=0; red_q1_s=0; unif_rho_s=0; gn_key_s=0; h_in0_s=0; h_in1_s=0;
    // dummy sensitivity anchors for submodule-output wires (iverilog @* does not track them)
    dmy = add_r_d0 | ntt_r_d0 | bm_r_d0 | red_r_d0 | gn_r_d0;

    // TEMP: sensitivity test - force default
    // enc_e1_d0 = 16'hAAAA;

    case (state)
        // ============ S_G: 读 d 32 字节 ============
        S_G: begin
            if (cnt <= 31) begin
                d_a = cnt[4:0]; d_ce = 1;
            end
        end

        // ============ S_GW: 写 rho/sigma -> enc_rho_ram ============
        S_GW: begin
            enc_rho_wce = 1; enc_rho_wwe = 1;
            enc_rho_wa = cnt[5:0];
        end

        // ============ S_CBD: getnoise 写 enc_r/e1 (双写口), key 读 enc_rho ============
        S_CBD: begin
            // getnoise r 双写口 -> enc_r (idx<2) / enc_e1 (idx>=2)
            if (idx < 2) begin
                enc_r_a0 = gn_r_a0; enc_r_ce0 = gn_r_ce0;
                enc_r_we0 = gn_r_we0;
                enc_r_a1 = gn_r_a1; enc_r_ce1 = gn_r_ce1;
                enc_r_we1 = gn_r_we1;
            end else begin
                enc_e1_a0 = gn_r_a0; enc_e1_ce0 = gn_r_ce0;
                enc_e1_we0 = gn_r_we0;
                enc_e1_a1 = gn_r_a1; enc_e1_ce1 = gn_r_ce1;
                enc_e1_we1 = gn_r_we1;
            end
            // key 读口 (enc_rho[32..63] = sigma)
            enc_rho_ra1 = gn_k_a; enc_rho_rce1 = gn_k_ce;
            gn_key_s = enc_rho_q1;
        end

        // ============ S_NTT: ntt 双口读写 enc_r/e1 (r 单口 rw + 双读口) ============
        S_NTT: begin
            if (idx < 2) begin
                enc_r_a0 = ntt_r_a0; enc_r_ce0 = ntt_r_ce0;
                enc_r_we0 = ntt_r_we0;
                enc_r_a1 = ntt_r_a0; enc_r_ce1 = ntt_r_ce0;   // 读回同址 (we0=0 时)
                enc_r_we1 = 1'b0;
                ntt_q0_s = enc_r_q0;
            end else begin
                enc_e1_a0 = ntt_r_a0; enc_e1_ce0 = ntt_r_ce0;
                enc_e1_we0 = ntt_r_we0;
                enc_e1_a1 = ntt_r_a0; enc_e1_ce1 = ntt_r_ce0;
                enc_e1_we1 = 1'b0;
                ntt_q0_s = enc_e1_q0;
            end
        end

        // ============ S_AB ============
        S_AB: begin
            case (sub)
                4'd0: begin
                    // 清 poly1 (port0 写 0) OR basemul r 写 poly1
                    if (cnt < 256) begin
                        poly1_a0 = cnt[7:0]; poly1_ce0 = 1;
                        poly1_we0 = 1;
                    end else begin
                        // basemul r 双口写 poly1 (port0 + port1)
                        poly1_a0 = bm_r_a0; poly1_ce0 = bm_r_ce0;
                        poly1_we0 = bm_r_we0;
                        poly1_a1 = bm_r_a1; poly1_ce1 = bm_r_ce1;
                        poly1_we1 = bm_r_we1;
                    end
                    // uniform(i,0) 写 a_mat + rho 读 (与 basemul 不同时活跃)
                    a_mat_wa = unif_am_a; a_mat_wce = unif_am_ce;
                    a_mat_wwe = unif_am_we;
                    enc_rho_ra0 = unif_rho_a; enc_rho_rce0 = unif_rho_ce;
                    unif_rho_s = enc_rho_q0;
                    // basemul a 读 a_mat 双口
                    a_mat_ra0 = bm_a_a0; a_mat_rce0 = bm_a_ce0;
                    a_mat_ra1 = bm_a_a1; a_mat_rce1 = bm_a_ce1;
                    bm_a0_s = a_mat_q0; bm_a1_s = a_mat_q1;
                    // basemul b 读 enc_r (s_hat 段)
                    enc_r_a0 = bm_b_a0; enc_r_ce0 = bm_b_ce0; enc_r_we0 = 1'b0;
                    enc_r_a1 = bm_b_a1; enc_r_ce1 = bm_b_ce1; enc_r_we1 = 1'b0;
                    bm_b0_s = enc_r_q0; bm_b1_s = enc_r_q1;
                end
                4'd1: begin
                    // uniform(i,1) 写 a_mat
                    a_mat_wa = unif_am_a; a_mat_wce = unif_am_ce;
                    a_mat_wwe = unif_am_we;
                    enc_rho_ra0 = unif_rho_a; enc_rho_rce0 = unif_rho_ce;
                    unif_rho_s = enc_rho_q0;
                    // basemul r 双口写 poly2
                    poly2_a0 = bm_r_a0; poly2_ce0 = bm_r_ce0;
                    poly2_we0 = bm_r_we0;
                    poly2_a1 = bm_r_a1; poly2_ce1 = bm_r_ce1;
                    poly2_we1 = bm_r_we1;
                    // basemul a 读 a_mat 双口
                    a_mat_ra0 = bm_a_a0; a_mat_rce0 = bm_a_ce0;
                    a_mat_ra1 = bm_a_a1; a_mat_rce1 = bm_a_ce1;
                    bm_a0_s = a_mat_q0; bm_a1_s = a_mat_q1;
                    // basemul b 读 enc_r (s_hat 段)
                    enc_r_a0 = bm_b_a0; enc_r_ce0 = bm_b_ce0; enc_r_we0 = 1'b0;
                    enc_r_a1 = bm_b_a1; enc_r_ce1 = bm_b_ce1; enc_r_we1 = 1'b0;
                    bm_b0_s = enc_r_q0; bm_b1_s = enc_r_q1;
                    // add(poly1, poly1, poly2): r 写 poly1 port1, b 读 poly2 port0, poly1 读 poly1 port0
                    poly1_a0 = add_p1_a0; poly1_ce0 = add_p1_ce0;   // 读 poly1 (参数 b)
                    poly1_we0 = 1'b0;
                    add_p10_s = poly1_q0;
                    poly1_a1 = add_r_a0; poly1_ce1 = add_r_ce0;     // 写 poly1 (r)
                    poly1_we1 = add_r_we0;
                    if (add_b_ce0) begin
                        // add 读 poly2 (参数 a); basemul 写 poly2 与之时序互斥,
                        // add 活跃时覆盖 poly2_a0/ce0/we0
                        poly2_a0 = add_b_a0; poly2_ce0 = add_b_ce0;
                        poly2_we0 = 1'b0;
                    end
                    add_b0_s = poly2_q0;
                end
                4'd2: begin
                    // add(vec2[i], vec2[i], poly1): r 写 enc_e1 port0, b 读 enc_e1 port1, poly1 读 poly1
                    enc_e1_a0 = {idx[0], add_r_a0}; enc_e1_ce0 = add_r_ce0;
                    enc_e1_we0 = add_r_we0;
                    enc_e1_a1 = {idx[0], add_b_a0}; enc_e1_ce1 = add_b_ce0; enc_e1_we1 = 1'b0;
                    add_b0_s = enc_e1_q1;
                    poly1_a0 = add_p1_a0; poly1_ce0 = add_p1_ce0;
                    poly1_we0 = 1'b0;
                    add_p10_s = poly1_q0;
                end
                4'd3: begin
                    // reduce(vec2[i]): r 写+读 enc_e1 段
                    enc_e1_a0 = {idx[0], red_r_a0}; enc_e1_ce0 = red_r_ce0;
                    enc_e1_we0 = red_r_we0;
                    enc_e1_a1 = {idx[0], red_r_a1}; enc_e1_ce1 = red_r_ce1; enc_e1_we1 = 1'b0;
                    red_q1_s = enc_e1_q1;
                end
                default: ;
            endcase
        end

        // ============ S_PACK ============
        S_PACK: begin
            if (ph <= 4'd3) begin
                // tobytes 读源: ph0/1 -> enc_e1 段, ph2/3 -> enc_r 段
                // 每对 5 拍: step0 预读, step1 锁存, step2/3/4 写
                if (tb_step == 3'd0) begin
                    if (ph[1] == 1'b0) begin
                        // iverilog @(*) 对部分选择 concat 不传播 ph[0], 用算术展开
                        enc_e1_a0 = (ph[0] ? 10'd256 : 10'd0) + {2'b00, tb_pair, 1'b0};
                        enc_e1_a1 = (ph[0] ? 10'd256 : 10'd0) + {2'b00, tb_pair, 1'b1};
                        enc_e1_ce0 = 1'b1; enc_e1_we0 = 1'b0;
                        enc_e1_ce1 = 1'b1; enc_e1_we1 = 1'b0;
                    end else begin
                        enc_r_a0 = (ph[0] ? 10'd256 : 10'd0) + {2'b00, tb_pair, 1'b0};
                        enc_r_a1 = (ph[0] ? 10'd256 : 10'd0) + {2'b00, tb_pair, 1'b1};
                        enc_r_ce0 = 1'b1; enc_r_we0 = 1'b0;
                        enc_r_ce1 = 1'b1; enc_r_we1 = 1'b0;
                    end
                end
                // tobytes 写外部端口: step2/3/4 写 3 字节
                if (tb_step >= 3'd2 && tb_step <= 3'd4) begin
                    if (ph[1] == 1'b0) begin
                        pk_a = ph[0]*384 + tb_pair*3 + (tb_step - 3'd2);
                        pk_ce = 1; pk_we = 1;
                        if (tb_step == 3'd2)      pk_d = tb_b0;
                        else if (tb_step == 3'd3) pk_d = tb_b1;
                        else                      pk_d = tb_b2;
                    end else begin
                        sk_a = (ph[0] ? 11'd384 : 11'd0) + tb_pair*3 + (tb_step - 3'd2);
                        sk_ce = 1; sk_we = 1;
                        if (tb_step == 3'd2)      sk_d = tb_b0;
                        else if (tb_step == 3'd3) sk_d = tb_b1;
                        else                      sk_d = tb_b2;
                    end
                end
            end else if (ph == 4'd4) begin
                // rho -> pk[768..799]: 同步读 enc_rho
                if (cnt <= 32) begin
                    enc_rho_ra0 = cnt[5:0]; enc_rho_rce0 = 1'b1;
                    if (cnt >= 1) begin
                        pk_a = 10'd768 + cnt[5:0] - 1; pk_ce = 1; pk_we = 1;
                        pk_d = enc_rho_q0;
                    end
                end
            end else if (ph == 4'd5) begin
                // pk -> sk[768..1567]: pk_buf 组合读
                if (cnt <= 799) begin
                    sk_a = 11'd768 + cnt[9:0]; sk_ce = 1; sk_we = 1;
                    sk_d = pk_buf[cnt[9:0]];
                end
            end else if (ph == 4'd6) begin
                // z -> sk[1600..1631]: 同步读 z RAM
                if (cnt <= 32) begin
                    z_a = cnt[5:0]; z_ce = 1;
                    if (cnt >= 1) begin
                        sk_a = 11'd1600 + cnt[5:0] - 1; sk_ce = 1; sk_we = 1;
                        sk_d = z_q0;
                    end
                end
            end else if (ph == 4'd7) begin
                // H(pk) 读 pk_buf: 无条件驱动, 直到 H 模块完成所有读取
                h_in0_s = pk_buf[h_in_a0];
                h_in1_s = pk_buf[h_in_a1];
                // H 输出搬运 -> sk[1568..1599] (H 输出在 h_r[32..63])
                if (cnt >= 3'd2 && cnt <= 6'd33) begin
                    sk_a = 11'd1568 + cnt[5:0] - 2;
                    sk_ce = 1; sk_we = 1; sk_d = h_r[cnt[5:0] + 6'd30];
                end
            end
        end
        default: ;
    endcase
end

// ---- assign-driven data lines: iverilog @(*) misses submodule-output wires in
//      deep conditional branches; continuous assigns auto-track all inputs. ----
assign enc_e1_d0 = (state==S_CBD && idx>=2) ? gn_r_d0 :
                   (state==S_NTT && idx>=2) ? ntt_r_d0 :
                   (state==S_AB && sub==4'd2) ? add_r_d0 :
                   (state==S_AB && sub==4'd3) ? red_r_d0 : 16'h0;
assign enc_e1_d1 = (state==S_CBD && idx>=2) ? gn_r_d1 : 16'h0;
assign enc_r_d0  = (state==S_CBD && idx<2) ? gn_r_d0 :
                   (state==S_NTT && idx<2) ? ntt_r_d0 : 16'h0;
assign enc_r_d1  = (state==S_CBD && idx<2) ? gn_r_d1 : 16'h0;
assign a_mat_wd  = (state==S_AB && (sub==4'd0 || sub==4'd1)) ? unif_am_d : 16'h0;
assign enc_rho_wd = (state==S_GW) ? g_out[8*cnt +: 8] : 8'h0;
assign poly1_d0  = (state==S_AB && sub==4'd0) ? (cnt<256 ? 16'h0 : bm_r_d0) : 16'h0;
assign poly1_d1  = (state==S_AB && sub==4'd0) ? bm_r_d1 :
                   (state==S_AB && sub==4'd1) ? add_r_d0 : 16'h0;
assign poly2_d0  = (state==S_AB && sub==4'd1) ? bm_r_d0 : 16'h0;
assign poly2_d1  = (state==S_AB && sub==4'd1) ? bm_r_d1 : 16'h0;

// ===================== 主 FSM (单 always, 只驱动控制信号) =====================
reg [15:0] tb0, tb1;        // tobytes 暂存 2 项
wire [15:0] tb_t0, tb_t1;    // 符号归一化后 (连续赋值)
wire [7:0]  tb_b0, tb_b1, tb_b2;
reg [7:0]  h_r[0:63];       // H 输出暂存 (H 模块写 out_r[32..63])
reg [4:0]  h_wr;            // H 写入指针
reg        gn_done_prev;    // getnoise done 上一拍 (上升沿检测)
reg        ntt_done_prev;   // ntt done 上一拍
reg        unif_done_prev;  // uniform done 上一拍
reg        bm_done_prev;    // basemul done 上一拍
reg        add_done_prev;   // add done 上一拍
reg        red_done_prev;   // reduce done 上一拍

// tobytes 组合 (仅由 tb0/tb1 计算, 无端口驱动)
// 用连续赋值: iverilog @(*) 对子表达式位选传播不可靠, 直接 assign 全自动跟踪
assign tb_t0 = tb0[15] ? tb0 + 16'd3329 : tb0;
assign tb_t1 = tb1[15] ? tb1 + 16'd3329 : tb1;
assign tb_b0 = tb_t0[7:0];
assign tb_b1 = ((tb_t1 & 16'h000F) << 4) | ((tb_t0 >> 8) & 16'h00FF);
assign tb_b2 = (tb_t1 >> 4) & 16'h00FF;

always @(posedge ap_clk) begin
    if (ap_rst) begin
        state <= S_IDLE;
        ntt_go <= 0; uniform_go <= 0; basemul_go <= 0; add_go <= 0;
        reduce_go <= 0; getnoise_go <= 0; h_go <= 0; g_go <= 0;
        ap_done <= 0; ap_idle <= 1; ap_ready <= 0;
        cnt <= 0; idx <= 0; sub <= 0; ph <= 0; tb_pair <= 0; tb_step <= 0;
        tb0 <= 0; tb1 <= 0; h_wr <= 0;
        gn_done_prev <= 0; ntt_done_prev <= 0;
        unif_done_prev <= 0; bm_done_prev <= 0; add_done_prev <= 0; red_done_prev <= 0;
    end else begin
        // 默认清单元 go
        ntt_go <= 0; uniform_go <= 0; basemul_go <= 0; add_go <= 0;
        reduce_go <= 0; getnoise_go <= 0; h_go <= 0; g_go <= 0;
        // 采样 done 上一拍 (上升沿检测)
        gn_done_prev <= getnoise_done;
        ntt_done_prev <= ntt_done;
        unif_done_prev <= uniform_done;
        bm_done_prev <= basemul_done;
        add_done_prev <= add_done;
        red_done_prev <= reduce_done;

        case (state)
            S_IDLE: begin
                ap_idle <= 1;
                if (ap_start) begin
                    ap_idle <= 0;
                    cnt <= 0;
                    state <= S_G;
                end
            end

            // ============ S_G: 读 d[32] -> g_din, 触发 G ============
            S_G: begin
                if (cnt == 0) begin
                    g_din <= {8'd2, 256'd0};   // K=0x02 in byte32 (din[263:256]); G(d||k)
                    cnt <= 1;
                end else if (cnt <= 32) begin
                    g_din[8*(cnt-1) +: 8] <= d_q0;   // d[cnt-1] -> byte cnt-1 (byte0..31)
                    cnt <= cnt + 1;
                end else if (cnt == 33) begin
                    g_go <= 1;
                    cnt <= 34;
                end else if (cnt == 34) begin
                    if (g_valid) begin
                        state <= S_GW; cnt <= 0;
                    end
                end
            end

            // ============ S_GW: 写 rho/sigma -> enc_rho_ram (64 拍) ============
            S_GW: begin
                if (cnt == 63) begin
                    state <= S_CBD; cnt <= 0; idx <= 0;
                end else begin
                    cnt <= cnt + 1;
                end
            end

            // ============ S_CBD: 4 次 getnoise (idx=0..3) ============
            // getnoise 空闲时 ap_done=1, 必须用 done 上升沿握手: 启动后 done 1->0,
            // 完成时 0->1. go 保持直到完成.
            S_CBD: begin
                if (cnt == 0) begin
                    if (idx < 2) gn_off <= idx; else gn_off <= idx - 2'd2;
                    gn_nonce <= idx;
                    getnoise_go <= 1;
                    cnt <= 1;
                end else begin
                    getnoise_go <= 1;           // 保持
                    if (getnoise_done && !gn_done_prev) begin
                        getnoise_go <= 0;
                        if (idx == 3) begin
                            state <= S_NTT; idx <= 0; cnt <= 0;
                        end else begin
                            idx <= idx + 1; cnt <= 0;
                        end
                    end
                end
            end

            // ============ S_NTT: 4 次 ntt (idx=0..3) ============
            // ntt 空闲时 ap_done=1, 用 done 上升沿握手
            S_NTT: begin
                if (cnt == 0) begin
                    if (idx < 2) ntt_off <= idx; else ntt_off <= idx - 2'd2;
                    ntt_go <= 1;
                    cnt <= 1;
                end else begin
                    if (ntt_done && !ntt_done_prev) begin
                        ntt_go <= 0;
                        if (idx == 3) begin
                            state <= S_AB; idx <= 0; cnt <= 0; sub <= 0;
                        end else begin
                            idx <= idx + 1; cnt <= 0;
                        end
                    end
                end
            end

            // ============ S_AB: 逐行 A*s + e (idx=0..1) ============
            // sub 0: clear poly1 + uniform(i,0) + basemul(poly1, a_mat, s_hat[0])
            // sub 1: uniform(i,1) + basemul(poly2, a_mat, s_hat[1]) + add(poly1+=poly2)
            // sub 2: add(vec2[i], vec2[i], poly1)
            // sub 3: reduce(vec2[i])
            // 注意: uniform/add/reduce 是 flow-control 流水线单元, ap_start 不锁存,
            //       go 必须保持到 done 到来 (与权威 enc top 的 ap_start_reg 握手一致).
            //       由于默认清零每拍执行, 等待拍必须显式重写 go <= 1 以保持.
            // uniform/add/reduce 是 flow-control 流水线单元 (ap_start 不锁存),
            // basemul 是 FSM 型. 两者空闲时 ap_done 均 =1.
            // 统一用 done 上升沿握手: 启动拍 go=1, 等待 done 0->1 后再清 go.
            S_AB: begin
                case (sub)
                    4'd0: begin
                        if (cnt < 256) begin
                            cnt <= cnt + 1;
                        end else if (cnt == 256) begin
                            unif_i <= idx; unif_j <= 0;
                            uniform_go <= 1;
                            cnt <= 257;
                        end else if (cnt == 257) begin
                            uniform_go <= 1;      // 保持
                            if (uniform_done && !unif_done_prev) begin
                                uniform_go <= 0;
                                bm_a_off <= 0; bm_b_off <= 0;
                                basemul_go <= 1;
                                cnt <= 258;
                            end
                        end else if (cnt == 258) begin
                            if (basemul_done && !bm_done_prev) begin
                                basemul_go <= 0;
                                sub <= 1; cnt <= 0;
                            end
                        end
                    end
                    4'd1: begin
                        if (cnt == 0) begin
                            unif_i <= idx; unif_j <= 1;
                            uniform_go <= 1;
                            cnt <= 1;
                        end else if (cnt == 1) begin
                            uniform_go <= 1;      // 保持
                            if (uniform_done && !unif_done_prev) begin
                                uniform_go <= 0;
                                bm_a_off <= 0; bm_b_off <= 1;
                                basemul_go <= 1;
                                cnt <= 2;
                            end
                        end else if (cnt == 2) begin
                            if (basemul_done && !bm_done_prev) begin
                                basemul_go <= 0;
                                add_go <= 1;
                                cnt <= 3;
                            end
                        end else if (cnt == 3) begin
                            add_go <= 1;          // 保持
                            if (add_done && !add_done_prev) begin
                                add_go <= 0;
                                sub <= 2; cnt <= 0;
                            end
                        end
                    end
                    4'd2: begin
                        if (cnt == 0) begin
                            add_go <= 1;
                            cnt <= 1;
                        end else if (cnt == 1) begin
                            add_go <= 1;          // 保持
                            if (add_done && !add_done_prev) begin
                                add_go <= 0;
                                sub <= 3; cnt <= 0;
                            end
                        end
                    end
                    4'd3: begin
                        if (cnt == 0) begin
                            reduce_go <= 1;
                            cnt <= 1;
                        end else if (cnt == 1) begin
                            reduce_go <= 1;       // 保持
                            if (reduce_done && !red_done_prev) begin
                                reduce_go <= 0;
                                if (idx == 1) begin
                                    state <= S_PACK; idx <= 0; ph <= 0; cnt <= 0;
                                    tb_pair <= 0; tb_step <= 0;
                                end else begin
                                    idx <= idx + 1; sub <= 0; cnt <= 0;
                                end
                            end
                        end
                    end
                    default: ;
                endcase
            end

            // ============ S_PACK: tobytes + 组装 ============
            S_PACK: begin
                if (ph <= 4'd3) begin
                    // tobytes: 每对 5 拍, tb_pair 0..127
                    case (tb_step)
                        3'd0: begin
                            // 预读 (组合块已拉 rce); 本拍无动作
                            tb_step <= 3'd1;
                        end
                        3'd1: begin
                            // q0/q1 有效, 锁存
                            tb0 <= (ph[1] ? enc_r_q0 : enc_e1_q0);
                            tb1 <= (ph[1] ? enc_r_q1 : enc_e1_q1);
                            tb_step <= 3'd2;
                        end
                        3'd2: begin
                            // 写 b0 -> pk_buf (镜像, 供 H(pk))
                            if (ph[1] == 1'b0)
                                pk_buf[ph[0]*384 + tb_pair*3] <= tb_b0;
                            tb_step <= 3'd3;
                        end
                        3'd3: begin
                            // 写 b1 -> pk_buf
                            if (ph[1] == 1'b0)
                                pk_buf[ph[0]*384 + tb_pair*3 + 1] <= tb_b1;
                            tb_step <= 3'd4;
                        end
                        3'd4: begin
                            // 写 b2 -> pk_buf
                            if (ph[1] == 1'b0)
                                pk_buf[ph[0]*384 + tb_pair*3 + 2] <= tb_b2;
                            if (tb_pair == 8'd127) begin
                                ph <= ph + 1; cnt <= 0; tb_pair <= 0; tb_step <= 0;
                            end else begin
                                tb_pair <= tb_pair + 1; tb_step <= 3'd0;
                            end
                        end
                        default: tb_step <= 3'd0;
                    endcase
                end else if (ph == 4'd4) begin
                    // rho -> pk[768..799]
                    if (cnt == 0) begin
                        cnt <= 1;
                    end else if (cnt <= 32) begin
                        pk_buf[10'd768 + cnt[5:0] - 1] <= enc_rho_q0;
                        if (cnt == 32) begin
                            ph <= 5; cnt <= 0;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end else if (ph == 4'd5) begin
                    // pk -> sk[768..1567]
                    if (cnt <= 799) begin
                        if (cnt == 799) begin
                            ph <= 6; cnt <= 0;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end else if (ph == 4'd6) begin
                    // z -> sk[1600..1631]
                    if (cnt == 0) begin
                        cnt <= 1;
                    end else if (cnt <= 32) begin
                        if (cnt == 32) begin
                            ph <= 7; cnt <= 0;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end else if (ph == 4'd7) begin
                    // H(pk): 先运行 H (多拍吸收 800B), 捕获输出, 再搬运到 sk
                    if (cnt == 0) begin
                        h_go <= 1; h_wr <= 0;
                        cnt <= 1;
                    end else if (cnt == 1) begin
                        // 保持 h_go (H 是 FSM 模块, ap_start 需保持到锁存)
                        h_go <= 1;
                        // 捕获 h_out 写期 (state18 期间逐字节写 32 次)
                        if (h_out_we) begin
                            h_r[h_out_a] <= h_out_d;
                            h_wr <= h_wr + 1;
                        end
                        if (h_done) begin
                            h_go <= 0;
                            cnt <= 2;
                        end
                    end else if (cnt <= 33) begin
                        // 搬运 h_r -> sk[1568..1599] (32B)
                        if (cnt == 33) begin
                            state <= S_DONE; cnt <= 0;
                        end else begin
                            cnt <= cnt + 1;
                        end
                    end
                end
            end

            S_DONE: begin
                ap_done <= 1;
                state <= S_IDLE;
            end
            default: state <= S_DONE;
        endcase
    end
end

endmodule
