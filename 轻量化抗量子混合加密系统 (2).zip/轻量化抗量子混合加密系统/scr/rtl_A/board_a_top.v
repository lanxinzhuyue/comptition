// ============================================================================
// board_a_top.v -- A 板加密闭环上板顶层 (Encaps 侧)
//
// IO (仅这些): clk_50m, rst_n, uart_rx(PC->A), uart_tx(A->B), led
//   内部实例化 mlkem_a_loop_top, 走真实上板路径:
//     USE_RAND=1      d/z/m 由内部 TRNG+SHAKE256 (NUM_RUNS=2) 产生
//     PK_FROM_UART=1  对端 pk_B 经 uart_rx 收包 ([0xAA][0x01][pk:800])
//                     明文帧 [0xAA][0x02][pt:16]
//     bypass_mlkem=0  真实 ML-KEM 核
//   SIM_MODE 参数透传: 0=真 TRNG(上板), 1=LFSR(仿真)
//
// 时钟: clk_50m (50MHz 板载晶振) -> clk_wiz_0 MMCM -> clk_out1=50MHz 给 loop.
//   (AES 密钥扩展改为迭代式后, 25MHz 收敛 WNS=+16.0ns, 关键路径 ~24ns;
//    现 clk_wiz_0 CLKOUT0_DIVIDE_F 改回 20.0 -> clk_out1=50MHz, 周期 20ns)
//   loop 的 CLK_FREQ 参数同步为 50MHz, UART 波特率自动重算:
//     115200 -> 50MHz/115200 = 434 分频 (16 位安全)
//
// 接线:
//   uart_rx  -> loop.uart1_rx   (PC 转发 B 的 pk_B + 发明文帧)
//   loop.uart2_tx -> uart_tx    (A -> B 密文帧 [0xAA][ct][ct_aes])
//   loop.uart1_tx 悬空 (A 不发回 PC, 预留)
//
// 波特率: 默认 115200 (50MHz/115200=434, source4 uart 16 位 baud_cnt 安全).
//   仿真加速可改 BAUD_RATE=1_152_000 (10x), SIM_MODE=1 (LFSR).
// ============================================================================
`timescale 1ns/1ps
module board_a_top #(
    parameter CLK_FREQ  = 50_000_000,    // 经 PLL 后的实际工作时钟 (与 clk_out1 一致)
    parameter BAUD_RATE = 115_200,       // 上板: 115200; 仿真加速: 1.152M
    parameter SIM_MODE  = 0              // 0=真TRNG(上板), 1=LFSR(仿真)
) (
    input  wire clk_50m,      // 50MHz 板载晶振 (MMCM 输入)
    input  wire rst_n,        // 低有效
    input  wire uart_rx,      // PC -> A
    output wire uart_tx,      // A -> B
    input  wire uart_nego_rx, // B -> A (协商直连)
    output wire led
);

    wire [255:0] ss;
    wire         loop_done;

    // ==================================================================
    // 时钟: 50MHz -> MMCM -> 50MHz (loop 工作时钟, clk_out1=50MHz)
    // ==================================================================
    wire clk_50m_p;   // MMCM 输出 (50MHz)
    wire locked;

    clk_wiz_0 u_clk_wiz (
        .clk_out1(clk_50m_p), // 50MHz
        .reset   (~rst_n),    // MMCM 复位高有效; 板载复位低有效取反
        .locked  (locked),
        .clk_in1 (clk_50m)    // 50MHz
    );

    // ==================================================================
    // 时钟未锁定时保持 loop 复位 (防 MMCM 锁定前自由运行)
    // ==================================================================
    wire rst_n_sync;
    rst_sync u_rst_sync (
        .clk  (clk_50m_p),
        .rstn (rst_n & locked),
        .rstn_out(rst_n_sync)
    );

    mlkem_a_loop_top #(
        .CLK_FREQ     (CLK_FREQ),
        .BAUD_RATE    (BAUD_RATE),
        .USE_RAND     (1),          // 内部 TRNG+SHAKE256
        .PK_FROM_UART (1),          // 旧路径 (保留)
        .AUTO_NEGO    (1),          // 自动协商: pk 走 nego_rx
        .SIM_MODE     (SIM_MODE)    // 0=真TRNG
    ) u_loop (
        .clk(clk_50m_p), .rst_n(rst_n_sync),
        .uart1_rx(uart_rx), .uart1_tx(),          // PC 口 (tx 预留)
        .uart_nego_rx(uart_nego_rx),              // B -> A 协商直连
        .uart2_tx(uart_tx),                       // A -> B 密文帧
        .d_in(256'd0), .z_in(256'd0), .m_in(256'd0),   // USE_RAND=1 忽略
        .pkB_w_a(), .pkB_w_q(32'd0), .pkB_ready(1'b0),
        .bypass_mlkem(1'b0), .ss_bypass(256'd0),
        .ct_bypass_w_a(), .ct_bypass_w_q(32'd0),
        .led(led), .done(loop_done), .ss_out(ss)
    );

endmodule
