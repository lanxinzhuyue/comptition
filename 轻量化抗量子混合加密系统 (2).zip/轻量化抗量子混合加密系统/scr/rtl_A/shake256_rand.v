`timescale 1ns / 1ps
// ---------------------------------------------------------------------------
// shake256_rand.v -- SHAKE256 后处理引擎 (TRNG 真随机源去偏/扩展)
//
// 功能: 接收 TRNG 收集的 32 字节 seed, 输出 64 字节伪随机 m||z:
//     out = SHAKE256( seed || SHAKE256(seed) )
//   (SP800-185 风格域分离: 先对 seed 做一次 SHAKE256 得 h, 再 SHAKE256(seed||h)
//    规避裸 seed 的长周期/欠偏风险)
//   输出: 前 32 字节 = m (A 板 Encaps 随机消息), 后 32 字节 = z (B 板 implicit rejection)
//
// 引擎: keccak_f1600_core (自包含 24 轮置换, 1 round/cycle, ~26 拍/置换)
//   - 内层 SHAKE256(seed) = h (32B): 1 次置换
//   - 外层 SHAKE256(seed||h) = 64B out: 1 次置换
//   总 2 次置换/请求 (~52 拍 @ 50MHz = ~1us)
//
// SHAKE256 rate = 136 字节 (25 lane - 9 lane 容量 = 17 lane rate 数据)
//   - 输入 32B seed / 64B seed||h 各占 1 block (rate 136 > 64)
//   - 域分离字节 0x1F, pad10*1: 输入末尾后跟 0x1F, rate 末尾 byte |= 0x80
//
// 接口:
//   go         : 上升沿触发一次生成
//   seed[255:0]: 32 字节输入 (来自 TRNG; seed[7:0]=byte0, LE)
//   busy       : 1 = 处理中, 0 = 空闲可接收新 go
//   out[511:0] : 64 字节输出 (m=out[255:0], z=out[511:256], LE)
//   valid      : 输出有效脉冲 (1 拍)
// ---------------------------------------------------------------------------
module shake256_rand (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         go,
    input  wire [255:0] seed,
    output reg          busy,
    output reg          valid,
    output reg  [511:0] out
);

    // ---------------------------------------------------------------------
    // keccak_f1600_core 实例 (内层置换: SHAKE256(seed) -> h)
    // ---------------------------------------------------------------------
    reg  [1599:0] core1_in;
    wire          core1_busy, core1_done;
    wire [1599:0] core1_out;
    reg           core1_go;
    keccak_f1600_core u_core1 (
        .clk       (clk),
        .rst_n     (rst_n),
        .go        (core1_go),
        .state_in  (core1_in),
        .busy      (core1_busy),
        .done      (core1_done),
        .state_out (core1_out)
    );

    // ---------------------------------------------------------------------
    // keccak_f1600_core 实例 (外层置换: SHAKE256(seed||h) -> out)
    // ---------------------------------------------------------------------
    reg  [1599:0] core2_in;
    wire          core2_busy, core2_done;
    wire [1599:0] core2_out;
    reg           core2_go;
    keccak_f1600_core u_core2 (
        .clk       (clk),
        .rst_n     (rst_n),
        .go        (core2_go),
        .state_in  (core2_in),
        .busy      (core2_busy),
        .done      (core2_done),
        .state_out (core2_out)
    );

    // ---------------------------------------------------------------------
    // 内层哈希 h = SHAKE256(seed) 的前 32 字节 (4 lane)
    // ---------------------------------------------------------------------
    reg [63:0] h_lane [0:3];

    // ---------------------------------------------------------------------
    // FSM
    // ---------------------------------------------------------------------
    localparam S_IDLE   = 3'd0;
    localparam S_CORE1  = 3'd1;   // 内层置换
    localparam S_CORE1W = 3'd2;   // 等内层 done
    localparam S_STOREH = 3'd3;   // 读 h (lane0..3) -> h_lane
    localparam S_CORE2  = 3'd4;   // 外层置换
    localparam S_CORE2W = 3'd5;   // 等外层 done
    localparam S_OUT    = 3'd6;   // 取 out (lane0..7)
    localparam S_DONE   = 3'd7;

    reg [2:0] state;
    integer   i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state    <= S_IDLE;
            busy     <= 1'b0;
            valid    <= 1'b0;
            core1_go <= 1'b0;
            core2_go <= 1'b0;
            out      <= 512'd0;
            for (i = 0; i < 4; i = i + 1) h_lane[i] <= 64'd0;
        end else begin
            valid    <= 1'b0;
            core1_go <= 1'b0;
            core2_go <= 1'b0;

            case (state)
                // ------------------------------------------
                S_IDLE: begin
                    if (go) begin
                        busy     <= 1'b1;
                        // 装配内层 block: seed(4 lane) + 0x1F + pad + 零
                        //   lane0..3 = seed
                        //   lane4 byte0 = 0x1F
                        //   lane16 byte7 |= 0x80
                        core1_in[ 63:   0] <= seed[ 63:  0];
                        core1_in[127:  64] <= seed[127: 64];
                        core1_in[191: 128] <= seed[191:128];
                        core1_in[255: 192] <= seed[255:192];
                        core1_in[319: 256] <= 64'h000000000000001F;
                        core1_in[ 63+64*5 +: 64] <= 64'd0;   // 占位
                        // 逐个 lane 清零 + 设 pad
                        // (用 generate 式: 全部 lane 先清, 再覆盖)
                        for (i = 0; i < 25; i = i + 1)
                            core1_in[64*i +: 64] <= 64'd0;
                        // 覆盖数据 lane 和 pad
                        core1_in[ 63:   0] <= seed[ 63:  0];
                        core1_in[127:  64] <= seed[127: 64];
                        core1_in[191: 128] <= seed[191:128];
                        core1_in[255: 192] <= seed[255:192];
                        core1_in[319: 256] <= 64'h000000000000001F;  // lane4 byte0
                        core1_in[1087:1024] <= 64'h8000000000000000;  // lane16 byte7 |= 0x80
                        state <= S_CORE1;
                    end
                end

                // ------------------------------------------
                S_CORE1: begin
                    core1_go <= 1'b1;
                    state    <= S_CORE1W;
                end
                S_CORE1W: begin
                    if (core1_done) begin
                        state <= S_STOREH;
                    end
                end

                // ------------------------------------------
                S_STOREH: begin
                    // core1_out lane0..3 = h (32B)
                    h_lane[0] <= core1_out[ 63:  0];
                    h_lane[1] <= core1_out[127: 64];
                    h_lane[2] <= core1_out[191:128];
                    h_lane[3] <= core1_out[255:192];
                    // 装配外层 block: seed||h(8 lane) + 0x1F + pad + 零
                    for (i = 0; i < 25; i = i + 1)
                        core2_in[64*i +: 64] <= 64'd0;
                    core2_in[ 63:   0] <= seed[ 63:  0];
                    core2_in[127:  64] <= seed[127: 64];
                    core2_in[191: 128] <= seed[191:128];
                    core2_in[255: 192] <= seed[255:192];
                    core2_in[319: 256] <= core1_out[ 63:  0];
                    core2_in[383: 320] <= core1_out[127: 64];
                    core2_in[447: 384] <= core1_out[191:128];
                    core2_in[511: 448] <= core1_out[255:192];
                    core2_in[575: 512] <= 64'h000000000000001F;  // lane8 byte0
                    core2_in[1087:1024] <= 64'h8000000000000000;  // lane16 byte7 |= 0x80
                    state <= S_CORE2;
                end

                // ------------------------------------------
                S_CORE2: begin
                    core2_go <= 1'b1;
                    state    <= S_CORE2W;
                end
                S_CORE2W: begin
                    if (core2_done) begin
                        state <= S_OUT;
                    end
                end

                // ------------------------------------------
                S_OUT: begin
                    // core2_out lane0..7 = out (64B), LE
                    out[ 63:   0] <= core2_out[ 63:  0];
                    out[127:  64] <= core2_out[127: 64];
                    out[191: 128] <= core2_out[191:128];
                    out[255: 192] <= core2_out[255:192];
                    out[319: 256] <= core2_out[319:256];
                    out[383: 320] <= core2_out[383:320];
                    out[447: 384] <= core2_out[447:384];
                    out[511: 448] <= core2_out[511:448];
                    state <= S_DONE;
                end

                // ------------------------------------------
                S_DONE: begin
                    busy  <= 1'b0;
                    valid <= 1'b1;
                    state <= S_IDLE;
                end

                default: state <= S_IDLE;
            endcase
        end
    end

endmodule
