`timescale 1ns / 1ps
// ============================================================================
// rand_src.v -- 上板随机源 (TRNG 真随机 seed + SHAKE256 后处理)
//
// 为 loop top 提供 d/z/m 随机值, 替代 tb 注入的参考值:
//   每次 SHAKE256 run 输出 64B = out[255:0](前32B) || out[511:256](后32B)
//     NUM_RUNS=1 (B 板): run0 -> d = 前32B, z = 后32B
//     NUM_RUNS=2 (A 板): run0 -> d,z ; run1 -> m = 前32B
//   SHAKE256(seed) = SHAKE256(seed || SHAKE256(seed)), 域分离去偏 (同 shake256_rand)
//
// 时序: 复位释放后自动生成, 每个 seed 窗口 TRNG 收集 256bit (~1024 cyc) +
//   SHAKE ~52 cyc. A 板 2 run ~2150 cyc (~43us @50MHz), 远早于首帧到达.
//   all_valid 电平保持, 一帧会话内 d/z/m 固定 (每次复位换一组新随机值).
//
// SIM_MODE: 1 = TRNG 用 LFSR 伪随机 (仿真可测), 0 = 真 TRNG PDL 振荡 (上板)
// ============================================================================
module rand_src #(
    parameter SIM_MODE = 1,     // 1=LFSR(仿真), 0=真TRNG(上板)
    parameter NUM_RUNS = 2      // SHAKE256 运行次数: 1=B(d,z), 2=A(d,z,m)
) (
    input  wire         clk,
    input  wire         rst_n,
    output wire [255:0] d_out,     // run0 前 32B (d)
    output wire [255:0] z_out,     // run0 后 32B (z)
    output wire [255:0] m_out,     // run1 前 32B (m, 仅 A 用)
    output reg          all_valid  // level: 全部随机数就绪
);

    // ---- TRNG (256-bit seed, 每窗口收集满拉 seed_valid 1 拍) ----
    wire [255:0] seed;
    wire         seed_valid;
    trng_pdl_top #(.SIM_MODE(SIM_MODE)) u_trng (
        .clk(clk), .rst_n(rst_n),
        .seed(seed), .seed_valid(seed_valid), .rand_bit()
    );

    // ---- SHAKE256 后处理引擎 ----
    wire         shake_busy, shake_valid;
    wire [511:0] shake_out;
    reg          shake_go;
    reg  [255:0] shake_seed;
    shake256_rand u_shake (
        .clk(clk), .rst_n(rst_n),
        .go(shake_go), .seed(shake_seed),
        .busy(shake_busy), .valid(shake_valid), .out(shake_out)
    );

    localparam [2:0] S_IDLE      = 3'd0,
                     S_WAIT_SEED = 3'd1,
                     S_SHAKE     = 3'd2,
                     S_WAIT      = 3'd3,
                     S_DONE      = 3'd4;
    reg [2:0] state;
    reg [1:0] run;          // 0..NUM_RUNS-1
    reg [255:0] d_r, z_r, m_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state     <= S_IDLE;
            run       <= 0;
            d_r       <= 256'd0;
            z_r       <= 256'd0;
            m_r       <= 256'd0;
            all_valid <= 1'b0;
            shake_go  <= 1'b0;
            shake_seed<= 256'd0;
        end else begin
            shake_go <= 1'b0;          // go 只打 1 拍
            case (state)
                S_IDLE: if (!all_valid) begin
                            run   <= 0;
                            state <= S_WAIT_SEED;
                        end

                // 等 TRNG 收集满一组 256-bit seed
                S_WAIT_SEED: begin
                    if (seed_valid) begin
                        shake_seed <= seed;      // 冻结本 run 的 seed
                        state      <= S_SHAKE;
                    end
                end

                // 打 SHAKE256 go 脉冲, 等输出
                S_SHAKE: begin
                    shake_go <= 1'b1;
                    state    <= S_WAIT;
                end
                S_WAIT: begin
                    if (shake_valid) begin
                        if (run == 0) begin
                            d_r <= shake_out[255:0];
                            z_r <= shake_out[511:256];
                        end else begin
                            m_r <= shake_out[255:0];
                        end
                        if (run == NUM_RUNS-1) begin
                            all_valid <= 1'b1;
                            state     <= S_DONE;
                        end else begin
                            run   <= run + 1;
                            state <= S_WAIT_SEED;    // 等下一组 seed
                        end
                    end
                end

                S_DONE: state <= S_DONE;           // 保持
                default: state <= S_IDLE;
            endcase
        end
    end

    assign d_out = d_r;
    assign z_out = z_r;
    assign m_out = m_r;

endmodule
